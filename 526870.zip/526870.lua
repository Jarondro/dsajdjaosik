-- MAIN APPLICATION
addappid(526870, 1, "f8d1243ead37652491a8d284a79ee2b814ad878208ec9276f3d5d8b1528a11e7") -- Satisfactory
-- MAIN APP DEPOTS
addappid(526871, 1, "ae0ab673da3c9d0f444b1cd61fe8f2235d43e6c0401684a78f4fbdfc8f0d9bc1") -- ApatoaCorp Content
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3170070) -- Early Access supporter pack