-- MAIN APPLICATION
addappid(1926520) -- Ambulance Life: A Paramedic Simulator
-- MAIN APP DEPOTS
addappid(1926521, 1, "8d99afff8971c840af514a5901f2195b6fd5fabb00d1beaa89d547fe2b297787") -- Depot 1926521
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Ambulance Life - Paramedic Handbook Devs cut (AppID: 3077470)
addappid(3077470)
addappid(3077470, 1, "4e9bb8fadd0c69419eaa512af507a2f00b5e698d7d09b149cceb37abfe62e29a") -- Ambulance Life - Paramedic Handbook Devs cut - Depot 3077470
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3039580) -- Ambulance Life - Official Siren Pack
addappid(3140820) -- Ambulance Life - Fire Department Cosmetic Pack
addappid(3140830) -- Ambulance Life - Additional Siren Pack
addappid(3140840) -- Ambulance Life - Bay Side Expansion