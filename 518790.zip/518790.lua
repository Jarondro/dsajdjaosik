-- DLCS WITHOUT DEDICATED DEPOTS
addappid(602310) -- theHunter Call of the Wild - Bearclaw Lite CB-60
addappid(619790) -- theHunter Call of the Wild - Facing the Wild 1
addappid(622450) -- theHunter Call of the Wild - Tents  Ground Blinds
addappid(630940) -- theHunter Call of the Wild - ATV
addappid(640230) -- theHunter Call of the Wild - Shooting Range
addappid(695680) -- theHunter Call of the Wild - Medved-Taiga
addappid(706150) -- theHunter Call of the Wild - Backpacks
addappid(766870) -- theHunter Call of the Wild - Weapon Pack 1
addappid(767380) -- theHunter Call of the Wild - New Species 2018
addappid(854070) -- theHunter Call of the Wild - Wild Goose Chase Gear
addappid(894600) -- theHunter Call of the Wild - Vurhonga Savanna
addappid(939840) -- theHunter Call of the Wild - Duck and Cover Pack
addappid(986850) -- theHunter Call of the Wild - Parque Fernando
addappid(1011280) -- theHunter Call of the Wild - New Species 2019
addappid(1028270) -- theHunter Call of the Wild - Weapon Pack 2
addappid(1052690) -- theHunter Call of the Wild - Trophy Lodge Spring Creek Manor
addappid(1070170) -- theHunter Call of the Wild - TruRACS
addappid(1076850) -- theHunter Call of the Wild - Treestand  Tripod Pack
addappid(1093700) -- theHunter Call of the Wild - Yukon Valley
addappid(1108410) -- theHunter Call of the Wild - Weapon Pack 3
addappid(1146830) -- theHunter Call of the Wild - High-Tech Hunting Pack
addappid(1164110) -- theHunter Call of the Wild - Saseka Safari Trophy Lodge
addappid(1179710) -- theHunter Call of the Wild - Cuatro Colinas Game Reserve 
addappid(1252750) -- theHunter Call of the Wild - Smoking Barrels Weapon Pack
addappid(1316840) -- theHunter Call of the Wild - Silver Ridge Peaks
addappid(1433620) -- theHunter Call of the Wild - Remi Warren
addappid(1450350) -- theHunter Call of the Wild - Free Species European Rabbit
addappid(1463090) -- theHunter Call of the Wild - Te Awaroa National Park
addappid(1546670) -- theHunter Call of the Wild - Bloodhound
addappid(1608440) -- theHunter Call of the Wild - Rancho del Arroyo
addappid(1776430) -- theHunter Call of the Wild - Mississippi Acres Preserve
addappid(1843410) -- theHunter Call of the Wild - Modern Rifle Pack
addappid(1931910) -- theHunter Call of the Wild - Revontuli Coast
addappid(2064720) -- theHunter Call of the Wild - Assorted Sidearms Pack
addappid(2167630) -- theHunter Call of the Wild - New England Mountains
addappid(2197810) -- theHunter Call of the Wild - Emerald Coast Cosmetic Pack
addappid(2197811) -- theHunter Call of the Wild - Sundarpatan Cosmetic Pack
addappid(2197812) -- theHunter Call of the Wild - Layton Lake Cosmetic Pack
addappid(2197822) -- theHunter Call of the Wild - Medved-Taiga Cosmetic Pack
addappid(2198012) -- theHunter Call of the Wild - Vurhonga Savanna Cosmetic Pack
addappid(2198015) -- theHunter Call of the Wild - Parque Fernando Cosmetic Pack
addappid(2198025) -- theHunter Call of the Wild	- Yukon Valley Cosmetic Pack
addappid(2198092) -- theHunter Call of the Wild - Cuatro Colinas Cosmetic Pack
addappid(2198095) -- theHunter Call of the Wild - Silver Ridge Peaks Cosmetic Pack
addappid(2198870) -- theHunter Call of the Wild - New England Scout Cosmetic Pack
addappid(2198872) -- theHunter Call of the Wild - New England Veteran Cosmetic Pack
addappid(2198874) -- theHunter Call of the Wild - Hirschfelden Veteran Cosmetic Pack
addappid(2199012) -- theHunter Call of the Wild - Te Awaroa Cosmetic Pack
addappid(2199015) -- theHunter Call of the Wild - Rancho del Arroyo Cosmetic Pack
addappid(2199072) -- theHunter Call of the Wild - Mississippi Acres Cosmetic Pack
addappid(2199075) -- theHunter Call of the Wild - Revontuli Coast Cosmetic Pack
addappid(2299780) -- theHunter Call of the Wild - Hunter Power Pack
addappid(2383430) -- theHunter Call of the Wild - Emerald Coast Australia
addappid(2532370) -- theHunter Call of the Wild  - Ambusher Pack
addappid(2631430) -- theHunter Call of the Wild - Labrador Retriever
addappid(2701860) -- theHunter Call of the Wild - High Caliber Weapon Pack
addappid(2869680) -- theHunter Call of the Wild - Sundarpatan Hunting Reserve
addappid(3106720) -- theHunter Call of the Wild - Scopes and Crosshairs Pack
addappid(3244800) -- theHunter Call of the Wild - German Shorthaired Pointer
addappid(3244810) -- theHunter Call of the Wild - Salzwiesen Park
addappid(3244820) -- theHunter Call of the Wild - Hunters Choice Bolt-Action Rifle Pack
addappid(3447720) -- theHunter Call of the Wild - Rapid Hunt Rifle Pack
addappid(3570290) -- theHunter Call of the Wild - Alberta Hunting Preserve
addappid(3750770) -- theHunter Call of the Wild  Pump, Flip and Fire Pack
addappid(3992110) -- theHunter Call of the Wild - Game Feeder Pack
addappid(4010590) -- theHunter Call of the Wild - Scotland Hunting Reserve
addappid(4089880) -- theHunter Call of the Wild - Premium Trophy Mount Pack
addappid(4182010) -- theHunter Call of the Wild - Game Feeder Pack 2
addappid(4424610) -- theHunter Call of the Wild - Multi-Class Weapon Pack
addappid(4467980) -- theHunter Call of the Wild - Peru Hunting Reserve