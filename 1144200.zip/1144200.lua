-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1844910) -- Ready or Not Supporter Edition
addappid(3015760) -- Ready or Not Home Invasion
addappid(3174120) -- Ready or Not Dark Waters
addappid(4224910) -- Ready or Not Boiling Point