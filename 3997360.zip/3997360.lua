-- MAIN APPLICATION
addappid(3997360) -- Pawnbroker Simulator
-- MAIN APP DEPOTS
addappid(3997361, 1, "603b76690d85648cc2996d2b3c7b6b3dd24b88d451ffb4f77ced6ebc9191dc25") -- Depot 3997361
