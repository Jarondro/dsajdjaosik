-- MAIN APPLICATION
addappid(1332720) -- Thief Simulator 2
-- MAIN APP DEPOTS
addappid(1332721, 1, "fa8baa603d576daf280269ec6d1581afea7eb9d1940f593ff8d3bbfb78339e14") -- Depot 1332721
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3027860) -- Thief Simulator 2: Cruise Ship DLC (unreleased)