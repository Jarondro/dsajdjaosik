-- MAIN APPLICATION
addappid(221910) -- The Stanley Parable
-- MAIN APP DEPOTS
addappid(221911, 1, "63a52ac3857a0c6a6a85bfe4af6d84395e79ddf0cc5e38eb1bf45b6932e30999") -- The Stanley Parable Content
addappid(221912, 1, "239566732a9a1d0e47deba270c2d39cdf30f5e1916164c046f4069f9751353e8") -- The Stanley Parable Windows
addappid(221913, 1, "e1551dfc6816c3dab69e361f7d3d8a3a5a7364c11c17932e91e41b129d012f9f") -- The Stanley Parable such OSX
addappid(221914, 1, "c5c453c2733e1fd0ba816e8772d28d2078d6ec93f2315063d2f1926eb9b1a903") -- The Stanley Parable Tea Edition
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
