-- MAIN APPLICATION
addappid(594330) -- Visage
-- MAIN APP DEPOTS
addappid(594331, 1, "bd25107db41b4499b57e397d12db225a8488620327bad7ef15021a9e0294cde9") -- Visage Content
addappid(594333, 1, "a6a275dec1c322efa0cc50745375764c4f89ccd32a2ed30809681bdadd6a51a6") -- Visage Content (32-bit)
addappid(938721, 1, "237b39e0b35e141f64b5354d0ade640791de2d73b268d60eaed3cec81254a6d9") -- Visage — Original Digital Soundtrack Depot
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
