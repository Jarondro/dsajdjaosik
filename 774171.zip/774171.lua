-- MAIN APPLICATION
addappid(774171) -- Muse Dash
addtoken(774171, "1032167890812251798")
-- MAIN APP DEPOTS
addappid(774172, 1, "c4fdeb37adb91f019b5f8f1378c0a63c3a3b90ffec89c7e0394b32a28206d2ec") -- Muse Dash Windows
addappid(774173, 1, "e3c55a2a1de897657fb5347590d09a3c41d944a2b041848d5cdacb44afed102f") -- Muse Dash MacOSX
-- DLCS WITH DEDICATED DEPOTS
-- Muse Dash - Just as planned (AppID: 1055810)
addappid(1055810)
addappid(1055810, 1, "ecf8e8de3bbebc8dc0a0f6aecb1c46d919f2172bb7e3611cd56ba636d523d880") -- Muse Dash - Just as planned - Just as planned (1055810) 个 Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2593750) -- Muse Plus