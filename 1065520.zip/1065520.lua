-- MAIN APPLICATION
addappid(1065520) -- Autobahn Police Simulator 3
-- MAIN APP DEPOTS
addappid(1065521, 1, "ebdf69796c66194e13e3eba42c193675f787c3d7e93d878ccbbbd71adfa98da7") -- Depot 1065521
addappid(1065522, 1, "2b897b355434d8d396d3cae8a4c488b3d6c9188df5daf894a3c01d316f5e5c3a") -- Depot 1065522
-- DLCS WITH DEDICATED DEPOTS
-- Autobahn Police Simulator 3 - Off-Road (AppID: 2068070)
addappid(2068070)
addappid(2068070, 1, "e5163f6d8fc49ac016e4318e092a2b6601b1f1f10244e0368abe68722f89914f") -- Autobahn Police Simulator 3 - Off-Road - Depot 2068070
-- Autobahn Police Simulator 3 - Police Motorcycle (AppID: 3679160)
addappid(3679160)
addappid(3679160, 1, "a1fa64703ed6dc8534814e8ee3ee2db076b4a1c0f4a2be2f27fbd9504211db98") -- Autobahn Police Simulator 3 - Police Motorcycle - Depot 3679160
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3679150) -- Autobahn Police Simulator 3 - Speed Trap
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1065529) -- Depot 1065529 (empty depot)