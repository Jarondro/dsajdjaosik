-- MAIN APPLICATION
addappid(555160, 1, "cce0685da5b14e488d26c085dc59e195e83269fad985ea8a046e6f874483de39") -- Pavlov VR
-- MAIN APP DEPOTS
addappid(555161, 1, "a735c234a21b56c19d12783ed863a989479bace230efa2b8dc0c7098c99706eb") -- Pavlov Content
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
