-- MAIN APPLICATION
addappid(3869850, 1, "4d671bbfca31d67afd56d7180e5c7f3f0cb8278d313eeeda26903381569433c3") -- Welcome to the Game III
-- MAIN APP DEPOTS
addappid(3869851, 1, "6a3013f6cdd84051c584e737937cec085fa9ab43214b03b82b553de28c9b24b4") -- Depot 3869851
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Welcome to the Game III - Tanner Maid Outfit (AppID: 4941970)
addappid(4941970)
addappid(4941970, 1, "a44e6e7025c3873f7405ab5d0c9878adc1cf32f3b559d84f2867d55198ee4661") -- Welcome to the Game III - Tanner Maid Outfit - Depot 4941970
-- Welcome to the Game III - Tanner Cat Outfit (AppID: 4942030)
addappid(4942030)
addappid(4942030, 1, "3c878b07316585fe2d9d4d4f8f2772ea459ca1755b50c20956868620687d3fcf") -- Welcome to the Game III - Tanner Cat Outfit - Depot 4942030
-- Welcome to the Game III - Tanner Mankini Outfit (AppID: 4942040)
addappid(4942040)
addappid(4942040, 1, "3c53df1e1d86b32e509e99b5200696cbe33ff94cdb0d45c148030d8dc0e09dae") -- Welcome to the Game III - Tanner Mankini Outfit - Depot 4942040
-- Welcome to the Game III - Tanner Swimtrunks Outfit (AppID: 4942050)
addappid(4942050)
addappid(4942050, 1, "e145c9a6688d802d4d8670a740d130821881ada9bcf216cb9472e828a67004b3") -- Welcome to the Game III - Tanner Swimtrunks Outfit - Depot 4942050
-- Welcome to the Game III - Tanner Classy Outfit (AppID: 4942060)
addappid(4942060)
addappid(4942060, 1, "2e46dd38af9adeb0b6ecff02645404c10489a92ba4d4713e5d9da14b4c038211") -- Welcome to the Game III - Tanner Classy Outfit - Depot 4942060
