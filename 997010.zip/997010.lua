-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2009550) -- Police Simulator Patrol Officers Urban Terrain Vehicle DLC
addappid(2199030) -- Police Simulator Patrol Officers Compact Police Vehicle DLC
addappid(2210960) -- Police Simulator Patrol Officers Guardian Police Vehicle DLC
addappid(2350410) -- Police Simulator Patrol Officers Highway Patrol Expansion
addappid(2513250) -- Police Simulator Patrol Officers Multipurpose Police Vehicle DLC
addappid(2527820) -- Police Simulator Patrol Officers Surveillance Police Vehicle DLC
addappid(2527830) -- Police Simulator Patrol Officers Warden Police Vehicle DLC
addappid(2893870) -- Police Simulator Patrol Officers Unmarked Police Vehicle Pack
addappid(2893880) -- Police Simulator Patrol Officers Special Police Vehicle Pack 
addappid(3048950) -- Police Simulator Patrol Officers Tropical Taskforce Pack
addappid(3167630) -- Police Simulator Patrol Officers Fast Pursuit Police Vehicle DLC
addappid(3597210) -- Police Simulator Patrol Officers - Season Pass
addappid(3597220) -- Police Simulator Patrol Officers - Vehicle Customization Pack
addappid(3768290) -- Police Simulator Patrol Officers Adventurer Police Vehicle DLC
addappid(3768300) -- Police Simulator Patrol Officers Accident Pack
addappid(3768310) -- Police Simulator Patrol Officers Vanguard Police Vehicle DLC
addappid(3768320) -- Police Simulator Patrol Officers Contraband Expansion
addappid(3924710) -- Police Simulator Patrol Officers East Coast Police Uniform Pack
addappid(3924720) -- Police Simulator Patrol Officers South Atlantic Police Uniform Pack
addappid(3924730) -- Police Simulator Patrol Officers Western Police Uniform Pack