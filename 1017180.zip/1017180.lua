-- MAIN APPLICATION
addappid(1017180, 1, "f794bf137087c34994cfc1b3573ecc9c6b0d04f0290b6cfcc63b12f62b09fca1") -- The Long Drive
-- MAIN APP DEPOTS
addappid(1017181, 1, "244a982ca42ee3d2f9489b8debf008732bea45f9a499101041e26bd0dccfa4ed") -- TheLongDrive
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
