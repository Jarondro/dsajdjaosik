- MAIN APPLICATION
addappid(720250) -- Welcome to the Game II
-- MAIN APP DEPOTS
addappid(720251, 1, "4575e37a7087a13c47b386424bd698373128854437da3e13a133b6cdf247323e") -- Welcome to the Game II Depot
addappid(720252, 1, "a86283e8bc7ba5039aaa31290e78226f9650732e90d65e234217c1c332d96760") -- Welcome to the Game II Mac Depot
