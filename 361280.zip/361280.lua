-- MAIN APPLICATION
addappid(361280) -- Turmoil
-- MAIN APP DEPOTS
addappid(361281, 1, "0f3e5d3968ab0559516621bee8349b5f5a8f651f091fa419d8aadee78cfeb67c") -- Turmoil Content
addappid(361282, 1, "f2ff46e2f1b65bcab5960ce224a5fee831f290cee820939a636a13da0cc1fd8b") -- Turmoil Depot Windows
addappid(361283, 1, "2dd5fdd35a66fd50be6adc97b07ffd9105cca964218b58a451def135037f5e8b") -- Turmoil Depot Linux
addappid(361284, 1, "ddf67ba7f57b52bee876835cb5a9fd96148c0429b7415bad0b087319b9436076") -- Turmoil Depot Mac
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Turmoil Original Soundtrack (AppID: 539310)
addappid(539310)
addappid(539310, 1, "6a3b326bbfcde6dba191a64dc93cbd994c7b7edd834d1cf3cbc314e985b1356b") -- Turmoil Original Soundtrack - Turmoil Original Soundtrack (539310) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(804760) -- Turmoil - The Heat Is On
addappid(3106610) -- Turmoil - Deeper Underground