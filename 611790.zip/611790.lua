-- MAIN APPLICATION
addappid(611790) -- House Party
-- MAIN APP DEPOTS
addappid(611791, 1, "83bbf3421af9c12068fd0d7d85cbaf9d368db80bf05f3233c3887561783af1c5") -- House Party x64
addappid(611799, 1, "05fa356e7c4a3992252ed97b9252a3160401a04fa42abf9d07b8d794631425e4") -- Depot 611799
-- DLCS WITH DEDICATED DEPOTS
-- House Party - Explicit Content Add-On (AppID: 944540)
addappid(944540)
addappid(944540, 1, "df6c415c034e6590623fc12d69f7c5cd0701e5291eb9862d065a1869e642af53") -- House Party - Explicit Content Add-On - House Party - Explicit Content Add-On (944540) Depot
-- House Party - Detective Liz Katz in a Gritty Kitty Murder Mystery Expansion Pack (AppID: 1524910)
addappid(1524910)
addappid(1524910, 1, "dd346023a92ee8c9bbe4ec64f2d883f89077667088448f5637656284c4dcfbc8") -- House Party - Detective Liz Katz in a Gritty Kitty Murder Mystery Expansion Pack - Depot 1524910
-- House Party - Doja Cat Expansion Pack (AppID: 1648810)
addappid(1648810)
addappid(1648810, 1, "d213a830208db1771092e5c6738647e1a5eb7e9bc54425427b1a9d9dc101b3bf") -- House Party - Doja Cat Expansion Pack - Depot 1648810
-- House Party - Halloween Holiday Pack (AppID: 2229630)
addappid(2229630)
addappid(2229630, 1, "c545f2a975f50daee5d68d1a765049dcc1358a95ec2dac81fa934e5268e962d3") -- House Party - Halloween Holiday Pack - Depot 2229630
-- House Party - Winter Holiday Pack (AppID: 2229631)
addappid(2229631)
addappid(2229631, 1, "5f0ece6ad4425255cfdc0c892e2f0c1249138a9b27f6a66bcf3c5cc17e5f97e6") -- House Party - Winter Holiday Pack - Depot 2229631
-- House Party - Business and Pleasure Style Pack (AppID: 2363800)
addappid(2363800)
addappid(2363800, 1, "97ffa85ee5d7abd365a8dd1a437d69df1443fd3607a9a6f6e9a17e70d02a35c3") -- House Party - Business and Pleasure Style Pack - Depot 2363800
-- House Party - Valentines Day Holiday Pack (AppID: 2783130)
addappid(2783130)
addappid(2783130, 1, "de20813392537a16f351523a19c09a06e3a5678e34c3f5ca3ba074f6430d2131") -- House Party - Valentines Day Holiday Pack - Depot 2783130
-- House Party - Supporter Pack (AppID: 3487780)
addappid(3487780)
addappid(3487780, 1, "9a33d639ab8987b993e7cbe0900368481213498a6234eccf801e5336f5f9f57e") -- House Party - Supporter Pack - Depot 3487780
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(4055790) -- DLC 4055790 (unreleased)