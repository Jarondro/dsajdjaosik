-- MAIN APPLICATION
addappid(1350650) -- FreshWomen - Season 1
-- MAIN APP DEPOTS
addappid(1350651, 1, "cf1b50f8d8ab2dbf3f7cda0c9962aaf6ecaf1dfa64dd60809e3b3c2dcf94ac31") -- Depot 1350651
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(2691310) -- FreshWomen - Season 2 (unreleased)