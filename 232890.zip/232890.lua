-- MAIN APPLICATION
addappid(232890, 1, "c80ec5facf2431a63df7bcc10e6c94d6652a3a5ddd87da0c21f3eb8d491b2e94") -- Stronghold Crusader 2
-- MAIN APP DEPOTS
addappid(232891, 1, "5303b0708e931190fb49564a4799cf22bcb7d9c3af92a6cb9cba245078ffabbd") -- Stronghold Crusader 2 Content
addappid(232892, 1, "c77c58fa143012aebf55ef395915ce7907cc423085c16ff94739c24d3b948781") -- Stronghold Crusader 2 English
addappid(232893, 1, "fa80923bd352542445ed345bd712a51a4807d86b1413453d5b62a38da3fdbe13") -- Stronghold Crusader 2 French
addappid(232894, 1, "591e5fda1d1be33518546ea04b471fbc9769e2953287202ba17ffdd0c3d1d76e") -- Stronghold Crusader 2 German
addappid(232895, 1, "f4c8d400c95216f41478bf25ce60b7851eac55906013162b053d01837fbd9dba") -- Stronghold Crusader 2 Italian
addappid(232896, 1, "421795c09f7a5c397ddf67797f9964c439e0ff3b79e2310d18f02d44fc6fbaf2") -- Stronghold Crusader 2 Spanish
addappid(232897, 1, "476d7407d2f4698087e7e09bf681d7e131633e3b27003144b1dd9463a138a4bc") -- Stronghold Crusader 2 Russian
addappid(232898, 1, "8f0f58e73de62be971b6f9a1896aece39f56cbfe20f6064b51016ca07dd8f071") -- Stronghold Crusader 2 Polish
addappid(232899, 1, "d1453edd1281cf8533839e1e86f5c3b5619f2d6bcd9ac2142d18b6714c7427e5") -- Stronghold Crusader 2 Brazilian
addappid(232900, 1, "cde2d5e3d46c2d3b78390f0bef405c43c34b9a1b17f6843c6bda72f6db573652") -- Stronghold Crusader 2 Japanese
addappid(232901, 1, "04aef7671493ba96ac46cdfd372707d00e062de4943d92461ba447347943d7c0") -- Stronghold Crusader 2 Simplified Chinese
addappid(232902, 1, "c5aa592182e5be1e3e1fe0bbdae7b999a4c18cae15c377a3c7889c0740acc664") -- Stronghold Crusader 2 Trailer
-- DLCS WITH DEDICATED DEPOTS
-- Pre-order Delivering Justice mini-campaign (AppID: 317590)
addappid(317590)
addappid(317590, 1, "3ac2769ca3ae3a11f2a123dbf40f4c8abeae95d7cf11d021fd11468d0a870906") -- Pre-order Delivering Justice mini-campaign - Pre-order "Delivering Justice" mini-campaign (317590) Depot
-- Pre-order Freedom Fighters mini-campaign (AppID: 317591)
addappid(317591)
addappid(317591, 1, "025b953b6c945876b7b36e5e6430d32962b7c938f9417c7f91709181cc90fbc0") -- Pre-order Freedom Fighters mini-campaign - Pre-order "Freedom Fighters" mini-campaign (317591) Depot
-- Stronghold Crusader 2 - Official Soundtrack (AppID: 319790)
addappid(319790)
addappid(319790, 1, "e9b7215aeb125ca1be5c1d23de9e245dcb8c5213a455cd8211d1bc258aa93c93") -- Stronghold Crusader 2 - Official Soundtrack - Stronghold Crusader 2 - Official Soundtrack (319790) Depot
-- Stronghold Crusader 2 - Art Book (AppID: 319800)
addappid(319800)
addappid(319800, 1, "48297213d5d747962a588dc15cc9bb746034b40c216a45c03c2b4dac3bbff387") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book (319800) Depot
addappid(319801, 1, "391876832556bf77e6b541c9747f6d6ae1904db5de020acb48cf84c0e39c2501") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319802, 1, "71200c3adf6bec10e3d68338bd928e0bf124cafa31ddac465aac62dcc880a9db") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319803, 1, "3908c0ce7dc09335a517c635a73c589f9afbcea745ee8d740822c97a692b3bab") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319804, 1, "b09924680e4382d633fbecae309389722c33266b30c26075352293a97f2b64ed") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319805, 1, "6c97d0416b88ea90bc69181c097c3703bf07c6defd4c79536993151d19b7c642") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319806, 1, "5472f319c4a2c999de5353cba90c9467132fc1b2a16c9e0a4115da906a151304") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319807, 1, "481eade6421d06024ec69e4bd670b681c1ed395a7e1ba7b2ee12a231c8ab4cfa") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
addappid(319808, 1, "067cf79d636556eab7e49f009b7226d81a7ff3993da05b48d0ddb61deef4b0f7") -- Stronghold Crusader 2 - Art Book - Stronghold Crusader 2 - Art Book
-- Stronghold Crusader 2 - The Princess  The Pig (AppID: 348990)
addappid(348990)
addappid(348990, 1, "dd66ee24172beb24518bcdf14d5bfb07c64d60ba9ac32d6865867e39053062fd") -- Stronghold Crusader 2 - The Princess  The Pig - Stronghold Crusader 2 - The Princess & The Pig (348990) Depot
-- Stronghold Crusader 2 - The Emperor  The Hermit (AppID: 349000)
addappid(349000)
addappid(349000, 1, "fc25db7db9763eb60fdaf34163c1fdda6bca6aed3fa7719b50243f97ea280e4f") -- Stronghold Crusader 2 - The Emperor  The Hermit - Stronghold Crusader 2 - The Emperor & The Hermit (349000) Depot
-- Stronghold Crusader 2 The Templar  The Duke (AppID: 349230)
addappid(349230)
addappid(349230, 1, "97799b97a6b6513db7428159db8d9843ef26f784c4929b1ed1076fa55fb7d4bc") -- Stronghold Crusader 2 The Templar  The Duke - Stronghold Crusader 2: The Templar & The Duke (349230) Depot
-- Stronghold Crusader 2 The Jackal  The Khan (AppID: 349231)
addappid(349231)
addappid(349231, 1, "aaebd926a5c296b0372d8a6c72ae40e5077491a712a0e7109daab9602d3b72b7") -- Stronghold Crusader 2 The Jackal  The Khan - Stronghold Crusader 2: The Jackal & The Khan (349231) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(316470) -- Stronghold Crusader 2 - Registration Bonus
addappid(317592) -- Pre-order bonus shields
addappid(412590) -- Stronghold Crusader 2 - Ultimate Edition Shields