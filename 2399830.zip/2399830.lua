-- DLCS WITH DEDICATED DEPOTS
-- ARK The Center Ascended (AppID: 2827030)
addappid(2827030)
addappid(2827030, 1, "ca47571a30440cd0d827bee6a57a945cf56d25fd4dbc19435d608994b021302a") -- ARK The Center Ascended - Depot 2827030
-- ARK Scorched Earth Ascended (AppID: 2849450)
addappid(2849450)
addappid(2849450, 1, "06a4aa068a1a3940e0c7eff34508ad6474806f4b46520ef9ea12b4b7f77a3d0e") -- ARK Scorched Earth Ascended - Depot 2849450
-- ARK Aberration Ascended (AppID: 3059650)
addappid(3059650)
addappid(3059650, 1, "84b1a413568c28ea0226bbd983fbf08741ead907cc7cd9cdd447056405850bd2") -- ARK Aberration Ascended - Depot 3059650
-- ARK Extinction Ascended (AppID: 3349320)
addappid(3349320)
addappid(3349320, 1, "e0cbc7f932b6b5ffa7e36b9fe8ccf5b2317d5073f520b8a357a7bb8e32d7a181") -- ARK Extinction Ascended - Depot 3349320
-- ARK Astraeos (AppID: 3483400)
addappid(3483400)
addappid(3483400, 1, "8f2706fe64f86426091cbb9a23dedbc3ec0c53a78877abb9b549edded5f436ea") -- ARK Astraeos - Depot 3483400
-- ARK Lost Colony (AppID: 3583650)
addappid(3583650)
addappid(3583650, 1, "e7d5b3c53aabefd8ec1f24038e55c6e614c31d7e5c6237c443e83c4eb1fc5a83") -- ARK Lost Colony - Depot 3583650
-- ARK Ragnarok Ascended (AppID: 3675020)
addappid(3675020)
addappid(3675020, 1, "5028ee914f2c74aba43cc91d7f2f49fd5ad0ec96dcb76372ed26deec22b0e88c") -- ARK Ragnarok Ascended - Depot 3675020
-- ARK Valguero Ascended (AppID: 3982310)
addappid(3982310)
addappid(3982310, 1, "184547e9bf5059e77f7971af6c7a064a5a7eb7a76a3b210fbeed6ebb00df991c") -- ARK Valguero Ascended - Depot 3982310
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2881150) -- ARK Bobs Tall Tales
addappid(2972680) -- ARK Fantastic Tames - Pyromane
addappid(3282470) -- ARK Fantastic Tames - Dreadmare
addappid(3571730) -- ARK Animated Series 109-Costumes Pack
addappid(3720100) -- ARK Lost Colony Expansion Pass
addappid(3720200) -- ARK Fantastic Tames - Drakelings
addappid(3982300) -- ARK Fantastic Tames - Elderclaw