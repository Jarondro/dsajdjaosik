-- MAIN APPLICATION
addappid(2582140) -- Seafarer: The Ship Sim
-- MAIN APP DEPOTS
addappid(2582141, 1, "f40d0c88571b28f840178b77be55334a2e94510b18e939af7c2da27f9d855b4e") -- Depot 2582141
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4213410) -- Seafarer The Ship Sim - Supporter DLC