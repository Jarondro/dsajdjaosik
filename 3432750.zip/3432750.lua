-- MAIN APPLICATION
addappid(3432750) -- Laundering Simulator
-- MAIN APP DEPOTS
addappid(3432751, 1, "7532e8278f37755820a38828f8d2d43429580561facaed6b5f3e422c6ac7b201") -- Depot 3432751
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
