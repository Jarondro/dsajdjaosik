-- MAIN APPLICATION
addappid(503560, 1, "1d20d01c44c03cf7637ff1404e501cadb70dcab30037a9d526e843a9476015d0") -- 911 Operator
-- MAIN APP DEPOTS
addappid(503561, 1, "a95779f4bbf8535d668e35bc55d3a4853a05bd3cb36bf520cbefae7f769577bc") -- 911 Operator Content
addappid(503562, 1, "15534f873ff89549daf55ded5d38983103075108cdf3646e361f02d098d50d64") -- 911 Operator Mac
-- DLCS WITH DEDICATED DEPOTS
-- 911 Operator - Every Life Matters (AppID: 580731)
addappid(580731)
addappid(580731, 1, "fee91c3513a59aa5e39cee4557b7d09fe5d0263d76bbfbcb49d48dc83b5f3b02") -- 911 Operator - Every Life Matters - 911 Operator - Every Life Matters (580731) Depot
-- 911 Operator - Search  Rescue (AppID: 606971)
addappid(606971)
addappid(606971, 1, "3b0cf0bf7d79345c130f87adb6b81ec3c85d0c81672c64a86958fc41dde8c2a8") -- 911 Operator - Search  Rescue - 911 Operator - Search & Rescue (606971) - magazyn zawartości
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(580730) -- 911 Operator - Special Resources
addappid(606970) -- 911 Operator - First Response