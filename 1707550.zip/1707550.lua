-- MAIN APPLICATION
addappid(1707550) -- Granny 3
-- MAIN APP DEPOTS
addappid(1707551, 1, "f4410bc90ecd9cb0290cb8844063c55ea74deb00a789cd359633fd0790a6f742") -- Granny 3 Content
