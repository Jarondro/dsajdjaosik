-- MAIN APPLICATION
addappid(1850740, 1, "3119293ca8283e74497a588b64ec4fa7fc4494ec00ce6c0332d1ecc13bf6b081") -- Ghost Watchers
-- MAIN APP DEPOTS
addappid(1850741, 1, "a830d518fb69395dfac8536575b35f141dc0ccb74f84bb08dad20556b7050c1e") -- Depot 1850741
-- DLCS WITH DEDICATED DEPOTS
-- Ghost Watchers - Supporter Pack (AppID: 3876090)
addappid(3876090)
addappid(3876090, 1, "3d86a638743c1845580d2fe8dfbba088e48712581c1f040ad5745c4c590af9ad") -- Ghost Watchers - Supporter Pack - Depot 3876090
