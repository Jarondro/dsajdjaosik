-- MAIN APPLICATION
addappid(12120) -- Grand Theft Auto: San Andreas
-- MAIN APP DEPOTS
addappid(12123, 1, "b6246a66a369124f35879ade188971257e9827d14f178abace4d759001e6191a") -- Grand Theft Auto San Andreas content 3
addappid(12122, 1, "eaa6ab82216553e3e53f1de147e88096b378cbc8b0cd488fd2c4d047ff263389") -- Grand Theft Auto San Andreas content 2
addappid(12121, 1, "d89825855fd6f4b802378b6110effadaea8db612d89de6cf00f75dc92f898bf0") -- Grand Theft Auto San Andreas content
addappid(12124, 1, "020b11d09c31b51ddf1f3de13d5a2e420501f31de6638914b7ecfee4b15e3fc8") -- gtasa_lv_content
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
