-- MAIN APPLICATION
addappid(3024040, 1, "aaa00f3f7864c4619f9fc02c864424ca1a58a6d542b078c5284071c63dac2fd5") -- Stronghold Crusader: Definitive Edition
-- MAIN APP DEPOTS
addappid(3024041, 1, "e6dbd7bb633ba99b181c4f2b78584081739b918d60bb52b8a6414f7ec6a20d68") -- Depot 3024041
addappid(3024042, 1, "cee5bb3c6821879a73a463e874470c6cf6291ca212a81e7a2c8b8a93c1972c05") -- Depot 3024042
addappid(3024043, 1, "4c1134b41a5a46469b7d2243d9186953e7a488baef357d51dc9eb396a4cc46f6") -- Depot 3024043
addappid(3024044, 1, "81cc4f80b71ad448ede20a2640db15b2811e3e12b6d22d0d546ce3505642589e") -- Depot 3024044
addappid(3024045, 1, "a561c929568d6348a419ecaceb98bb546ff2a2627a3961c87edc23dcc4e3cfef") -- Depot 3024045
addappid(3024046, 1, "425cd1425f5e185c8d4f3fe53fba1cda0ea7879d02467283110e3e3acc7f23e3") -- Depot 3024046
addappid(3024047, 1, "57c1a0ce1a0390ec70df63de6c6f7c065da56e05c83d0e54e46eeb292224614c") -- Depot 3024047
addappid(3024048, 1, "7bb3a4737514c91349f81cd0318b3e66b5dfcbb4698fcd09a6eac88916dcb5fa") -- Depot 3024048
addappid(3024049, 1, "7e215232c33f220ef09930ad2e3c6948ec70f2d14d33d7fef41d56e61e0db245") -- Depot 3024049
addappid(3027330, 1, "d91fb801febe39725557fdfcf82946ad7884e0b4e5aa7630522dea88f5d96212") -- Depot 3027330
addappid(3027331, 1, "c43237459cf4603c8f4f70918b33e291d077819defebef4c0746273b8e14241e") -- Depot 3027331
addappid(3027332, 1, "4117bd075ae087d0ec72666d3a234a004490138e87f87e05514f79b295d2e649") -- Depot 3027332
addappid(3027333, 1, "371d29f78230e1fcec6e970770877372b517071b9134f84cdb3aa69a4f1b23e6") -- Depot 3027333
addappid(3027334, 1, "53d9efd5c358b53006191a10fa895c206ad769ab309015ea6aa42784bbcf0804") -- Depot 3027334
addappid(3027335, 1, "7b0984c1f09baeb8b0d6368f28852f5151d161085f076702f75f8a0f8e86ddd6") -- Depot 3027335
addappid(3027336, 1, "b5eb09168ec6aa689e7b1b7ec0f81ddffc813ac57951a4ecc14329d86b96adcc") -- Depot 3027336
addappid(3027337, 1, "43a08c7dc38ee35c9749cf489fd36dd27a0abd54bc10a88631db9064bef31cd7") -- Depot 3027337
addappid(3027338, 1, "72e0e7c4eac3cd13bef785415306f8aa6502570479395ed788e11a06462776eb") -- Depot 3027338
addappid(3027339, 1, "28702311291eea464ba64a8380e75df96855073b2599b1e6209d36c6f4aa28b5") -- Depot 3027339
addappid(3027340, 1, "62cf5a8053dee99101a84f5ace1d5332fa3ca9aa49204745f9eb9cff406a3594") -- Depot 3027340
addappid(3027341, 1, "b706ae3f59d5b4c9affb04e4e69958495620a4209c5b546bd1bea638829c7fc7") -- Depot 3027341
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3030340) -- Stronghold Crusader Definitive Edition - The Canary  The Trader
addappid(3030350) -- Stronghold Crusader Definitive Edition - The Sergeant  The Lioness
addappid(4483540) -- Stronghold Crusader Definitive Edition - Baldwin  Bullseye
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3030340) -- Depot 3030340 (empty depot)
-- addappid(3030350) -- Depot 3030350 (empty depot)