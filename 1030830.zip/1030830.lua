-- MAIN APPLICATION
addappid(1030830) -- Mafia II: Definitive Edition
-- MAIN APP DEPOTS
addappid(1030831, 1, "32530b6455aff62129bdca96b7eade4476d7d5aa76a6233563dca1ccad754475") -- RYE Content
