-- MAIN APPLICATION
addappid(1332010) -- Stray
-- MAIN APP DEPOTS
addappid(1332011, 1, "e61bdb7aeaccc075f69345348178ac158f107c1433c9a28743797407dc335e4c") -- Depot 1332011
addappid(1332012, 1, "b0288825cade4cf4aceb6bf5a2e523e0c94028b45fe8095fea1f7e04e26f5728") -- Depot 1332012
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
