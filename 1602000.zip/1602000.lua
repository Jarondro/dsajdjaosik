-- 1602000's Lua and Manifest Created by Hubcap Manifest
-- Hotel Architect
-- Created: June 04, 2026 at 12:52:22 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1602000, 1, "a17e0c50e72b96a8be98c8d7702bb79628b78e3d9532b1cc3bf7b34949259636") -- Hotel Architect
-- MAIN APP DEPOTS
addappid(1602001, 1, "0eae087f0db9be78952d7fae0ef01ab55a34cc7d8bae7f18ccc3379d89476fe7") -- Depot 1602001
setManifestid(1602001, "5583622494334720593", 1665460529)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)