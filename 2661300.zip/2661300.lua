-- MAIN APPLICATION
addappid(2661300, 1, "b327d3f0e0a2c4b9cdcf82f361f1c231a8745bb2cc80eb767850907427bfa346") -- Grounded 2
-- MAIN APP DEPOTS
addappid(2661301, 1, "cac026f4758d6992ff85de08375749a662b82dc6517be7dc72368060eca7427d") -- Depot 2661301
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Grounded 2 Digital Artbook  Soundtrack (AppID: 3784940)
addappid(3784940)
addappid(3784940, 1, "6843207657f513fdac03f7aaeaf83190c1176e552d92aa410f91d0afdb8e220b") -- Grounded 2 Digital Artbook  Soundtrack - Depot 3784940
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3788090) -- Grounded 2 Founders Pack