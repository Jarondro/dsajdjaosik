-- 736260's Lua and Manifest Created by Morrenus
-- Baba Is You
-- Created: September 28, 2025 at 23:49:30 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(736260) -- Baba Is You
-- MAIN APP DEPOTS
addappid(736261, 1, "410c70fef86e8f5cf276b33125a7ea483ea83d86e1d68441996f1fc7c100f660") -- Baba Is You Content
setManifestid(736261, "8815489357607334049", 111328718)
addappid(736262, 1, "4d0d21a1ef7fa4d22ccc1a9fad105d3fe1a3d0974ec3bc2737b6df22cb456f6f") -- Baba Is You OSX
setManifestid(736262, "2616255736580287154", 109964067)
addappid(736263, 1, "ecd6193b5c2ad8855abf4d383ed3d8cc1cc36f2caffa2cd8e2826fa7bea89cc5") -- Baba Is You Linux
setManifestid(736263, "416776647528072709", 124697966)