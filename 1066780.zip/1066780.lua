-- MAIN APPLICATION
addappid(1066780, 1, "5cbef276a4f684c035e26bb7ed808628e29470e6c280f9b855af0dc63aa48553") -- Transport Fever 2
-- MAIN APP DEPOTS
addappid(1066781, 1, "97acfe79f2e374b3c99a226e64e795e1f8756c100e5305a43e3f2565738e9c96") -- Transport Fever 2 Content
addappid(1066782, 1, "146991dac876ce6da2f849a162e6c4c2f9921c476c7423d763ae038b3663e977") -- Transport Fever 2 Windows
addappid(1066783, 1, "272c5d50dc85d20404598ae67e60e8e17e124eb84bd3a4069cbe1b3da782fbf3") -- Transport Fever 2 Mac
addappid(1066784, 1, "7ec42bea502955c03b97608b6232c84771aaca49e03eb847171d8b331c731c7a") -- Transport Fever 2 Linux
addappid(1066785, 1, "e50f40854a0c04b79c841dc8752530195300f6e7cec6ad3ee04cf9962a5214a8") -- Model Editor Windows
addappid(1066786, 1, "d29d4adebb2f5c765d00194ff6e326e66ca6c74abd2c0fc25d515c328df6b17a") -- Model Editor Mac
addappid(1066787, 1, "b0c7a3216014db8199b54e378082a4e59e50637f9e858af074569cfeaf65a920") -- Model Editor Linux
-- DLCS WITH DEDICATED DEPOTS
-- Transport Fever 2 Deluxe Upgrade Pack (AppID: 2195610)
addappid(2195610)
addappid(2195610, 1, "fca430039a85874f8c4abc66e099cf739d39a966ba8c57a8c8d3f00127c6c1d9") -- Transport Fever 2 Deluxe Upgrade Pack - Depot 2195610
-- Transport Fever 2 Early Supporter Pack (AppID: 2195611)
addappid(2195611)
addappid(2195611, 1, "3178f15ef9b12ebb5eb703e9f7b4889a478cbd73eb14639adbcf22940a38b0fb") -- Transport Fever 2 Early Supporter Pack - Depot 2195611
