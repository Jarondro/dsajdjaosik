-- MAIN APPLICATION
addappid(2104890) -- RoadCraft
-- MAIN APP DEPOTS
addappid(2104891, 1, "7aae8e21e13a76d7d261e23592399805131dbb2dc4678b5c40b335e6f131b3a7") -- Depot 2104891
-- DLCS WITH DEDICATED DEPOTS
-- RoadCraft - 4K Texture Pack (AppID: 3510890)
addappid(3510890)
addappid(3510890, 1, "fed6ac5a7ee3d94e10e924fe19f30acfcbcfdb56a5835b080efede124d44b8a0") -- RoadCraft - 4K Texture Pack - Depot 3510890
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2806770) -- RoadCraft  Aramatsu Bowhead 30T
addappid(3470710) -- RoadCraft  Invictus Type A Scout
addappid(3470720) -- RoadCraft - Rebuild DLC
addappid(3470730) -- RoadCraft - Rebuild Expansion
addappid(4124160) -- RoadCraft  Timberworks Pack