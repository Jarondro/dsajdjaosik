-- MAIN APPLICATION
addappid(620980, 1, "c65a385847c7f919a9bc057f573b6b3b7f748400ef0edc93a7ffdcad324e6e0c") -- Beat Saber
-- MAIN APP DEPOTS
addappid(620981, 1, "9ed35e10891998ba515f2e19a33976b3ca2d39e22bdb82245eaf046a37d48805") -- Beat Saber Content
-- DLCS WITH DEDICATED DEPOTS
-- Beat Saber - Aero Chord - Boundless (AppID: 1048870)
addappid(1048870)
addappid(1048870, 1, "fe2a7aa8ca1be8a507ed568f4744404b7bc3ee792ad757273c9494cec2c9f695") -- Beat Saber - Aero Chord - Boundless - Beat Saber DLC (1048870) Depot
-- Beat Saber - Pegboard Nerds - Emoji VIP (AppID: 1048871)
addappid(1048871)
addappid(1048871, 1, "b19f825b81102d95de35829ee6460ab97531ab40d38744bfe7ee4455b20b98be") -- Beat Saber - Pegboard Nerds - Emoji VIP - Beat Saber DLC (1048871) Depot
-- Beat Saber - Tokyo Machine - EPIC (AppID: 1048872)
addappid(1048872)
addappid(1048872, 1, "82f270f13f36ff49daeecea9ec9d96aa07b02c773adc42173247c843d0ee8127") -- Beat Saber - Tokyo Machine - EPIC - Beat Saber DLC (1048872) Depot
-- Beat Saber - Muzzy - Feeling Stronger (AppID: 1048873)
addappid(1048873)
addappid(1048873, 1, "39ed428d0f2ccc1e32aa9af86f989939b975641c89bf579fbede5a38ffad1bf5") -- Beat Saber - Muzzy - Feeling Stronger - Beat Saber DLC (1048873) Depot
-- Beat Saber - RIOT - Overkill (AppID: 1048874)
addappid(1048874)
addappid(1048874, 1, "496f28e037161e535e26c7712b0613439bf1a188d03efc14b61c131873214767") -- Beat Saber - RIOT - Overkill - Beat Saber DLC (1048874) Depot
-- Beat Saber - Rogue - Rattlesnake (AppID: 1048875)
addappid(1048875)
addappid(1048875, 1, "77a7aa8a7e3fcd95c1870dacad1be2121d837338e93820df710e16463e5e529e") -- Beat Saber - Rogue - Rattlesnake - Beat Saber DLC (1048875) Depot
-- Beat Saber - Stonebank - Stronger (AppID: 1048876)
addappid(1048876)
addappid(1048876, 1, "932aeb970c6d75812d576c0473e1cd0cda8ab6d9fd153b6bc8b644aaf2d54134") -- Beat Saber - Stonebank - Stronger - Beat Saber DLC (1048876) Depot
-- Beat Saber - Kayzo - This Time (AppID: 1048877)
addappid(1048877)
addappid(1048877, 1, "74705c9bacd6f4d6d940c18ca54a8d350cfce9f98fca37128e4eb3c0a20891ee") -- Beat Saber - Kayzo - This Time - Beat Saber DLC (1048877) Depot
-- Beat Saber - Tristam - Till Its Over (AppID: 1048878)
addappid(1048878)
addappid(1048878, 1, "ade04ddfafc10ff3ac778a93fd7187cf03b674737cf8fbcebf7281e98815fc96") -- Beat Saber - Tristam - Till Its Over - Beat Saber DLC (1048878) Depot
-- Beat Saber - Feint - We Wont Be Alone (AppID: 1048879)
addappid(1048879)
addappid(1048879, 1, "bd8eeea3496e9df99455fbd5ef8685e0b12aad5a9be99aefe25043808463164d") -- Beat Saber - Feint - We Wont Be Alone - Beat Saber DLC (1048879) Depot
-- Beat Saber - Imagine Dragons - Bad Liar (AppID: 1099560)
addappid(1099560)
addappid(1099560, 1, "096a63ed30b5fd67b4d7de07131b3bcaa7ae5fea208486ee80f126f83fa4c9b1") -- Beat Saber - Imagine Dragons - Bad Liar - P2S1 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Believer (AppID: 1099561)
addappid(1099561)
addappid(1099561, 1, "77435e6ef6278fe9545d0222245e615a3409506054319a23d53c79496ccddf56") -- Beat Saber - Imagine Dragons - Believer - P2S2 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Digital (AppID: 1099562)
addappid(1099562)
addappid(1099562, 1, "7bf1ce2aebe26324990ba096700ae2c0d7acf5e51e8e4e238d9488b148cdd99c") -- Beat Saber - Imagine Dragons - Digital - P2S3 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Its Time (AppID: 1099563)
addappid(1099563)
addappid(1099563, 1, "08cb6064c91c1a0aa3c0333fceec4e6d2ac54e9d468cb0635b17d99463ad9f4c") -- Beat Saber - Imagine Dragons - Its Time - P2S4 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Machine (AppID: 1099580)
addappid(1099580)
addappid(1099580, 1, "c54837f4b76c8f983c35468170bde05c8865935255fa8acb27f1a50d221a46e4") -- Beat Saber - Imagine Dragons - Machine - P2S5 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Natural (AppID: 1099581)
addappid(1099581)
addappid(1099581, 1, "f34871b9b43f5092c20f76aeca3609872db33fb28ebbf43018d8e0cf74d791d4") -- Beat Saber - Imagine Dragons - Natural - P2S6 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Radioactive (AppID: 1099582)
addappid(1099582)
addappid(1099582, 1, "5b502a81735b8d79e123c4c1ff9aeb52d22a796b8dd035701c8e492e71b17545") -- Beat Saber - Imagine Dragons - Radioactive - P2S7 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Thunder (AppID: 1099583)
addappid(1099583)
addappid(1099583, 1, "045297eb4f7eb3cf7f65f26fba8a8a038aa1d00845e7682d33e873e9b55cc055") -- Beat Saber - Imagine Dragons - Thunder - P2S8 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Warriors (AppID: 1099584)
addappid(1099584)
addappid(1099584, 1, "c65cc4cbfb6e115114eda75937ee6a28a23646f9957f18d31392b71de3388247") -- Beat Saber - Imagine Dragons - Warriors - P2S9 Depot (Beat Saber DLC)
-- Beat Saber - Imagine Dragons - Whatever It Takes (AppID: 1099585)
addappid(1099585)
addappid(1099585, 1, "30f874d0272ec9de4754cd971e16a71fb01b33963b29936e111ca7f2542b5b6c") -- Beat Saber - Imagine Dragons - Whatever It Takes - P2S10 Depot (Beat Saber DLC)
-- Beat Saber - Panic at the Disco - The Greatest Show (AppID: 1167660)
addappid(1167660)
addappid(1167660, 1, "92c8bc073f38d6c50af7ed9dc052247a45073b4c3ae868c6a18068df989b6aa8") -- Beat Saber - Panic at the Disco - The Greatest Show - Beat Saber - Panic! at the Disco - The Greatest Show Depot
-- Beat Saber - Panic at the Disco - Victorious (AppID: 1167661)
addappid(1167661)
addappid(1167661, 1, "c7c59cb4e01df7008e2d584a4867796e5d41aa6df05f34a5a3e5d9c5dc2d5f7f") -- Beat Saber - Panic at the Disco - Victorious - Beat Saber - Panic! at the Disco - Victorious Depot
-- Beat Saber - Panic at the Disco - Emperors New Clothes (AppID: 1167662)
addappid(1167662)
addappid(1167662, 1, "aea87c47c81f65819bafc61ac4e13282e407167b1f4a2a9ad055cb318fccc0c0") -- Beat Saber - Panic at the Disco - Emperors New Clothes - Beat Saber - Panic! at the Disco - Emperor's New Clothes Depot
-- Beat Saber - Panic at the Disco - High Hopes (AppID: 1167663)
addappid(1167663)
addappid(1167663, 1, "cb0a1189e7401dd3ad3510c0067234e129f7614e4c67e4fcf7cd0e047685bb68") -- Beat Saber - Panic at the Disco - High Hopes - Beat Saber - Panic! at the Disco - High Hopes Depot
-- Beat Saber - Tokyo Machine  PLAY (AppID: 1181770)
addappid(1181770)
addappid(1181770, 1, "f1721ab76836bd427184cd59d6568ed1ce4e8be1306940a7a518123ee7879e6b") -- Beat Saber - Tokyo Machine  PLAY - P4S1 Depot
-- Beat Saber - Stephen Walking  Glide (AppID: 1181771)
addappid(1181771)
addappid(1181771, 1, "e52725b124f2ad782ebe1aaf97bd154cac2f29e5e30eb7cff863ae03acd7cf0d") -- Beat Saber - Stephen Walking  Glide - P4S2 Depot
-- Beat Saber - Slushii  LUV U NEED U (AppID: 1181772)
addappid(1181772)
addappid(1181772, 1, "042f1baeeda071002406c8cc24575f3bbd3d8c2afff17d6cf8734188673e5a8b") -- Beat Saber - Slushii  LUV U NEED U - P4S3 Depot
-- Beat Saber - Tokyo Machine  ROCK IT (AppID: 1181773)
addappid(1181773)
addappid(1181773, 1, "d9e4415393d0299c24164f2c1ca7c7f98e8ce1a4c8b0ee592dd0caa4b0ffc82f") -- Beat Saber - Tokyo Machine  ROCK IT - P4S4 Depot
-- Beat Saber - Dion Timmer  Shiawase (AppID: 1181774)
addappid(1181774)
addappid(1181774, 1, "cddb39d5e07ec2b224cb225ae5b5a3d531d23d146637185ea9e1a208b517395d") -- Beat Saber - Dion Timmer  Shiawase - P4S5 Depot
-- Beat Saber - Slushii  Dion Timmer  Test Me (AppID: 1181775)
addappid(1181775)
addappid(1181775, 1, "d8765c7f5608cdd4ec398d1325efa4d3bbf2c6406e6a12054ace256bf65d6d85") -- Beat Saber - Slushii  Dion Timmer  Test Me - P4S6 Depot
-- Beat Saber - Green Day - American Idiot (AppID: 1209130)
addappid(1209130)
addappid(1209130, 1, "01676922ef24740225c6f001c904293e069f540c54fb2c6ebdf45ac4e8bd6194") -- Beat Saber - Green Day - American Idiot - Beat Saber - Green Day - American Idiot Depot
-- Beat Saber - Green Day - Father of All... (AppID: 1209131)
addappid(1209131)
addappid(1209131, 1, "f01575ce876d2a2cf949ef8c005340db7332d306a8fd963e373e26bf219dee06") -- Beat Saber - Green Day - Father of All... - Beat Saber - Green Day - Father of All... Depot
-- Beat Saber - Green Day - Boulevard Of Broken Dreams (AppID: 1209132)
addappid(1209132)
addappid(1209132, 1, "bde148d51e0bb9b79ed4f412e8d65af6d913d0f2b4d4696cbf18a3b19805a14a") -- Beat Saber - Green Day - Boulevard Of Broken Dreams - Beat Saber - Green Day - Boulevard Of Broken Dreams Depot
-- Beat Saber - Green Day - Holiday (AppID: 1209133)
addappid(1209133)
addappid(1209133, 1, "9525f32f3513219eb987b8dee36dfd7ef93282b4ea2e2c180ecfc1424123ee85") -- Beat Saber - Green Day - Holiday - Beat Saber - Green Day - Holiday Depot
-- Beat Saber - Green Day - Fire, Ready, Aim (AppID: 1209134)
addappid(1209134)
addappid(1209134, 1, "a6b682362e8ca572883d8fa7a9cbe5d675bc71e821a6ebd528d8645969a1c4ab") -- Beat Saber - Green Day - Fire, Ready, Aim - Beat Saber - Green Day - Fire, Ready, Aim Depot
-- Beat Saber - Green Day - Minority (AppID: 1209135)
addappid(1209135)
addappid(1209135, 1, "565b083b62aafc39f2569417caa49a45488e107a239386fd3c3efed82af7e49d") -- Beat Saber - Green Day - Minority - Beat Saber - Green Day - Minority Depot
-- Beat Saber - Sid Tipton  Timbaland - Has A Meaning (AppID: 1267590)
addappid(1267590)
addappid(1267590, 1, "2b6525f5172a2b5e10b4704c139ca00426336c106e01e3fe64b4bbd0b6af3628") -- Beat Saber - Sid Tipton  Timbaland - Has A Meaning - Beat Saber - Sid Tipton & Timbaland - Has A Meaning Depot
-- Beat Saber - Kaydence  Timbaland - Dumb Thingz (AppID: 1267591)
addappid(1267591)
addappid(1267591, 1, "de0d39aee1dde8aac67b6db5304d3f5517765a36aeff270e6de6e0f43e2fa735") -- Beat Saber - Kaydence  Timbaland - Dumb Thingz - Beat Saber - Kaydence & Timbaland - Dumb Thingz Depot
-- Beat Saber - Wavezswavesz - While Were Young (AppID: 1267592)
addappid(1267592)
addappid(1267592, 1, "3adff218a7b385dcbc90f797a2686fbbf89a788bfc0ec795296b475f6d451c3d") -- Beat Saber - Wavezswavesz - While Were Young - Beat Saber - Wavezswavesz - While We’re Young Depot
-- Beat Saber - Nash Overstreet, Karra  Common Strangers - What I Like (AppID: 1267593)
addappid(1267593)
addappid(1267593, 1, "01a00a43a8823de8c38fe8fcf6a09ce3398123d3a1fe9834e1cccaba00977062") -- Beat Saber - Nash Overstreet, Karra  Common Strangers - What I Like - Beat Saber - Nash Overstreet, Karra & Common Strangers - What I Like Depot
-- Beat Saber - Bruno Martini  Timbaland - Famous ft. Jake Davis (AppID: 1267594)
addappid(1267594)
addappid(1267594, 1, "c1236da8709c73531b973df64370fd633e7a0fba5b6268620f58cfc61114075f") -- Beat Saber - Bruno Martini  Timbaland - Famous ft. Jake Davis - Beat Saber - Bruno Martini & Timbaland - Famous ft. Jake Davis Depot
-- Beat Saber - Linkin Park - Bleed It Out (AppID: 1375360)
addappid(1375360)
addappid(1375360, 1, "65d6b7583041ab4e1d608f0dd242fdf338c6e35544543ad9dfe8b8a3499d51c9") -- Beat Saber - Linkin Park - Bleed It Out - Beat Saber - Linkin Park - Bleed It Out Depot
-- Beat Saber - Linkin Park - Breaking the Habit (AppID: 1375361)
addappid(1375361)
addappid(1375361, 1, "d1660e2cfe51af21e2c79a3d7a7bb634cd06d5d0e5bef6ad18e06e88a479ffc6") -- Beat Saber - Linkin Park - Breaking the Habit - Beat Saber - Linkin Park - Breaking the Habit Depot
-- Beat Saber - Linkin Park - Faint (AppID: 1375362)
addappid(1375362)
addappid(1375362, 1, "3a59cd96c81852805624c983235a5c6e4a4e036e78e6d2e0f9785c25f1d30bb7") -- Beat Saber - Linkin Park - Faint - Beat Saber - Linkin Park - Faint Depot
-- Beat Saber - Linkin Park - Given Up (AppID: 1375363)
addappid(1375363)
addappid(1375363, 1, "01188e2f653465a4cccf2d7c03a6576e1b924b727f519fc14e2057e945c5e5b9") -- Beat Saber - Linkin Park - Given Up - Beat Saber - Linkin Park - Given Up Depot
-- Beat Saber - Linkin Park - In the End (AppID: 1375364)
addappid(1375364)
addappid(1375364, 1, "120f82028d894060f494e19474bc8fce6e24b01f3ff4af0fef9c3f40e99a54ca") -- Beat Saber - Linkin Park - In the End - Beat Saber - Linkin Park - In the End Depot
-- Beat Saber - Linkin Park - New Divide (AppID: 1375365)
addappid(1375365)
addappid(1375365, 1, "9184ff95ff4d49053636338a5b4002e3344144fd4fddc510d4db9cb1d65cc21f") -- Beat Saber - Linkin Park - New Divide - Beat Saber - Linkin Park - New Divide Depot
-- Beat Saber - Linkin Park - Numb (AppID: 1375366)
addappid(1375366)
addappid(1375366, 1, "dcd69b42c3b608202180c5b7139ff90b6757a18cc42a34c0efe92bdec3d2549e") -- Beat Saber - Linkin Park - Numb - Beat Saber - Linkin Park - Numb Depot
-- Beat Saber - Linkin Park - One Step Closer (AppID: 1375367)
addappid(1375367)
addappid(1375367, 1, "b02846120ed0685b8c92d203a686fd49699747de3a6ddfc7975f6a9ee4d9f214") -- Beat Saber - Linkin Park - One Step Closer - Beat Saber - Linkin Park - One Step Closer Depot
-- Beat Saber - Linkin Park - Papercut (AppID: 1375368)
addappid(1375368)
addappid(1375368, 1, "2ec339b38bf022c49321f72b6f115df5d4daa8fe4b52902e7b692881a0971afc") -- Beat Saber - Linkin Park - Papercut - Beat Saber - Linkin Park - Papercut Depot
-- Beat Saber - Linkin Park - Somewhere I Belong (AppID: 1375369)
addappid(1375369)
addappid(1375369, 1, "21167464e984b91d747afe5ec8084ae53e0dd6613cdd94f6347bd788916a716d") -- Beat Saber - Linkin Park - Somewhere I Belong - Beat Saber - Linkin Park - Somewhere I Belong Depot
-- Beat Saber - Linkin Park - What Ive Done (AppID: 1375370)
addappid(1375370)
addappid(1375370, 1, "1150bc27f8bb7cd06b195b217b9ff9382635e74d30e1cb5e2c987a2839acb8c6") -- Beat Saber - Linkin Park - What Ive Done - Beat Saber - Linkin Park - What I've Done Depot
-- Beat Saber - BTS - Blood Sweat  Tears (AppID: 1463160)
addappid(1463160)
addappid(1463160, 1, "93fac31d1e8e941c817a23a2ecaa57483c3835708458813e8a91b46d6071545c") -- Beat Saber - BTS - Blood Sweat  Tears - Beat Saber - BTS - Blood Sweat &amp; Tears Depot
addappid(1463161, 1, "7f95495d92ceb8d8b85dc1ddb9a214517a4ad8a5a30bfb3afc6f9d5ab87be0ea") -- Beat Saber - BTS - Blood Sweat  Tears - Depot 1463161
-- Beat Saber - BTS - Boy With Luv (feat. Halsey) (AppID: 1463190)
addappid(1463190)
addappid(1463190, 1, "35b0293ca093cc6136ac6e09fe8787620192a51d619ac8d01b398ebbfb6c42ee") -- Beat Saber - BTS - Boy With Luv (feat. Halsey) - Beat Saber - BTS - Boy With Luv (feat. Halsey) Depot
addappid(1463191, 1, "5c87b2cfb38e01418b9f228129ab11ee29c2a70f7e84be7757b1718223dcc743") -- Beat Saber - BTS - Boy With Luv (feat. Halsey) - Depot 1463191
-- Beat Saber - BTS - Burning Up (Fire) (AppID: 1463220)
addappid(1463220)
addappid(1463220, 1, "1dba642fd7d9f34ee28d2dcec1485266f2c422c208f7fde2768701dba759489a") -- Beat Saber - BTS - Burning Up (Fire) - Beat Saber - BTS - Burning Up (Fire) Depot
addappid(1463221, 1, "09d2994029d6f7f8363392ef6ae332933acb9a77914b15e344514cd50d17419b") -- Beat Saber - BTS - Burning Up (Fire) - Depot 1463221
-- Beat Saber - BTS - Dionysus (AppID: 1463230)
addappid(1463230)
addappid(1463230, 1, "767cac4f799236012b11301de917a2ee0bda1d731a5c7e52b8be96f5078aa637") -- Beat Saber - BTS - Dionysus - Beat Saber - BTS - Dionysus Depot
addappid(1463231, 1, "43ed58427f50deb053b0fd86fcf268f81db89d40d5ccd5d4414966cfcfdc9c3a") -- Beat Saber - BTS - Dionysus - Depot 1463231
-- Beat Saber - BTS - DNA (AppID: 1463240)
addappid(1463240)
addappid(1463240, 1, "b8056674cd7773f909312ab2321190146e817f1d42098133c3a533e179f3f9dc") -- Beat Saber - BTS - DNA - Beat Saber - BTS - DNA Depot
addappid(1463242, 1, "a5455348acbb62df2188aea65c9401d9455b8db52cbd73e288b8e96764b59542") -- Beat Saber - BTS - DNA - Depot 1463242
-- Beat Saber - BTS - Dope (AppID: 1463241)
addappid(1463241)
addappid(1463241, 1, "6ad726d9203dc3a52688f045a3d93c8d805371b2d8a638562d5160093f88ac36") -- Beat Saber - BTS - Dope - Beat Saber - BTS - Dope Depot
addappid(3030840, 1, "bf2dee128e5c6144e9c76b52988d5d801988c6fd8769feaad08f1e08f7a56fc2") -- Beat Saber - BTS - Dope - Depot 3030840
-- Beat Saber - BTS - Dynamite (AppID: 1463250)
addappid(1463250)
addappid(1463250, 1, "0eac812753bffacd14cd82dc3579c61d344eefa25c55c6221ea4553cd5f24228") -- Beat Saber - BTS - Dynamite - Beat Saber - BTS - Dynamite Depot
addappid(1463252, 1, "53cbfbb54c94d691acd8cb39567eaa0d457a277472ebdba247a0930c48e526e2") -- Beat Saber - BTS - Dynamite - Depot 1463252
-- Beat Saber - BTS - FAKE LOVE (AppID: 1463251)
addappid(1463251)
addappid(1463251, 1, "88d8fcb08c3ac472634eaa68124a10f6754d63e01c3745b8ef33fd52ed15957c") -- Beat Saber - BTS - FAKE LOVE - Beat Saber - BTS - FAKE LOVE Depot
addappid(3030890, 1, "0a1caae20e57ab889619d68df4a048e8e5a89cc2b43ae2b348e48c7b5e5af12e") -- Beat Saber - BTS - FAKE LOVE - Depot 3030890
-- Beat Saber - BTS - IDOL (AppID: 1463260)
addappid(1463260)
addappid(1463260, 1, "c245815105f7025e85f4525c24aa650371d348de49807699424e945be37b4860") -- Beat Saber - BTS - IDOL - Beat Saber - BTS - IDOL Depot
addappid(1463262, 1, "b099dc9e14834043588421aea1b966c7373110f8f3ffd0a2611b620d85115a5a") -- Beat Saber - BTS - IDOL - Depot 1463262
-- Beat Saber - BTS - MIC Drop (Steve Aoki Remix) (AppID: 1463261)
addappid(1463261)
addappid(1463261, 1, "7f59bba9f2c81e96f94a91806e10ba5badeafcd94b59e86635a1507458145c7a") -- Beat Saber - BTS - MIC Drop (Steve Aoki Remix) - Beat Saber - BTS - MIC Drop (Steve Aoki Remix) Depot
addappid(3030900, 1, "716e6be29f2d2dc88d80a46e18bd9ce55242c5134055e5b8bfdf7a40e842e066") -- Beat Saber - BTS - MIC Drop (Steve Aoki Remix) - Depot 3030900
-- Beat Saber - BTS - Not Today (AppID: 1463270)
addappid(1463270)
addappid(1463270, 1, "2d04324bd1b0770de341bf1026aa70e3a289c5fb3b9b632ed4b08418aa25e662") -- Beat Saber - BTS - Not Today - Beat Saber - BTS - Not Today Depot
addappid(1463272, 1, "f4ca2b5c54caedee4ec98c346c8afec3f7546133953869e1688341ac8d225e89") -- Beat Saber - BTS - Not Today - Depot 1463272
-- Beat Saber - BTS - UGH (AppID: 1463271)
addappid(1463271)
addappid(1463271, 1, "f9a6167f03bd00e016ce7afa123a56d74c808f499ad8829439bb17b2fbfa9c19") -- Beat Saber - BTS - UGH - Beat Saber - BTS - UGH! Depot
addappid(3030910, 1, "e21480f72d477e33af84c317b39ed353cd903fb0a98a696b4d99f94f67367ba2") -- Beat Saber - BTS - UGH - Depot 3030910
-- Beat Saber - OneRepublic - Counting Stars (AppID: 1636340)
addappid(1636340)
addappid(1636340, 1, "e077189e5227961b8b2fbe6873a94327a4662c186f1d3941d5dc16ebbc262390") -- Beat Saber - OneRepublic - Counting Stars - Depot 1636340
-- Beat Saber - Kendrick Lamar - DNA. (AppID: 1636341)
addappid(1636341)
addappid(1636341, 1, "1d6c710db935024d7ac65b3ad6c19039eec398507a197ec2256b542f602c146e") -- Beat Saber - Kendrick Lamar - DNA. - Depot 1636341
-- Beat Saber -  The Pussycat Dolls - Dont Cha (AppID: 1636342)
addappid(1636342)
addappid(1636342, 1, "4dadf713009191cba9e0739cc89b813e89c215a92bdfffe3ad08cd3f6ac7fb9f") -- Beat Saber -  The Pussycat Dolls - Dont Cha - Depot 1636342
-- Beat Saber - LMFAO ft. Lauren Bennett, GoonRock - Party Rock Anthem (AppID: 1636343)
addappid(1636343)
addappid(1636343, 1, "522defb7d604943287835062c91a6fc2c37ad38b5aa5da31eaf987c285545bb0") -- Beat Saber - LMFAO ft. Lauren Bennett, GoonRock - Party Rock Anthem - Depot 1636343
-- Beat Saber - Limp Bizkit - Rollin (Air Raid Vehicle) (AppID: 1636344)
addappid(1636344)
addappid(1636344, 1, "d123e67f72b93df983ec3cfc34d112c53b4ebf798504ce04cd49015579db621e") -- Beat Saber - Limp Bizkit - Rollin (Air Raid Vehicle) - Depot 1636344
-- Beat Saber - Maroon 5 - Sugar (AppID: 1636345)
addappid(1636345)
addappid(1636345, 1, "d389ff4a24fb1157eb1b9d5fe9279dcd2c1c9cd67f720c1069243f57b38d9ba7") -- Beat Saber - Maroon 5 - Sugar - Depot 1636345
-- Beat Saber - Gwen Stefani - The Sweet Escape ft. Akon (AppID: 1636346)
addappid(1636346)
addappid(1636346, 1, "71e13b6bab3f411baf9abe5fc93713054b35deab164f0f6e2a4cd244ad8c22b8") -- Beat Saber - Gwen Stefani - The Sweet Escape ft. Akon - Depot 1636346
-- Beat Saber - Skrillex - Bangarang (feat. Sirah) (AppID: 1725500)
addappid(1725500)
addappid(1725500, 1, "fd521668f7ccc759dd6955305fdf44c5cd3b759bae3823a4e6e09951390ea356") -- Beat Saber - Skrillex - Bangarang (feat. Sirah) - Depot 1725500
-- Beat Saber - Skrillex, Starrah  Four Tet - Butterflies (AppID: 1725501)
addappid(1725501)
addappid(1725501, 1, "c85c065b26bcaa31f26ad68f4c4976251b4a17092116434f1b89ffc41ecd87c8") -- Beat Saber - Skrillex, Starrah  Four Tet - Butterflies - Depot 1725501
-- Beat Saber - Skrillex, Justin Bieber  Don Toliver - Dont Go (AppID: 1725502)
addappid(1725502)
addappid(1725502, 1, "e9bd8b71b6d53c9cc26559d6c15d980c15db26112798bd097eabd1a4fcd7b21e") -- Beat Saber - Skrillex, Justin Bieber  Don Toliver - Dont Go - Depot 1725502
-- Beat Saber - Skrillex - First of the Year (Equinox)  (AppID: 1725503)
addappid(1725503)
addappid(1725503, 1, "829c870940e9e2a61d27a9e1ae4edf894adb8314a7a5007e286af1611f7c1b1c") -- Beat Saber - Skrillex - First of the Year (Equinox)  - Depot 1725503
-- Beat Saber - Skrillex - Ragga Bomb (feat. Ragga Twins) (AppID: 1725504)
addappid(1725504)
addappid(1725504, 1, "44726de5c447be13a030bb60373b66877a1cbfdb719a89e410c953877be366d5") -- Beat Saber - Skrillex - Ragga Bomb (feat. Ragga Twins) - Depot 1725504
-- Beat Saber - Skrillex - Rock n Roll (Will Take You to the Mountain)  (AppID: 1725505)
addappid(1725505)
addappid(1725505, 1, "e4d00c9bf6d5ed352c3046f0f626c0284a6ee6aa31e6288d4866dc0a1a402641") -- Beat Saber - Skrillex - Rock n Roll (Will Take You to the Mountain)  - Depot 1725505
-- Beat Saber - Skrillex - Scary Monsters and Nice Sprites (AppID: 1725506)
addappid(1725506)
addappid(1725506, 1, "f22662cb36c4d7b5a37f2d76f54acf47eb5c4dd8a8d7e11e8a9f43c9d3d5f0ce") -- Beat Saber - Skrillex - Scary Monsters and Nice Sprites - Depot 1725506
-- Beat Saber - Skrillex  Wolfgang Gartner - The Devils Den  (AppID: 1725507)
addappid(1725507)
addappid(1725507, 1, "bfa53d88e0b72622811285b7f3afb302b77b0a0a430f023cec1d60d625546289") -- Beat Saber - Skrillex  Wolfgang Gartner - The Devils Den  - Depot 1725507
-- Beat Saber - Billie Eilish - all the good girls go to hell (AppID: 1753520)
addappid(1753520)
addappid(1753520, 1, "550f7dd878fcdc1566ab1663ef1c2384e17cda77ef21eb05df069c6b57603f24") -- Beat Saber - Billie Eilish - all the good girls go to hell - Depot 1753520
-- Beat Saber - Billie Eilish - bad guy (AppID: 1753521)
addappid(1753521)
addappid(1753521, 1, "e0693c00ed84cd9a37a9167abef54673df45a4f6e59be6c044ce80f6ba3f649f") -- Beat Saber - Billie Eilish - bad guy - Depot 1753521
-- Beat Saber - Billie Eilish - bellyache (AppID: 1753522)
addappid(1753522)
addappid(1753522, 1, "84e217107cdbe276e54b30ec68704116b7c42ea904e312c4f66cba2b64309d79") -- Beat Saber - Billie Eilish - bellyache - Depot 1753522
-- Beat Saber - Billie Eilish - bury a friend (AppID: 1753523)
addappid(1753523)
addappid(1753523, 1, "f112a12eddb325e4be602d89839569996f10d221fd7090293c5ff90efe04f067") -- Beat Saber - Billie Eilish - bury a friend - Depot 1753523
-- Beat Saber - Billie Eilish - Happier Than Ever (AppID: 1753524)
addappid(1753524)
addappid(1753524, 1, "92f99ec2601ec78586e791cc1ca2c08500d548405190aac2429fa2343f2f5400") -- Beat Saber - Billie Eilish - Happier Than Ever - Depot 1753524
-- Beat Saber - Billie Eilish - I Didnt Change My Number (AppID: 1753525)
addappid(1753525)
addappid(1753525, 1, "d6f95d06ec5266f1c8a59a63d13f85b08417366ea4ef80a15025dc4ae9f9a65b") -- Beat Saber - Billie Eilish - I Didnt Change My Number - Depot 1753525
-- Beat Saber - Billie Eilish - NDA (AppID: 1753526)
addappid(1753526)
addappid(1753526, 1, "eb5836f4692e8e2279f89672f8d1850e2de075243c3d823ede22d917a777db11") -- Beat Saber - Billie Eilish - NDA - Depot 1753526
-- Beat Saber - Billie Eilish - Oxytocin (AppID: 1753527)
addappid(1753527)
addappid(1753527, 1, "9130fde7ed1f29c3c8bc7730df1bf0538b30c1ca5b30cf06f35ed0fb28017d1a") -- Beat Saber - Billie Eilish - Oxytocin - Depot 1753527
-- Beat Saber - Billie Eilish - Therefore I Am (AppID: 1753528)
addappid(1753528)
addappid(1753528, 1, "ae306811ee4263a91dfad5623fe16095fe02b1400f6fcf7f4508781e4af9c447") -- Beat Saber - Billie Eilish - Therefore I Am - Depot 1753528
-- Beat Saber - Billie Eilish - you should see me in a crown (AppID: 1753529)
addappid(1753529)
addappid(1753529, 1, "5b6c9abc1ca43f9859b21cdcf3b24b976e7328068b0a07c3b9faf70e90bf1c13") -- Beat Saber - Billie Eilish - you should see me in a crown - Depot 1753529
-- Beat Saber - Lady Gaga - Alejandro (AppID: 1812880)
addappid(1812880)
addappid(1812880, 1, "d680875970c51a97f441f2405483c4f91d4a6aee6f5c93d43f85d5478a47cdca") -- Beat Saber - Lady Gaga - Alejandro - Depot 1812880
-- Beat Saber - Lady Gaga - Bad Romance (AppID: 1812881)
addappid(1812881)
addappid(1812881, 1, "4a2473561aea1b25663cba2ac1f4b50f20a2362aec2e392ef610447b0cb2598d") -- Beat Saber - Lady Gaga - Bad Romance - Depot 1812881
-- Beat Saber - Lady Gaga - Born This Way (AppID: 1812882)
addappid(1812882)
addappid(1812882, 1, "ad2ac82265f5d80aeed586c4c99b4f09868ef6410d4e4452e67c71384065093e") -- Beat Saber - Lady Gaga - Born This Way - Depot 1812882
-- Beat Saber - Lady Gaga, Colby ODonis - Just Dance (feat. Colby ODonis) (AppID: 1812883)
addappid(1812883)
addappid(1812883, 1, "2b189a4edeb5c976465821670d461d4940ebb7e896637f4761e3911e5af70559") -- Beat Saber - Lady Gaga, Colby ODonis - Just Dance (feat. Colby ODonis) - Depot 1812883
-- Beat Saber - Lady Gaga - Paparazzi (AppID: 1812884)
addappid(1812884)
addappid(1812884, 1, "90c75c4e9d2796fa114c84d5a0b908c8f3c6e1512b5c5aadc3dc643c2d0f5419") -- Beat Saber - Lady Gaga - Paparazzi - Depot 1812884
-- Beat Saber - Lady Gaga - Poker Face (AppID: 1812885)
addappid(1812885)
addappid(1812885, 1, "82d397b5abba91b16b644d465222fc1bd4dd539cac6f118ceb1a145b750730a5") -- Beat Saber - Lady Gaga - Poker Face - Depot 1812885
-- Beat Saber - Lady Gaga, Ariana Grande - Rain On Me (with Ariana Grande) (AppID: 1812886)
addappid(1812886)
addappid(1812886, 1, "ed9c9683c871144bf233e7940c68c0750bf95e2aa39cf40c35f29d02b20ce710") -- Beat Saber - Lady Gaga, Ariana Grande - Rain On Me (with Ariana Grande) - Depot 1812886
-- Beat Saber - Lady Gaga - Stupid Love (AppID: 1812887)
addappid(1812887)
addappid(1812887, 1, "e5ec952b042417731b9e34ec1fe1ae73e3603b2f751875757f596af6d85a3b2a") -- Beat Saber - Lady Gaga - Stupid Love - Depot 1812887
-- Beat Saber - Lady Gaga, Beyonc - Telephone (feat. Beyonc) (AppID: 1812888)
addappid(1812888)
addappid(1812888, 1, "0a6b3c05ab73d5d49f0b15f6ac03991ac4615d59bbeaa2fc8f1bfb24fe035761") -- Beat Saber - Lady Gaga, Beyonc - Telephone (feat. Beyonc) - Depot 1812888
-- Beat Saber - Lady Gaga - The Edge Of Glory (AppID: 1812889)
addappid(1812889)
addappid(1812889, 1, "36758cda4f77cf221cae530b8799fd2b6bdd7115b4e5d200f78221e75b735329") -- Beat Saber - Lady Gaga - The Edge Of Glory - Depot 1812889
-- Beat Saber - Fall Out Boy - Centuries (AppID: 1939830)
addappid(1939830)
addappid(1939830, 1, "dd0ee5d8c3621dff66d866a4fb8d3460263bcd852867bafea755c6e23cb325eb") -- Beat Saber - Fall Out Boy - Centuries - Depot 1939830
-- Beat Saber - Fall Out Boy - Dance, Dance (AppID: 1939831)
addappid(1939831)
addappid(1939831, 1, "775b8361f1e89ec881ac37b32d04aada9db4b03d98a9f5df1c0a4789dc90d79e") -- Beat Saber - Fall Out Boy - Dance, Dance - Depot 1939831
-- Beat Saber - Fall Out Boy - I Dont Care (AppID: 1939832)
addappid(1939832)
addappid(1939832, 1, "a76dd722ee2d389be66560d0e292b9f6bfddc2780551cbc6a7e05077043af08f") -- Beat Saber - Fall Out Boy - I Dont Care - Depot 1939832
-- Beat Saber - Fall Out Boy - Immortals (AppID: 1939833)
addappid(1939833)
addappid(1939833, 1, "2e6bbd45fa9702fba2f55ca81af9d0dbf4d9f69f974db4032fa718c29c3e3a59") -- Beat Saber - Fall Out Boy - Immortals - Depot 1939833
-- Beat Saber - Fall Out Boy - Irresistible (AppID: 1939834)
addappid(1939834)
addappid(1939834, 1, "86f5234d4240bcd75378e2c325dc3557bb8aa669a1d0d3e83892f515e7ca0ad2") -- Beat Saber - Fall Out Boy - Irresistible - Depot 1939834
-- Beat Saber - Fall Out Boy - My Songs Know What You Did In The Dark (Light Em Up) (AppID: 1939835)
addappid(1939835)
addappid(1939835, 1, "18a987fcfdd13f65b9c5e10a5dd69c28306d1fe0c6dfe40b0ca7b6142f58e23f") -- Beat Saber - Fall Out Boy - My Songs Know What You Did In The Dark (Light Em Up) - Depot 1939835
-- Beat Saber - Fall Out Boy - This Aint A Scene, Its An Arms Race (AppID: 1939836)
addappid(1939836)
addappid(1939836, 1, "fe1f51a66e7dd81400bfb9889a1174ead139beba138403e42bddabfcebab3baf") -- Beat Saber - Fall Out Boy - This Aint A Scene, Its An Arms Race - Depot 1939836
-- Beat Saber - Fall Out Boy - Thnks fr th Mmrs (AppID: 1939837)
addappid(1939837)
addappid(1939837, 1, "5fa5560b1a97263c04ebd1030d5beddea578b89a0c05aaa0d4db09191287c448") -- Beat Saber - Fall Out Boy - Thnks fr th Mmrs - Depot 1939837
-- Beat Saber - Marshmello - Alone (AppID: 1967800)
addappid(1967800)
addappid(1967800, 1, "5581bc362e2d6f3000fccc983e242a6fbcf0dca62f6fc3908f1f11e7f2c6f780") -- Beat Saber - Marshmello - Alone - Depot 1967800
-- Beat Saber - Martin Garrix - Animals (AppID: 1967801)
addappid(1967801)
addappid(1967801, 1, "57f6f6b8d0fbd029323b5f0bd08df58b2ad407f38d2c20c5e5c75e4b814f83e4") -- Beat Saber - Martin Garrix - Animals - Depot 1967801
-- Beat Saber - Bomfunk MCs - Freestyler (AppID: 1967802)
addappid(1967802)
addappid(1967802, 1, "7a0573ab2a742f4d80b4eb038c3c71e53606ec6ac1edec6aea66f859849a11e6") -- Beat Saber - Bomfunk MCs - Freestyler - Depot 1967802
-- Beat Saber - deadmau5 - Ghosts n Stuff (feat. Rob Swire) (AppID: 1967803)
addappid(1967803)
addappid(1967803, 1, "9e36a9cc9249f87f3a33569a8fb307f490913c5b27ae7198b9260e5e45a2072d") -- Beat Saber - deadmau5 - Ghosts n Stuff (feat. Rob Swire) - Depot 1967803
-- Beat Saber - Madeon - Icarus (AppID: 1967804)
addappid(1967804)
addappid(1967804, 1, "35a87b77c586ed213188e17cb5736c279ac92996b738d94305ef14fd96733e6e") -- Beat Saber - Madeon - Icarus - Depot 1967804
-- Beat Saber - Darude - Sandstorm (AppID: 1967805)
addappid(1967805)
addappid(1967805, 1, "8189d04aeb87dcf233168299fa24173d14222bbfbb1ef0083249e54858ed772f") -- Beat Saber - Darude - Sandstorm - Depot 1967805
-- Beat Saber - Zedd - Stay The Night (feat. Hayley Williams) (AppID: 1967806)
addappid(1967806)
addappid(1967806, 1, "00b22c3fce3d834170c98aa78e6dcddb93c738ad6b02ccf368d3be40b42f0ba1") -- Beat Saber - Zedd - Stay The Night (feat. Hayley Williams) - Depot 1967806
-- Beat Saber - Fatboy Slim - The Rockafeller Skank (AppID: 1967807)
addappid(1967807)
addappid(1967807, 1, "3750332770cb19cc0e71cd87e1f0eec41ffe13571a3ed9b1dd2c4a8ddb3e901b") -- Beat Saber - Fatboy Slim - The Rockafeller Skank - Depot 1967807
-- Beat Saber - Rudimental - Waiting All Night (feat. Ella Eyre) (AppID: 1967808)
addappid(1967808)
addappid(1967808, 1, "6e09fd488b81e3afae9a0560b96ddb72a41e48c9c4167b45c56eed264230c715") -- Beat Saber - Rudimental - Waiting All Night (feat. Ella Eyre) - Depot 1967808
-- Beat Saber - Pendulum - Witchcraft (AppID: 1967809)
addappid(1967809)
addappid(1967809, 1, "977ced412af7ce118c118966e7e3f252b198056360c87e93117c288e01927a8e") -- Beat Saber - Pendulum - Witchcraft - Depot 1967809
-- Beat Saber - Lizzo - 2 Be Loved (Am I Ready) (AppID: 2122140)
addappid(2122140)
addappid(2122140, 1, "108a5755cbb1c1eb0597a7d76c25554eaa8547177742fb5b0375da4744579ef0") -- Beat Saber - Lizzo - 2 Be Loved (Am I Ready) - Depot 2122140
-- Beat Saber - Lizzo - About Damn Time (AppID: 2122141)
addappid(2122141)
addappid(2122141, 1, "0b4fe1b4cc92dd720a2bf2f38a1570be40dbcde8c3b233fc26db19dfd021e7dc") -- Beat Saber - Lizzo - About Damn Time - Depot 2122141
-- Beat Saber - Lizzo - Cuz I Love You (AppID: 2122142)
addappid(2122142)
addappid(2122142, 1, "df3c761f3f727596b3ac707fead29377e6f1f48885c675ebe31ddc60101bfa3a") -- Beat Saber - Lizzo - Cuz I Love You - Depot 2122142
-- Beat Saber - Lizzo - Everybodys Gay (AppID: 2122143)
addappid(2122143)
addappid(2122143, 1, "e857e6da14e717284129f09873343e8f0af3831fab1d4132dbf87b2e050c9173") -- Beat Saber - Lizzo - Everybodys Gay - Depot 2122143
-- Beat Saber - Lizzo - Good As Hell (AppID: 2122144)
addappid(2122144)
addappid(2122144, 1, "e7db22279e9786528820aa8dbeb12dc796896c2ccc28945cec787b95db1c2730") -- Beat Saber - Lizzo - Good As Hell - Depot 2122144
-- Beat Saber - Lizzo - Juice (AppID: 2122160)
addappid(2122160)
addappid(2122160, 1, "ff589ad77ada8969fd65402fc3cc9b52ac6e48fe16db534206b7017a9012d0ab") -- Beat Saber - Lizzo - Juice - Depot 2122160
-- Beat Saber - Lizzo - Tempo (feat. Missy Elliot) (AppID: 2122161)
addappid(2122161)
addappid(2122161, 1, "df33b2933ad1bd5bc9c599606ce8bb823904b97efa68f4c095d8c56f10558235") -- Beat Saber - Lizzo - Tempo (feat. Missy Elliot) - Depot 2122161
-- Beat Saber - Lizzo - Truth Hurts (AppID: 2122162)
addappid(2122162)
addappid(2122162, 1, "abb15b12ee8e6487126c2f03e9fed5a317a9f992d122f546aba49ec0af3a3a06") -- Beat Saber - Lizzo - Truth Hurts - Depot 2122162
-- Beat Saber - Lizzo - Worship (AppID: 2122163)
addappid(2122163)
addappid(2122163, 1, "f106017ef14c0be0bd0287b22765008ec2dedb7a30e6e26a786cd59e710a7e2d") -- Beat Saber - Lizzo - Worship - Depot 2122163
-- Beat Saber - The Weeknd - Blinding Lights (AppID: 2195470)
addappid(2195470)
addappid(2195470, 1, "f1bcf2678370204f6238bbf31f53737efcc0fed3775ec24fc90ba0eb4104ab66") -- Beat Saber - The Weeknd - Blinding Lights - Depot 2195470
-- Beat Saber - The Weeknd - Cant Feel My Face (AppID: 2195471)
addappid(2195471)
addappid(2195471, 1, "588f91149d2644ca2142c511305707dec94e6b588454f221669fc2360fa042d7") -- Beat Saber - The Weeknd - Cant Feel My Face - Depot 2195471
-- Beat Saber - The Weeknd - How Do I Make You Love Me (AppID: 2195472)
addappid(2195472)
addappid(2195472, 1, "805dcad91a8ef9c8e30ad210503ef1ef13f2e6be6ecce678e2d12aae74de82ca") -- Beat Saber - The Weeknd - How Do I Make You Love Me - Depot 2195472
-- Beat Saber - The Weeknd - I Feel It Coming (Feat. Daft Punk) (AppID: 2195473)
addappid(2195473)
addappid(2195473, 1, "346ef63effc4547e63af7960d7fc0865456702803f46b770bd65663d335ae9ba") -- Beat Saber - The Weeknd - I Feel It Coming (Feat. Daft Punk) - Depot 2195473
-- Beat Saber - The Weeknd, Kendrick Lamar - Pray For Me (AppID: 2195474)
addappid(2195474)
addappid(2195474, 1, "7045cb5df6a072cba59f0bff5b7d472a7970d36c3d98620487b94423ceda77c0") -- Beat Saber - The Weeknd, Kendrick Lamar - Pray For Me - Depot 2195474
-- Beat Saber - The Weeknd - Sacrifice (AppID: 2195475)
addappid(2195475)
addappid(2195475, 1, "bf0db8d125dbbee7489a66619644da9c780da052249876820280ecef52f99e13") -- Beat Saber - The Weeknd - Sacrifice - Depot 2195475
-- Beat Saber - The Weeknd - Save Your Tears (AppID: 2195476)
addappid(2195476)
addappid(2195476, 1, "1139dce4de3c3247297176ad1146b1a17c0a8c8302877a793c6e6f1cf6f3d7a2") -- Beat Saber - The Weeknd - Save Your Tears - Depot 2195476
-- Beat Saber - The Weeknd - Starboy (feat. Daft Punk) (AppID: 2195477)
addappid(2195477)
addappid(2195477, 1, "7c479592043b31d341ce4ce58f2554104eafb8e7de9d7b6c6a1ba1ca66b29b77") -- Beat Saber - The Weeknd - Starboy (feat. Daft Punk) - Depot 2195477
-- Beat Saber - The Weeknd - Take My Breath (AppID: 2195478)
addappid(2195478)
addappid(2195478, 1, "2bbb5c9eff1bbb1b2eb9844224b61018878fa32b72adc1e262e51c464c955745") -- Beat Saber - The Weeknd - Take My Breath - Depot 2195478
-- Beat Saber - The Weeknd - The Hills (AppID: 2195479)
addappid(2195479)
addappid(2195479, 1, "99faff849d8eb2b93f356f916d00ccfaae2142a2e2c285a029433c4ecf9e33f4") -- Beat Saber - The Weeknd - The Hills - Depot 2195479
-- Beat Saber - Steppenwolf - Born To Be Wild (AppID: 2233130)
addappid(2233130)
addappid(2233130, 1, "3e61c3f1f097bec24d8be56a0cdd63beddb2b2eda60b1f8e7de7ff53a6f9b0d7") -- Beat Saber - Steppenwolf - Born To Be Wild - Depot 2233130
-- Beat Saber - Survivor - Eye of the Tiger (AppID: 2233131)
addappid(2233131)
addappid(2233131, 1, "3d8dfa69707e50ba26a4e05a5a05cde285be0abbd6da7b76e394f4b14758a276") -- Beat Saber - Survivor - Eye of the Tiger - Depot 2233131
-- Beat Saber - Lynyrd Skynyrd - Free Bird (AppID: 2233132)
addappid(2233132)
addappid(2233132, 1, "82a4eddaf8483d8c59f67230bdbcca4177c243b105a5ce390de85306a784def2") -- Beat Saber - Lynyrd Skynyrd - Free Bird - Depot 2233132
-- Beat Saber - KISS - I Was Made For Lovin You (AppID: 2233133)
addappid(2233133)
addappid(2233133, 1, "d06b7c9c63a0093f65b680c7e255bdc0d2a3c2e3f2c6dca4af975f2511977161") -- Beat Saber - KISS - I Was Made For Lovin You - Depot 2233133
-- Beat Saber - The White Stripes - Seven Nation Army (AppID: 2233134)
addappid(2233134)
addappid(2233134, 1, "5db837b7887af7975a6f9d826e66cd23ddbedb3e6c106e645661adb4cd19f818") -- Beat Saber - The White Stripes - Seven Nation Army - Depot 2233134
-- Beat Saber - Nirvana - Smells Like Teen Spirit (AppID: 2233135)
addappid(2233135)
addappid(2233135, 1, "42262b51e2919a46205651409ec8b115db0994312f62e8555ea21b4728a71c32") -- Beat Saber - Nirvana - Smells Like Teen Spirit - Depot 2233135
-- Beat Saber - Guns N Roses - Sweet Child O Mine (AppID: 2233136)
addappid(2233136)
addappid(2233136, 1, "43f6659cd0833c37e12c9c72757f8236476502dd6a16a3c9fe1dad9d16e34b16") -- Beat Saber - Guns N Roses - Sweet Child O Mine - Depot 2233136
-- Beat Saber - Foo Fighters - The Pretender (AppID: 2233137)
addappid(2233137)
addappid(2233137, 1, "14441118a21955e493f983737468a6f42e7d3f9df7b3c37594aedbe72bb831dd") -- Beat Saber - Foo Fighters - The Pretender - Depot 2233137
-- Beat Saber - Imagine Dragons x J.I.D - Enemy (from the series Arcane League of Legends) (AppID: 2271511)
addappid(2271511)
addappid(2271511, 1, "0ad82031f0363d3e99fd03f770fbf2cd71302b8565f83cdd231b13d121e7d587") -- Beat Saber - Imagine Dragons x J.I.D - Enemy (from the series Arcane League of Legends) - Depot 2271511
-- Beat Saber - Panic At The Disco - Crazy  Genius (AppID: 2350250)
addappid(2350250)
addappid(2350250, 1, "c7c2fa61e87168d204834f88444d1332860e62d85193bb567b3c57920947444a") -- Beat Saber - Panic At The Disco - Crazy  Genius - Depot 2350250
-- Beat Saber - Panic At The Disco - Dancings Not A Crime (AppID: 2350251)
addappid(2350251)
addappid(2350251, 1, "5bc9fff3565864e677f5f53baf71e45fea840384a3f9c969c5984fc55ef3947f") -- Beat Saber - Panic At The Disco - Dancings Not A Crime - Depot 2350251
-- Beat Saber - Panic At The Disco - Hey Look Ma, I Made It (AppID: 2350252)
addappid(2350252)
addappid(2350252, 1, "7788c22c27341fb26e4185b41bafc6fd8f6aa290c2e3346c613910576142819c") -- Beat Saber - Panic At The Disco - Hey Look Ma, I Made It - Depot 2350252
-- Beat Saber - Panic At The Disco - Say Amen (Saturday Night) (AppID: 2350253)
addappid(2350253)
addappid(2350253, 1, "df4e6d49e629bf92cd84d8d399cb3320bba38bfc2ebd025c450ea1a4aecd616f") -- Beat Saber - Panic At The Disco - Say Amen (Saturday Night) - Depot 2350253
-- Beat Saber - Panic At The Disco - Sugar Soaker (AppID: 2350254)
addappid(2350254)
addappid(2350254, 1, "0561c5c0decd13d82e987206c35bdc26257b1d2ef8837fd818ae7bf79209a74b") -- Beat Saber - Panic At The Disco - Sugar Soaker - Depot 2350254
-- Beat Saber - Panic At The Disco - Viva Las Vengeance (AppID: 2350255)
addappid(2350255)
addappid(2350255, 1, "a86ba5fa2926d4324d2d207a605a873503e10c67c823081ff32e2bad8185019d") -- Beat Saber - Panic At The Disco - Viva Las Vengeance - Depot 2350255
-- Beat Saber - Queen - Another One Bites the Dust (AppID: 2407760)
addappid(2407760)
addappid(2407760, 1, "0302887fc3d2d99119d410c93adcb6c24715ce8a8c302885b1116c31ce8c7337") -- Beat Saber - Queen - Another One Bites the Dust - Depot 2407760
-- Beat Saber - Queen - Bohemian Rhapsody (AppID: 2407761)
addappid(2407761)
addappid(2407761, 1, "ca69919a11b7c2ba1701d907afeaac9af1363e0e805e3f970e1c792d8be7a29d") -- Beat Saber - Queen - Bohemian Rhapsody - Depot 2407761
-- Beat Saber - Queen - Crazy Little Thing Called Love (AppID: 2407762)
addappid(2407762)
addappid(2407762, 1, "af20c422ac0922542cd78077667cb8c907df510e2180842c58a067107198ac68") -- Beat Saber - Queen - Crazy Little Thing Called Love - Depot 2407762
-- Beat Saber - Queen - Dont Stop Me Now (AppID: 2407763)
addappid(2407763)
addappid(2407763, 1, "ba2c4491ae27948577ebe22c8e2f8600b27fb84ded5b4b8b366b476c5a39bdd5") -- Beat Saber - Queen - Dont Stop Me Now - Depot 2407763
-- Beat Saber - Queen - I Want It All (AppID: 2407764)
addappid(2407764)
addappid(2407764, 1, "7259b9a968598010766a15ef2421f8884554da0d529fd41e3e12a459f8dcb44d") -- Beat Saber - Queen - I Want It All - Depot 2407764
-- Beat Saber - Queen - Killer Queen (AppID: 2407765)
addappid(2407765)
addappid(2407765, 1, "5ffcc637d6c26fe0db60a5d7c5594031aa3985f7e38bb060542697d359d5c4f7") -- Beat Saber - Queen - Killer Queen - Depot 2407765
-- Beat Saber - Queen - One Vision (AppID: 2407766)
addappid(2407766)
addappid(2407766, 1, "63b4cfc67d86f3b0ba4ae2615151a913cdf55388b50be817080c46aec49571a3") -- Beat Saber - Queen - One Vision - Depot 2407766
-- Beat Saber - Queen - Somebody to Love (AppID: 2407767)
addappid(2407767)
addappid(2407767, 1, "b15549622067b27bb3c2d990e7512a0ab9f7712ee302e040ee886324c7aee263") -- Beat Saber - Queen - Somebody to Love - Depot 2407767
-- Beat Saber - Queen - Stone Cold Crazy (AppID: 2407768)
addappid(2407768)
addappid(2407768, 1, "02e0ddbdc8b67c03cf321a9d620d4e29d6e614ac1fd1a026674cff066cb05a0f") -- Beat Saber - Queen - Stone Cold Crazy - Depot 2407768
-- Beat Saber - Queen - We Are The Champions (AppID: 2407769)
addappid(2407769)
addappid(2407769, 1, "5085deacdd4aa455744ebfb3a6060a8a8650dedbe0f5e98d1ec3060c8d1a76d3") -- Beat Saber - Queen - We Are The Champions - Depot 2407769
-- Beat Saber - Queen - We Will Rock You (AppID: 2407770)
addappid(2407770)
addappid(2407770, 1, "d8f67e8234e74b58483ec23b48b7267a435b8265320aef220815ad20dab1641e") -- Beat Saber - Queen - We Will Rock You - Depot 2407770
-- Beat Saber - The Weeknd - Die For You (Feat. Ariana Grande) (AppID: 2455550)
addappid(2455550)
addappid(2455550, 1, "1e8f88974b1d0449e9f628a72a744eb50bddcbe053c27abd017677ba4a02252b") -- Beat Saber - The Weeknd - Die For You (Feat. Ariana Grande) - Depot 2455550
-- Beat Saber - The Weeknd - Less Than Zero (AppID: 2455551)
addappid(2455551)
addappid(2455551, 1, "164f8aa6f956264970e464ec26a660b81dec5adb757ed032969d06d5f10a1d36") -- Beat Saber - The Weeknd - Less Than Zero - Depot 2455551
-- Beat Saber - Mike Shinoda - Already Over (AppID: 2594030)
addappid(2594030)
addappid(2594030, 1, "297d194cfd1c31d494974ef29a53b79fcd3fd53f7c25c93c12c4fa68ad1f9c33") -- Beat Saber - Mike Shinoda - Already Over - Depot 2594030
-- Beat Saber - Linkin Park - Crawling (AppID: 2594040)
addappid(2594040)
addappid(2594040, 1, "c219d336c89166572dde3b9ec7352453fdb4c3431810081791b557561755f5d0") -- Beat Saber - Linkin Park - Crawling - Depot 2594040
-- Beat Saber - Linkin Park - Fighting Myself (AppID: 2594050)
addappid(2594050)
addappid(2594050, 1, "8cf479dc857abd63a749048d2c481a2d30cccb4c3fa0402abf6ec58e0c2d54cc") -- Beat Saber - Linkin Park - Fighting Myself - Depot 2594050
-- Beat Saber - Mike Shinoda  Kaliee Morgue - In My Head (AppID: 2594060)
addappid(2594060)
addappid(2594060, 1, "b2ef2ddbba9494897b30dbd8d58e6ed47f7e0f6a04e35005aeb9cd6c5c9a0eb8") -- Beat Saber - Mike Shinoda  Kaliee Morgue - In My Head - Depot 2594060
-- Beat Saber - Linkin Park - Lost (AppID: 2594070)
addappid(2594070)
addappid(2594070, 1, "6edbda3ad8916ce00ab78e8872cbfb8aa72f74f773dce326d1fa2f071a7cf042") -- Beat Saber - Linkin Park - Lost - Depot 2594070
-- Beat Saber - Linkin Park - More The Victim (AppID: 2594080)
addappid(2594080)
addappid(2594080, 1, "ac02903c3ad99f5468432fe21b87432f0d4cf53c244eed103968ab2abfafb322") -- Beat Saber - Linkin Park - More The Victim - Depot 2594080
-- Beat Saber - JAY-Z, Linkin Park - NumbEncore (AppID: 2594090)
addappid(2594090)
addappid(2594090, 1, "7ee824a6a48935379cea0b3b6d46c75aed1060b95d731c08cbe509cd20da293d") -- Beat Saber - JAY-Z, Linkin Park - NumbEncore - Depot 2594090
-- Beat Saber - Fort Minor - Remember the Name (feat. Styles of Beyond) (AppID: 2594100)
addappid(2594100)
addappid(2594100, 1, "97f6fc4811b0a1757eb47d8f1e22f41df82693f86037d1d77bc656839544bb3c") -- Beat Saber - Fort Minor - Remember the Name (feat. Styles of Beyond) - Depot 2594100
-- Beat Saber - The Rolling Stones - Angry (AppID: 2650880)
addappid(2650880)
addappid(2650880, 1, "08d1f0d701125a6deafb61af226d3adf51821dffd3b40732e1f544249ba24b2d") -- Beat Saber - The Rolling Stones - Angry - Depot 2650880
-- Beat Saber - The Rolling Stones - Bite My Head Off (AppID: 2650900)
addappid(2650900)
addappid(2650900, 1, "32da12f0acf07e03dd7649ce80af71a91234c803f84150ab8b52e9d9aad0d8bc") -- Beat Saber - The Rolling Stones - Bite My Head Off - Depot 2650900
-- Beat Saber - The Rolling Stones - Cant You Hear Me Knocking (AppID: 2650910)
addappid(2650910)
addappid(2650910, 1, "80ab700e862d4dee8506d6b420a0076c57e7330f0c9210cc7d1bbcf0f86d481c") -- Beat Saber - The Rolling Stones - Cant You Hear Me Knocking - Depot 2650910
-- Beat Saber - The Rolling Stones - Gimme Shelter (AppID: 2650920)
addappid(2650920)
addappid(2650920, 1, "c747c61fb2d76fc551dd01a32f286fb7b2b8747946a2b9bf6c9ef5200699ee5b") -- Beat Saber - The Rolling Stones - Gimme Shelter - Depot 2650920
-- Beat Saber - The Rolling Stones - (I Cant Get No) Satisfaction (AppID: 2650930)
addappid(2650930)
addappid(2650930, 1, "3b3ff890a97c73af5ee3c6a5230239921298294a851be87cf34e7dabcc54864a") -- Beat Saber - The Rolling Stones - (I Cant Get No) Satisfaction - Depot 2650930
-- Beat Saber - The Rolling Stones - Live by the Sword (AppID: 2650940)
addappid(2650940)
addappid(2650940, 1, "2ee563f305ff6a7bcd602f5d27832ac35220ac56b23970a111cb73680772cce9") -- Beat Saber - The Rolling Stones - Live by the Sword - Depot 2650940
-- Beat Saber - The Rolling Stones - Mess it Up (AppID: 2650960)
addappid(2650960)
addappid(2650960, 1, "c9518cf1afb370234b7e4a9b89de404b3b061c9661ab220010010b4ca06ff30c") -- Beat Saber - The Rolling Stones - Mess it Up - Depot 2650960
-- Beat Saber - The Rolling Stones - Paint It Black (AppID: 2650970)
addappid(2650970)
addappid(2650970, 1, "fa0c997207ec0cca118bcc46e2d54d360080c4ebe987a823dd91e20e5919766e") -- Beat Saber - The Rolling Stones - Paint It Black - Depot 2650970
-- Beat Saber - The Rolling Stones - Start Me Up (AppID: 2650980)
addappid(2650980)
addappid(2650980, 1, "1f88343852ba3ccaba88efce48884614d8e1fc3e5a50cf3fe5db6bf6503457e4") -- Beat Saber - The Rolling Stones - Start Me Up - Depot 2650980
-- Beat Saber - The Rolling Stones - Sympathy For The Devil (AppID: 2650990)
addappid(2650990)
addappid(2650990, 1, "69329785d36b7ddd5070430ddc95d81b4bab57f401ea5f05734ec714baf7432a") -- Beat Saber - The Rolling Stones - Sympathy For The Devil - Depot 2650990
-- Beat Saber - The Rolling Stones - Whole Wide World (AppID: 2651000)
addappid(2651000)
addappid(2651000, 1, "c9664423dcad5407f849b5b9bf9b580dc639bc7e8afb7945c9e047f63028e9d0") -- Beat Saber - The Rolling Stones - Whole Wide World - Depot 2651000
-- Beat Saber - Daft Punk - Around The World (AppID: 2838230)
addappid(2838230)
addappid(2838230, 1, "c68f7dc20691b6ea2293964acabe4f4d535cfe9f1d850389ffe05e800c7e2140") -- Beat Saber - Daft Punk - Around The World - Depot 2838230
-- Beat Saber - Daft Punk - Around The World  Harder Better Faster Stronger (AppID: 2838240)
addappid(2838240)
addappid(2838240, 1, "920f7cef68343dae5ee7c45df6fc630b15294fb126668411cdf770d4a195c262") -- Beat Saber - Daft Punk - Around The World  Harder Better Faster Stronger - Depot 2838240
-- Beat Saber - Daft Punk - Da Funk  Daftendirekt (AppID: 2838250)
addappid(2838250)
addappid(2838250, 1, "dec5328d26c0ad79781b17b2c5e75dd887d76ddc3d6947aa040b2215aae49d4e") -- Beat Saber - Daft Punk - Da Funk  Daftendirekt - Depot 2838250
-- Beat Saber - Daft Punk - Get Lucky (feat. Pharrell Williams and Nile Rodgers) (AppID: 2838260)
addappid(2838260)
addappid(2838260, 1, "5bf29f5eb76bfe3f0bc65e32ba4f3caa6c5e075f2e13afaac42535a099e91fa4") -- Beat Saber - Daft Punk - Get Lucky (feat. Pharrell Williams and Nile Rodgers) - Depot 2838260
-- Beat Saber - Daft Punk - Harder, Better, Faster, Stronger (AppID: 2838270)
addappid(2838270)
addappid(2838270, 1, "9ad8257af0ff2ff95186115329a8a9a2cff2aed2e0fc96e823c203a464a39909") -- Beat Saber - Daft Punk - Harder, Better, Faster, Stronger - Depot 2838270
-- Beat Saber - Daft Punk - Lose Yourself to Dance (feat. Pharrell Williams) (AppID: 2838280)
addappid(2838280)
addappid(2838280, 1, "309ef301fbd9856b7519d7a404b1cc82329409e400e066859d7ab77bdaa1ca6e") -- Beat Saber - Daft Punk - Lose Yourself to Dance (feat. Pharrell Williams) - Depot 2838280
-- Beat Saber - Daft Punk - One More Time (AppID: 2838290)
addappid(2838290)
addappid(2838290, 1, "4c79a41246d3077e638638dcb6dd607acae87c4fdacfd64ced5d5f6bac282d5b") -- Beat Saber - Daft Punk - One More Time - Depot 2838290
-- Beat Saber - Daft Punk - Technologic (AppID: 2838300)
addappid(2838300)
addappid(2838300, 1, "5834bcfc536a610c610c34d46a7b37d880b2a898347f5bf525680fb541bf0f6c") -- Beat Saber - Daft Punk - Technologic - Depot 2838300
-- Beat Saber - Daft Punk - The Prime Time of Your LifeThe BrainwasherRollinAlive (Live 2007) (AppID: 2838310)
addappid(2838310)
addappid(2838310, 1, "762f7b07d743ce413b348a2697ca478b25b01b14d1347df81afaf79cb7332233") -- Beat Saber - Daft Punk - The Prime Time of Your LifeThe BrainwasherRollinAlive (Live 2007) - Depot 2838310
-- Beat Saber - Daft Punk - Veridis Quo (AppID: 2838330)
addappid(2838330)
addappid(2838330, 1, "28f0331e08241db0ad74fbd9e2f3dd018888ae2f8a23224082b838586ee30df7") -- Beat Saber - Daft Punk - Veridis Quo - Depot 2838330
-- Beat Saber - 2Pac - All Eyez On Me (feat. Big Syke) (AppID: 2893430)
addappid(2893430)
addappid(2893430, 1, "9f5717d141de0458a116c957184de18ad430aa5554f31d73ba71665a772ec6e5") -- Beat Saber - 2Pac - All Eyez On Me (feat. Big Syke) - Depot 2893430
-- Beat Saber - Nicki Minaj - Anaconda (AppID: 2893440)
addappid(2893440)
addappid(2893440, 1, "56d13f098cd03dac9d392dc4b7611bb9fc0c93af5461f845944568f35ab050bb") -- Beat Saber - Nicki Minaj - Anaconda - Depot 2893440
-- Beat Saber - Snoop Dogg - Gin and Juice (AppID: 2893450)
addappid(2893450)
addappid(2893450, 1, "a30098965dcecb811a39da73aa79db8250bf757bf2cc25b900a49611744737da") -- Beat Saber - Snoop Dogg - Gin and Juice - Depot 2893450
-- Beat Saber - Eminem - Godzilla (feat. Juice WRLD) (AppID: 2893460)
addappid(2893460)
addappid(2893460, 1, "632e890fc57854ee4c62d326d49d34e52e772f6754034443b6e091b28c66e65c") -- Beat Saber - Eminem - Godzilla (feat. Juice WRLD) - Depot 2893460
-- Beat Saber - Outkast - Hey Ya (AppID: 2893470)
addappid(2893470)
addappid(2893470, 1, "439f3f7c6426a6382b273916a0e15feecf45d576385b0588d5e49006aab4a321") -- Beat Saber - Outkast - Hey Ya - Depot 2893470
-- Beat Saber - The Notorious B.I.G. - Hypnotize (AppID: 2893480)
addappid(2893480)
addappid(2893480, 1, "67e9ee729741e2e5c60ab8c6e96b617409f4a74502f5bcf4518e43ef9d9e9293") -- Beat Saber - The Notorious B.I.G. - Hypnotize - Depot 2893480
-- Beat Saber - Dr Dre - Nuthin But A G Thang (AppID: 2893490)
addappid(2893490)
addappid(2893490, 1, "cd74752e9ddeff1ec25e137ab72305528f4d03e6cfd617e8cd9b0e95f6365ccd") -- Beat Saber - Dr Dre - Nuthin But A G Thang - Depot 2893490
-- Beat Saber - Grandmaster Flash  The Furious Five - The Message (AppID: 2893500)
addappid(2893500)
addappid(2893500, 1, "f0cb06548c5ce142ae628348990da820f5234b7ee891897991648dca24d5e84a") -- Beat Saber - Grandmaster Flash  The Furious Five - The Message - Depot 2893500
-- Beat Saber - Pop Smoke - The Woo (feat. 50 Cent, Roddy Ricch) (AppID: 2893510)
addappid(2893510)
addappid(2893510, 1, "b2115366009e3e8ec360cd2827f5af458ed9c53cf856c8d8c71943c59df490e4") -- Beat Saber - Pop Smoke - The Woo (feat. 50 Cent, Roddy Ricch) - Depot 2893510
-- Beat Saber - Eminem - Houdini (AppID: 3156250)
addappid(3156250)
addappid(3156250, 1, "23a95d9080d8ecd546d7aa5de801c98f20586c074c87d9e2da4abc79ee958cc2") -- Beat Saber - Eminem - Houdini - Depot 3156250
-- Beat Saber - Britney Spears - Baby One More Time (AppID: 3156260)
addappid(3156260)
addappid(3156260, 1, "02a17b607bfa00ef28725fd57189d964486d9a16385749216b59701a949b854e") -- Beat Saber - Britney Spears - Baby One More Time - Depot 3156260
-- Beat Saber - Britney Spears - Circus (AppID: 3181490)
addappid(3181490)
addappid(3181490, 1, "b77a28e145c1bd0d78736e05fe799964f307d0203998ba939aab7a33abf2000a") -- Beat Saber - Britney Spears - Circus - Depot 3181490
-- Beat Saber - Britney Spears - Gimme More (AppID: 3181510)
addappid(3181510)
addappid(3181510, 1, "20b2ea8e1ee289d0343f81d99db015d3dd4c755c3cca078473382b49386a31e1") -- Beat Saber - Britney Spears - Gimme More - Depot 3181510
-- Beat Saber - Britney Spears - Im A Slave 4 U (AppID: 3181520)
addappid(3181520)
addappid(3181520, 1, "b2c89929dff4950c9de05cee2684ea209d064417983fd41cb33542b5bcc329e6") -- Beat Saber - Britney Spears - Im A Slave 4 U - Depot 3181520
-- Beat Saber - Britney Spears - Me Against the Music (feat. Madonna) (AppID: 3181530)
addappid(3181530)
addappid(3181530, 1, "ff99008913ebf89123873aa135be10780f29ab0db8c08ead30bed9178660bd06") -- Beat Saber - Britney Spears - Me Against the Music (feat. Madonna) - Depot 3181530
-- Beat Saber - Britney Spears - Oops...I Did It Again (AppID: 3181550)
addappid(3181550)
addappid(3181550, 1, "98ed73dab564d08b403966384ec63ffc32b7af0bcfcebe3a1d1e2fc7ae15531b") -- Beat Saber - Britney Spears - Oops...I Did It Again - Depot 3181550
-- Beat Saber - Britney Spears - Overprotected (AppID: 3181560)
addappid(3181560)
addappid(3181560, 1, "8bae1b7e9e8b21a20c8559a29acd29dc6dda9afb6154587d5862ea0584eb3d7f") -- Beat Saber - Britney Spears - Overprotected - Depot 3181560
-- Beat Saber - Britney Spears x Will.I.AM - Scream and Shout (Will.I.AM) (AppID: 3181570)
addappid(3181570)
addappid(3181570, 1, "6500895d30a9017f105483e3293b4494bd68f6b0a30c39f752401132aedaa5fa") -- Beat Saber - Britney Spears x Will.I.AM - Scream and Shout (Will.I.AM) - Depot 3181570
-- Beat Saber - Britney Spears - Till the World Ends - Till the World Ends (AppID: 3181580)
addappid(3181580)
addappid(3181580, 1, "ed2148cdee8ff3d9bebb95c357adff9c6445874519334eabecc76cafaea03523") -- Beat Saber - Britney Spears - Till the World Ends - Till the World Ends - Depot 3181580
-- Beat Saber - Britney Spears - Toxic (AppID: 3181590)
addappid(3181590)
addappid(3181590, 1, "88e81b37f695e06ce5fc17a56c4dd72a25172908b29ff8ba9543c35cd1f494ae") -- Beat Saber - Britney Spears - Toxic - Depot 3181590
-- Beat Saber - Britney Spears - Womanizer (AppID: 3181600)
addappid(3181600)
addappid(3181600, 1, "10c59170966dd6bd878558785e5c7ef08128ef81f12f095117694db6d0e43fc7") -- Beat Saber - Britney Spears - Womanizer - Depot 3181600
-- Beat Saber - Teminite  Skybreak - Accelerate (AppID: 3274160)
addappid(3274160)
addappid(3274160, 1, "78f1f46c75e2bb1aeaf6dbd4aa77b2a1bda6199212fbaa9b51c7935371ba1826") -- Beat Saber - Teminite  Skybreak - Accelerate - Depot 3274160
-- Beat Saber - Excision  Dion Timmer - DABADABADABADABA (AppID: 3274170)
addappid(3274170)
addappid(3274170, 1, "848cd5582486e1ccb355b3e585ca90c23093c06409e2df865a5d92c28a7e1ca3") -- Beat Saber - Excision  Dion Timmer - DABADABADABADABA - Depot 3274170
-- Beat Saber - Grant  Ellis - Dead Man Walking (AppID: 3274180)
addappid(3274180)
addappid(3274180, 1, "1d0b450722c6adb4092aa07613f775b74ae684219bc72d82d3cdd355c75efc1b") -- Beat Saber - Grant  Ellis - Dead Man Walking - Depot 3274180
-- Beat Saber - Bossfight - Endgame (AppID: 3274190)
addappid(3274190)
addappid(3274190, 1, "3c440bc5248697139c0264ab2a571d30f006d917777e1d24911dfb03a5731931") -- Beat Saber - Bossfight - Endgame - Depot 3274190
-- Beat Saber - Nitro Fun - Final Boss (AppID: 3274200)
addappid(3274200)
addappid(3274200, 1, "230aa54b0a7885f0643ec5d52ceea093584a4b2e4c67ad1301086b9468e1f508") -- Beat Saber - Nitro Fun - Final Boss - Depot 3274200
-- Beat Saber - Dyro x Conro - Memory Bank (AppID: 3274210)
addappid(3274210)
addappid(3274210, 1, "c56d334d9d770f01b5f5c791804ec579db50b5df5b23903d48369596649aa829") -- Beat Saber - Dyro x Conro - Memory Bank - Depot 3274210
-- Beat Saber - F.O.O.L  Power Glove - Mercenary (AppID: 3274230)
addappid(3274230)
addappid(3274230, 1, "0f02f0e8f0c801ab9b889fed079561c1e8822f0bb32deb602283d97a82a905d9") -- Beat Saber - F.O.O.L  Power Glove - Mercenary - Depot 3274230
-- Beat Saber - Teddy Killerzs  Pegboard Nerds - Pump (AppID: 3274240)
addappid(3274240)
addappid(3274240, 1, "adc56c555ff204bf88f0c9a015d39d58f82e8cf71f8bbf6f6d0361c58449e8df") -- Beat Saber - Teddy Killerzs  Pegboard Nerds - Pump - Depot 3274240
-- Beat Saber - Tokyo Machine - RAD (AppID: 3274250)
addappid(3274250)
addappid(3274250, 1, "0e260a28eb02f50cec5000105a01591d60861f848065d13ded2ddf686252060d") -- Beat Saber - Tokyo Machine - RAD - Depot 3274250
-- Beat Saber - wnboss  Selva - RIOT (AppID: 3274260)
addappid(3274260)
addappid(3274260, 1, "004693a3ab320208bd06f572285501b1e3b4f934d9773b25db6b738d8ed1cc2b") -- Beat Saber - wnboss  Selva - RIOT - Depot 3274260
-- Beat Saber - Sullivan King - Thrones of Blood (AppID: 3274280)
addappid(3274280)
addappid(3274280, 1, "fbacda0b5b166c488631490714a4e5b39253547c3c5229856cfb3854011e590d") -- Beat Saber - Sullivan King - Thrones of Blood - Depot 3274280
-- Beat Saber - Alan Walker - Wake Up (AppID: 3274290)
addappid(3274290)
addappid(3274290, 1, "9e3faa44c9b3388e76b6295d61402cade160d03a99e9a39ee2fcd6f5d3a97a4b") -- Beat Saber - Alan Walker - Wake Up - Depot 3274290
-- Beat Saber - Metallica - Atlas, Rise (AppID: 3354440)
addappid(3354440)
addappid(3354440, 1, "1281cf3bd13f83c93ff54722457c548cebedfb99e0af6b1bb90cac31655fe2c2") -- Beat Saber - Metallica - Atlas, Rise - Depot 3354440
-- Beat Saber - Metallica - Battery (AppID: 3354460)
addappid(3354460)
addappid(3354460, 1, "5cadcf20439ca071dfd1159a77ef4d4233aebde7e0c7cc97437c0bdb1c214638") -- Beat Saber - Metallica - Battery - Depot 3354460
-- Beat Saber - Metallica - Blackened (AppID: 3354470)
addappid(3354470)
addappid(3354470, 1, "312cb5a2dd8a91b7394a9646291bfd93d77815834d0f578b6f5be33df6c3e0ad") -- Beat Saber - Metallica - Blackened - Depot 3354470
-- Beat Saber - Metallica - Creeping Death (AppID: 3354480)
addappid(3354480)
addappid(3354480, 1, "f0a9162538852393dd116be7663656223f3b921348178839b60c515ac6acffd2") -- Beat Saber - Metallica - Creeping Death - Depot 3354480
-- Beat Saber - Metallica - Enter Sandman (AppID: 3354490)
addappid(3354490)
addappid(3354490, 1, "684cfef148c6863d0a434362a932ccdddea9f6f4ee623573894bbe4db073a40d") -- Beat Saber - Metallica - Enter Sandman - Depot 3354490
-- Beat Saber - Metallica - Fade to Black (AppID: 3354500)
addappid(3354500)
addappid(3354500, 1, "6f73df8bbc26936f5f9ee9d3bf031b9cb96617d8f8004038c2d04c9f8b01b808") -- Beat Saber - Metallica - Fade to Black - Depot 3354500
-- Beat Saber - Metallica - For Whom the Bell Tolls (AppID: 3354510)
addappid(3354510)
addappid(3354510, 1, "cdf9a89ede09ac5329e3ebf4a382e202362e63bcdaac2e6242724116ad9f2674") -- Beat Saber - Metallica - For Whom the Bell Tolls - Depot 3354510
-- Beat Saber - Metallica - Fuel (AppID: 3354520)
addappid(3354520)
addappid(3354520, 1, "cae25ace6d86b99623ce36858a35ba791294daf6badb732772c408fff65752e2") -- Beat Saber - Metallica - Fuel - Depot 3354520
-- Beat Saber - Metallica - Hit the Lights (AppID: 3354530)
addappid(3354530)
addappid(3354530, 1, "3afbba7ed07b20dc4d4fcf96652e58660e0caad3daf34c8df641a6152531195f") -- Beat Saber - Metallica - Hit the Lights - Depot 3354530
-- Beat Saber - Metallica - King Nothing (AppID: 3354540)
addappid(3354540)
addappid(3354540, 1, "b3616c6d174fc55806954b440ac06dae9ccd51ea95df214d12959dbc799a2d06") -- Beat Saber - Metallica - King Nothing - Depot 3354540
-- Beat Saber - Metallica - Lux terna (AppID: 3354590)
addappid(3354590)
addappid(3354590, 1, "705bb5987644ae5d173a84bfa143e26673f7808dc2911be17fe09a58565d4671") -- Beat Saber - Metallica - Lux terna - Depot 3354590
-- Beat Saber - Metallica - Master of Puppets (AppID: 3354630)
addappid(3354630)
addappid(3354630, 1, "bceb367a4621591786c1fd546ebd91fb148284e14f0f8110c32e18dbadf9e2d3") -- Beat Saber - Metallica - Master of Puppets - Depot 3354630
-- Beat Saber - Metallica - Nothing Else Matters (AppID: 3354660)
addappid(3354660)
addappid(3354660, 1, "8a30d03d4d146489e28e6f392fb7337deaa9281e1801fc7a5394b0140c23f403") -- Beat Saber - Metallica - Nothing Else Matters - Depot 3354660
-- Beat Saber - Metallica - One (AppID: 3354680)
addappid(3354680)
addappid(3354680, 1, "db60d605031c25897883d11ce16cd83a4e7f1870accc42c3032b4f2e28c62827") -- Beat Saber - Metallica - One - Depot 3354680
-- Beat Saber - Metallica - Sad But True (AppID: 3354690)
addappid(3354690)
addappid(3354690, 1, "ac49f77008afe547e74098da19f447568a23d0c76d6cfe50537f0210b1209498") -- Beat Saber - Metallica - Sad But True - Depot 3354690
-- Beat Saber - Metallica - Seek  Destroy (AppID: 3354700)
addappid(3354700)
addappid(3354700, 1, "246def1b055d85477302baed99216bac14b0d5ba4448169d5d95e44711ae642a") -- Beat Saber - Metallica - Seek  Destroy - Depot 3354700
-- Beat Saber - Metallica - The Unforgiven (AppID: 3354710)
addappid(3354710)
addappid(3354710, 1, "9cb792947a664eabd8d88efd302030a1caa5790bbf11c17d39f2c7631357fd6a") -- Beat Saber - Metallica - The Unforgiven - Depot 3354710
-- Beat Saber - Kendrick Lamar - Not Like Us (AppID: 3535520)
addappid(3535520)
addappid(3535520, 1, "166319f4c2d71e2e216fda19e51ee5ff1118e343a5a516a5c0610bb2ff652878") -- Beat Saber - Kendrick Lamar - Not Like Us - Depot 3535520
-- Beat Saber - Lady Gaga - Abracadabra (AppID: 3739820)
addappid(3739820)
addappid(3739820, 1, "07cd214abeaada3bde404c07269ec9d2c2455b678f1d5bc8c594066d2a152454") -- Beat Saber - Lady Gaga - Abracadabra - Depot 3739820
-- Beat Saber - Billie Eilish - BIRDS OF A FEATHER (AppID: 3804490)
addappid(3804490)
addappid(3804490, 1, "e38a4bb69cfdd7c2d7f6f03f803f5009ee0954a31af2c80ef206705b6f781e8b") -- Beat Saber - Billie Eilish - BIRDS OF A FEATHER - Depot 3804490
-- Beat Saber - Sabrina Carpenter - Espresso (AppID: 3842290)
addappid(3842290)
addappid(3842290, 1, "0b8e14160294fc9099eb9bbf74cd3827350a5e23cbabc217ac4c61c9808d444b") -- Beat Saber - Sabrina Carpenter - Espresso - Depot 3842290
-- Beat Saber - Katseye - Gabriela (AppID: 4002060)
addappid(4002060)
addappid(4002060, 1, "867daaa62a7287b0254ea0fc14f70760acf07f6da269281ca426f69975137db6") -- Beat Saber - Katseye - Gabriela - Depot 4002060
-- Beat Saber - Andrew Gold - Spooky Scary Skeletons  Undead Tombstone Remix (AppID: 4084510)
addappid(4084510)
addappid(4084510, 1, "b63bf4617260ba563e154c263364ed52ac60164bef20ec7a1a97b9d503691427") -- Beat Saber - Andrew Gold - Spooky Scary Skeletons  Undead Tombstone Remix - Depot 4084510
-- Beat Saber - Coldplay - A Sky Full of Stars (AppID: 4185610)
addappid(4185610)
addappid(4185610, 1, "db3eca62c65233b8c94d4bdc675919aedc42a1e89d5fe1761bd9018d627a086d") -- Beat Saber - Coldplay - A Sky Full of Stars - Depot 4185610
-- Beat Saber - Coldplay - Adventure of a Lifetime (AppID: 4185620)
addappid(4185620)
addappid(4185620, 1, "8d8b4b5e8c73b4372bbcec6f811b81db4d000ef471da5c0ab8b581150c751a3e") -- Beat Saber - Coldplay - Adventure of a Lifetime - Depot 4185620
-- Beat Saber - Coldplay - Clocks (AppID: 4185630)
addappid(4185630)
addappid(4185630, 1, "2bac04b493621817eeacf5ea86a2a5deaa4cbc45b64af3301bc97d16b2754e1d") -- Beat Saber - Coldplay - Clocks - Depot 4185630
-- Beat Saber - Coldplay - feelslikeimfallinginlove (AppID: 4185640)
addappid(4185640)
addappid(4185640, 1, "7ffbba17257c89a4ff30e29448c6497cf61b08229152badf54089c666a0a61ad") -- Beat Saber - Coldplay - feelslikeimfallinginlove - Depot 4185640
-- Beat Saber - Coldplay - GOOD FEELiNGS (AppID: 4185650)
addappid(4185650)
addappid(4185650, 1, "adc3ba2ab8cc39bccc1ff22562c5d3b617642716a17cd4f305acc3fff63704bf") -- Beat Saber - Coldplay - GOOD FEELiNGS - Depot 4185650
-- Beat Saber - Coldplay  The Chainsmokers - Something Just Like This (AppID: 4185660)
addappid(4185660)
addappid(4185660, 1, "49c7e0c694684eac9ca21fd655aacde3234fc03b7fa097e341c1485656e31c9a") -- Beat Saber - Coldplay  The Chainsmokers - Something Just Like This - Depot 4185660
-- Beat Saber - Coldplay - Speed of Sound (AppID: 4185670)
addappid(4185670)
addappid(4185670, 1, "65022e0c34bdbe291b89ca9c95e18affd31c4f42df470620a2f6c849d00754a2") -- Beat Saber - Coldplay - Speed of Sound - Depot 4185670
-- Beat Saber - Coldplay - Talk (AppID: 4185680)
addappid(4185680)
addappid(4185680, 1, "167a9b87dcb554a3b219c00ba4f3b72baf3c55b56cc9ca8d1756363ff3a226ca") -- Beat Saber - Coldplay - Talk - Depot 4185680
-- Beat Saber - Coldplay - Trouble (AppID: 4185690)
addappid(4185690)
addappid(4185690, 1, "775a64f3b012e58dd9f3d582df47be61ebd143285f373581aa55f7d3333fa116") -- Beat Saber - Coldplay - Trouble - Depot 4185690
-- Beat Saber - Coldplay - Viva La Vida (AppID: 4185700)
addappid(4185700)
addappid(4185700, 1, "dbddeb4ff4f8c13e75f3ee4fc4506aaf76363f481848a70ef2e13d2e9d9cc581") -- Beat Saber - Coldplay - Viva La Vida - Depot 4185700
-- Beat Saber - Coldplay - WE PRAY (ft. Little Simz, Burna Boy, Elyanna, TINI) (AppID: 4185710)
addappid(4185710)
addappid(4185710, 1, "82a75eb57b6f024adb428ee3366eedc4da5073037b81d079d7aa2afbf3ecd37f") -- Beat Saber - Coldplay - WE PRAY (ft. Little Simz, Burna Boy, Elyanna, TINI) - Depot 4185710
-- Beat Saber - Coldplay - Yellow (AppID: 4185720)
addappid(4185720)
addappid(4185720, 1, "2765274a453bab8e546078e691783b4fa91ae164a8b191fa569de314296915a0") -- Beat Saber - Coldplay - Yellow - Depot 4185720
