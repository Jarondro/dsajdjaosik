-- MAIN APPLICATION
addappid(2772750, 1, "c2b82ddb04972f8d5ccf9cdddf8ec154829cac844c5b19a794e31f8dcdc5151a") -- Age of History 3
-- MAIN APP DEPOTS
addappid(2772751, 1, "1ba0a188cd6a0fd66ff7664712ff982f4dbd0400ff82ebe3297a8d12a940be37") -- Depot 2772751
addappid(2772752, 1, "d8bcd81563f970ed4f86bd66a42a5031d3a55e4d4b7f8e4d7be864e7e345bfe1") -- Depot 2772752
-- SHARED DEPOTS (from other apps)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Age of History 3 Smaller Map (AppID: 3238550)
addappid(3238550)
addappid(3238551, 1, "8910addc49581eacd64fd6519ab7085bfb463d2eff0a850a9cabbb9960cffe85") -- Age of History 3 Smaller Map - Depot 3238551
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3250400) -- DLC 3250400 (unreleased)