-- MAIN APPLICATION
addappid(2288630) -- Taiko no Tatsujin: Rhythm Festival
-- MAIN APP DEPOTS
addappid(2288631, 1, "6247e146b14ff88aa5a155f90b42e263de32e1c0b1f6d0a681454ef040c60530") -- Depot 2288631
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2885000) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 1
addappid(2885010) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 2
addappid(2885020) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 3
addappid(2885030) -- Taiko no Tatsujin Rhythm Festival - STUDIO GHIBLI Pack
addappid(2885040) -- Taiko no Tatsujin Rhythm Festival - STUDIO GHIBLI Pack Vol. 2
addappid(2885050) -- Taiko no Tatsujin Rhythm Festival - DRAGON BALL Anime Songs Pack
addappid(2885070) -- Taiko no Tatsujin Rhythm Festival - ONE PIECE Anime Songs Pack
addappid(2885080) -- Taiko no Tatsujin Rhythm Festival - HATSUNE MIKU Pack Vol. 1
addappid(2885090) -- Taiko no Tatsujin Rhythm Festival - HATSUNE MIKU Pack Vol. 2
addappid(2885100) -- Taiko no Tatsujin Rhythm Festival - HATSUNE MIKU Pack Vol. 3
addappid(2885110) -- Taiko no Tatsujin Rhythm Festival - HATSUNE MIKU Pack Vol. 4
addappid(2885120) -- Taiko no Tatsujin Rhythm Festival - Kids Pack Vol. 1
addappid(2885130) -- Taiko no Tatsujin Rhythm Festival - Kids Pack Vol. 2
addappid(2885140) -- Taiko no Tatsujin Rhythm Festival - 2000s Pops Pack
addappid(2926150) -- Taiko no Tatsujin Rhythm Festival - Namco Game Music Pack
addappid(3068500) -- Taiko no Tatsujin Rhythm Festival - HATSUNE MIKU Pack Vol. 5
addappid(3068510) -- Taiko no Tatsujin Rhythm Festival - KAMEN RIDER Opening Theme Songs Pack
addappid(3068520) -- Taiko no Tatsujin Rhythm Festival - SPYFAMILY Pack
addappid(3068530) -- Taiko no Tatsujin Rhythm Festival - Anime Songs Collection
addappid(3068540) -- Taiko no Tatsujin Rhythm Festival - Pops Collection
addappid(3068550) -- Taiko no Tatsujin Rhythm Festival - Vocaloid Songs Collection
addappid(3068560) -- Taiko no Tatsujin Rhythm Festival - One Piece Anime 25th Anniversary Collab. Pack
addappid(3222440) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 4
addappid(3222450) -- Taiko no Tatsujin Rhythm Festival - Kids Pack Vol. 3
addappid(3222460) -- Taiko no Tatsujin Rhythm Festival - Touhou Project Arrangements Pack Vol. 1
addappid(3222470) -- Taiko no Tatsujin Rhythm Festival - Crayon Shin-chan Theme Songs Pack
addappid(3416750) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 5
addappid(3416760) -- Taiko no Tatsujin Rhythm Festival - KASANE TETO Pack
addappid(3416770) -- Taiko no Tatsujin Rhythm Festival - Touhou Project Arrangements Pack Vol. 2
addappid(3622740) -- Taiko no Tatsujin Rhythm Festival - KAGAMINE RIN, KAGAMINE LEN Pack
addappid(3622750) -- Taiko no Tatsujin Rhythm Festival - 2020s Pops Pack
addappid(3638760) -- Taiko no Tatsujin Rhythm Festival - Timeless Hits Pack
addappid(3837580) -- Taiko no Tatsujin Rhythm Festival - KAWAII Pop Idol Pack
addappid(3837590) -- Taiko no Tatsujin Rhythm Festival - Classical Pack
addappid(3837600) -- Taiko no Tatsujin Rhythm Festival - Kids Pack Vol. 4
addappid(3891210) -- Taiko no Tatsujin Rhythm Festival - Tamagotchi Collab Pack
addappid(3976020) -- Taiko no Tatsujin Rhythm Festival - Anime Pack Vol. 6
addappid(3976030) -- Taiko no Tatsujin Rhythm Festival - 2020s Pops Pack Vol. 2
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2288632) -- Depot 2288632 (empty depot)