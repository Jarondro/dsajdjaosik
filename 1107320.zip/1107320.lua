-- MAIN APPLICATION
addappid(1107320) -- OUTBRK
-- MAIN APP DEPOTS
addappid(1107321, 1, "6e3a930a48829c711299685f520f1f304a512102627facc243b6ff199e47906c") -- Depot 1107321
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1107322) -- Depot 1107322 (empty depot)