-- MAIN APPLICATION
addappid(264710) -- Subnautica
-- MAIN APP DEPOTS
addappid(264712, 1, "d764b2a41e9bdbf338f04948309614ea6f8d462073a610940aaf10cbfc35aa85") -- Subnautica (Win32 Specific)
addappid(264713, 1, "6da396b527d2b570a039778566cef5c1e94ba486fefa835553a1831e40353dec") -- Subnautica (OSX Specific)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
