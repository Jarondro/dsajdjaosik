-- MAIN APPLICATION
addappid(2497900) -- DON'T SCREAM
-- MAIN APP DEPOTS
addappid(2497901, 1, "42d0e96d7b5440cf0b812b5ec843e2e437e28ba281e46830a2d2d7ec65c2a030") -- Depot 2497901
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
