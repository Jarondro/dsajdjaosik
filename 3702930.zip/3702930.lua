-- 3702930's Lua and Manifest Created by Morrenus
-- Bum: Revenge
-- Created: November 22, 2025 at 10:36:56 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3702930) -- Bum: Revenge
-- MAIN APP DEPOTS
addappid(3702931, 1, "a124cb5f958b098d926a9c050c49f941b50919a19c594173111e0c3314a9ce31") -- Depot 3702931
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
