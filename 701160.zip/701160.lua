-- MAIN APPLICATION
addappid(701160, 1, "a870b8cb617fd6f06ec9d1b0a89f514f8611794aa043288467001423108182c7") -- Kingdom Two Crowns
-- MAIN APP DEPOTS
addappid(701161, 1, "5aae8ca5c454854bdf1b25248fe5f3c01a97c983489767c17930cc8a02156ac3") -- Kingdom Two Crowns Content
addappid(701162, 1, "17174ac183441ce4785eb189f7a80fc0fd9a202494cad02f1ddf4bc3d87aade4") -- Kingdom Two Crowns Mac Depot
addappid(701163, 1, "88068941a333be0784b8fd4fe2c414237610909671e189f3068177fc84e0352e") -- Kingdom Two Crowns Linux Depot
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Kingdom Two Crowns OST (AppID: 988810)
addappid(988810)
addappid(988810, 1, "09f7b9d014059b08ea21838c59e9edadb8d14238c0e97a6cbb6d597d98f49174") -- Kingdom Two Crowns OST - Kingdom Two Crowns: OST (988810) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(980450) -- Kingdom Two Crowns Shogun
addappid(1299270) -- Kingdom Two Crowns Dead Lands
addappid(1708680) -- Kingdom Two Crowns Norse Lands
addappid(2736340) -- Kingdom Two Crowns Call of Olympus
addappid(3062350) -- Kingdom Two Crowns Regents Royal Wardrobe
addappid(3062360) -- Kingdom Two Crowns Archons Royal Wardrobe
addappid(3939430) -- Kingdom Two Crowns Decennial Royal Wardrobe
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1708680) -- Depot 1708680 (empty depot)