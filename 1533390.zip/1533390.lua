-- MAIN APPLICATION
addappid(1533390, 1, "c15a118d74b34f83f4bdb726a158113fd949e1ddf81b62fb91023c1f8178a829") -- Gorilla Tag
-- MAIN APP DEPOTS
addappid(1533391, 1, "76a9af57a776f43d1f3210b9c3beb33607799ae510b2c235ba2964972bc6a945") -- Gorilla Tag Content
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1564750) -- Gorilla Tag - Early Access Supporter Pack