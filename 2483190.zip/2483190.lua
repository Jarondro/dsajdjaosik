-- MAIN APPLICATION
addappid(2483190) -- Forza Horizon 6
addtoken(2483190, "2264898939686399139")
-- MAIN APP DEPOTS
addappid(2483191, 1, "f2a09f0a31b4df681ec0d2d572f368dfa4cd6c37ae67ebdfd591cfbe1334fcd9") -- Depot 2483191
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4439260) -- Forza Horizon 6 Welcome Pack
addappid(4439280) -- Forza Horizon 6 Time Attack Car Pack
addappid(4439300) -- Forza Horizon 6 Ferrari J50
addappid(4439750) -- Forza Horizon 6 Treasure Map
addappid(4440380) -- Forza Horizon 6 VIP Membership
addappid(4444140) -- Forza Horizon 6 TBDS2
addappid(4444150) -- Forza Horizon 6 1962 Peel P50 Trolli Edition
addappid(4562050) -- Forza Horizon 6 Crunchyroll Voucher