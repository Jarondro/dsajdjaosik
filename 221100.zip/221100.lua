-- MAIN APPLICATION
addappid(221100, 1, "1166f7815221fcc3afac8682ba307d6496101848e6483b6bb838551f2923ae64") -- DayZ
-- MAIN APP DEPOTS
addappid(221101, 1, "9d9c5d3d77309bbe701a3f018cea877d22d07160b4ea2b65bdf261d0dc399c15") -- DayZ Content
addappid(221102, 1, "fe6ef04ad5778ee58766d4c8b7057fa84feb52c2cc0155d808fb40ca1bd42789") -- Depot 221102
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- DayZ Livonia (AppID: 1151700)
addappid(1151700)
addappid(1151700, 1, "ed6fa275132bd015ad355b4058b0e4af4a79d000c2f912d1e28a19185ef3c1eb") -- DayZ Livonia - DayZ Livonia (1151700) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(830660) -- Survivor GameZ
addappid(2968040) -- DayZ Frostline
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3816030) -- DayZ Badlands (unreleased)