-- MAIN APPLICATION
addappid(2211170, 1, "7f95f02126d3af11214a9b1d2cf98b80bf03d78ff1060e0300efab169fedd6f5") -- Unrailed 2: Back on Track
-- MAIN APP DEPOTS
addappid(2211171, 1, "924f04bf42410b224830a5cbe6e5fe8ed52b2cac3a5fc909505918bbbc2670c7") -- Depot 2211171
addappid(2211172, 1, "879213df7df2f8d81ca40e1598d934533921f4f74471a53394c8f611bdeec23b") -- Depot 2211172
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Unrailed 2 Back on Track  Supporter Pack (AppID: 3393870)
addappid(3393870)
addappid(3393870, 1, "677987212f50458d0f106db2ca80b57787838ed4128669ed85322d2923aa79b0") -- Unrailed 2 Back on Track  Supporter Pack - Depot 3393870
