-- MAIN APPLICATION
addappid(632300) -- Hobo: Tough Life
-- MAIN APP DEPOTS
addappid(632301, 1, "f1e3666450afb59a43038cb7afb583a66b9fe73e79e1d99db59e02c91abda29e") -- Hobo: Tough Life x86-64
addappid(632302, 1, "a527ac8279aef11cc243871b0fc7ccd2a75f4824c0a1fbb1dbc2cf42e6e365b4") -- Hobo: Tough Life Linux
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Hobo Tough Life - Soundtrack  Wallpapers (AppID: 1255390)
addappid(1255390)
addappid(1255390, 1, "cdf7211589ca4e6b4f300e61100324b6d46d63f067d323047ddeb5a34249f879") -- Hobo Tough Life - Soundtrack  Wallpapers - Hobo: Tough Life - Soundtrack & Wallpapers (1255390)
