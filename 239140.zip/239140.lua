-- MAIN APPLICATION
addappid(239140, 1, "603f510e836a35c1c124afb7b3f9c4e00ab385bdd7c98dd63802a55b80d5a062") -- Dying Light
-- MAIN APP DEPOTS
addappid(239153, 1, "c6fcdb2d6512b606f1a71ccfd84da3129320ac8e12dbda5697dc44ecf11fad86") -- Binaries_Release
addappid(239142, 1, "dd4be4c23d15015c47203ba5e576b7d94b1b6bab2d285a6f1d9907d91dc3afcb") -- Movies
addappid(239141, 1, "d43f22eb50617425e906b808de0508b5668219ed5de743ffb6a96d387ab9a5e4") -- Content
addappid(239154, 1, "bfd86bba87fa2e2fbc783dae0c2d82ea12dcf704223b5e8792b7f024b8e04783") -- DataPaks
addappid(239144, 1, "9a7e5678376e0b1680258b1ceb7cc050988ed630e40401332dbb4a2c4c9b6873") -- Game_Sounds
addappid(239145, 1, "9a406d0152999e5ac765192887fe0e4ddcc7b0cb978a5016096d35b14b7942e5") -- Common_Content
addappid(302100, 1, "f93071cd8a04fff9d35ac709416db9f5f8ed7cbd2000837e66f1224a24eab514") -- Dying Light - Be the Zombie Mode (302100) Depot
addappid(239143, 1, "784fc854e9b1df1eb26155a776d4898a0a35798e9378bcef02d4dbaf50c42ad8") -- Loc_EN
addappid(239146, 1, "5dc64f1c81d707eea75c7414b4db341e32e7ec5c51831561475fc1e35085c94c") -- Loc_BR
addappid(239147, 1, "3d07ffce6f87a58f62c4c998419b67751cee4fc6cda63134cfafc11eceba6b06") -- Loc_DE
addappid(239148, 1, "0f888096b96297181839f55ec15549e3a5f45e4d3a95e007faed839ab73c472d") -- Loc_ES
addappid(335818, 1, "31412e3233e1f94b35343da3ed6df1b3a0fe4856364a0f1f4f718d77b1ce88f8") -- Loc_EL
addappid(239149, 1, "51ba3027452ff645ac04ebea157e620d5a7dc9e69a2615b489a5bfd0dcc1e397") -- Loc_FR
addappid(239150, 1, "a4beca8cbfb6a2e1724935cc8fc91407fda50404785b56f30c5ee9a8f828af20") -- Loc_IT
addappid(239152, 1, "548581b46d068549522f09d9c16f3db62d67377d2461bd239ef4a9f8046e065f") -- Loc_PL
addappid(239151, 1, "472a27da2bafc64d66eacc81028e86787ec574ef87557c9bfc1c85e007f80e35") -- LINUX_CONTENT
addappid(239155, 1, "38994ccf16578dd6ecee834c698d9467a4006f2baa52bb4508fda5ba67a1be37") -- LINUX_BTZ
addappid(239157, 1, "2dccf962440b0f9b10bef2dc7c1be9dffbf18628bc7199b2a70c35dbab091c0e") -- Content_JP
addappid(239158, 1, "ac378571b7679bcdc1d121520eef910fb1594321a3da1c0cb42ddb8861169969") -- LINUX_Content_JP
addappid(239156, 1, "7d47deed0dcf10255f1d78245984940a4db077fa63dcfe90d1a43acd73bacfac") -- Workshop
addappid(239159, 1, "ca6a14b1a73be972a17a4a74da8c282fa11e21f481faeaac17583b35b3de9d9d") -- Workshop_Data
addappid(325726, 1, "df587ce217685b930ca1231ead3c361809aec59d70e1551a9d1bc2e453f775d2") -- Workshop_Data_JP
addappid(325727, 1, "8cec0f5de662b30815d9e1fc0b2ed0ddd98c777c17d34c191e5b70e252f85a30") -- Workshop_Linux
addappid(325728, 1, "8cf07633fe357e1530b178be6adc6815c68171db7c52e3724684286ef8224b7e") -- Workshop_Linux_Data
addappid(325729, 1, "71b442c82934c4edb53e5239ac4be12cc2e3fa08f9cbad06100c422dbd8529ee") -- Workshop_Linux_Data_JP
addappid(412920, 1, "49a79ba116a43c0faf88157d3782fa05e87c243b4fa282925833765b40ff40a3") -- Dying Light - Custom Maps (412920) Depot
addappid(412923, 1, "38e033dcfd431c291ef7f268b419378ceb258d6293fe5da0964e288ec478c094") -- Dying Light - Custom Maps LINUX
addappid(415370, 1, "5b742b871e541b3f673ab3bb9a045d38ddc6611199ad5fb1ee9b4c1511191954") -- Dying Light - Custom Maps 2 (415370) Depot
addappid(302104, 1, "e20d95329cf0de87109a1ba47f90db1d5d7354f0d1865320020692338667217a") -- Dying Light - Custom Maps 2 LINUX
addappid(325718, 1, "a82801b34ca486a45f4186589d34d58143fe2c80fa9381b12a4bc94e5208321c") -- OSX_Bin
addappid(335811, 1, "a2bf0d355bf9857928aaa28c99346f578bb5eadcbb712bdc057d04132572b39f") -- OSX_BTZ
addappid(335814, 1, "cc74f4dcd4043130d5cb2b80a32ff930c066f4b0762c584e91bb326a08fab33a") -- OSX_CustomMaps
addappid(335815, 1, "9190b1cf9453881520747438121484af7007f4bd6ef9ac11fa49b69f8793d89d") -- OSX_CustomMaps2
addappid(325719, 1, "f259e29c755201c3110814d2abeab64effa4e52fddf38fcd8df8097aa94c124a") -- OSX_Main_JP
addappid(347093, 1, "1c38c45a57985cdb2ad6e2d2305598c705f42d6cea289e364515df635175ad81") -- Depot 347093
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Dying Light - The Bozak Horde (AppID: 325723)
addappid(325723)
addappid(325723, 1, "ea4b42ffe42766d79d3ba8af8fcc61b28901bfab8ebb4ad8ea2920753f4ec442") -- Dying Light - The Bozak Horde - Dying Light - The Bozak Horde (325723) Depot
addappid(302105, 1, "d586eda8faec228ed8216b9f8915785830722cc601d0886fed441b58628fbb86") -- Dying Light - The Bozak Horde - Dying Light - The Bozak Horde LINUX
addappid(302106, 1, "ea32e751c5c9265cae9993356eda21134e864331942d960e677fdf088cfe4481") -- Dying Light - The Bozak Horde - Dying Light - The Bozak Horde JP
addappid(335812, 1, "af2ed455ce47b41581e161a7726a34fd1de02f6c267a2924b0d87185746a49e7") -- Dying Light - The Bozak Horde - OSX_TheBozakHorde
addappid(335816, 1, "0127239b7ec09183956a0819dedd109189ebdc1a4fe3da57dba1870660486a9a") -- Dying Light - The Bozak Horde - OSX_TheBozakHorde_JP
-- Dying Light - The Following (AppID: 325724)
addappid(325724)
addappid(325724, 1, "59d801db2b871628da195dca8a59d4c582c6b204a3892e1570cfa38d7e971090") -- Dying Light - The Following - Dying Light - The Following (325724) Depot
addappid(412921, 1, "c1b9d960bc29fb856a820b810396cf7b063e628fdd430fc2f4f5cb29ad1e24e2") -- Dying Light - The Following - Dying Light  - The Following LINUX
addappid(335813, 1, "5c6ec7e26c577c7f4652707d01411361fc5ef05d1db91d85a25e85fd451d90c5") -- Dying Light - The Following - OSX_TheFollowing
addappid(412922, 1, "550a7a9c831851105926c9a9fbbb20b5ced04aef4e629087164f19ed865e0085") -- Dying Light - The Following - Dying Light - The Following COMMON
addappid(302108, 1, "8b500ae36679ec190ce7d9ef7fc0ef40702d28d8ce3147147e999c0cfb0a9cb4") -- Dying Light - The Following - Dying Light - The Following JP
addappid(302109, 1, "c3c2748345f430bfc4864f0fa5e64405f9d6b75a923f2fa49fffca25e093db9b") -- Dying Light - The Following - Dying Light - The Following LINUX JP
addappid(335817, 1, "005d3890c451828fa134a96a0f5ecfa1493ae139db801af14e46d8926d4d8394") -- Dying Light - The Following - OSX_TheFollowing_JP
-- Dying Light Original Soundtrack (AppID: 798540)
addappid(798540)
addappid(798540, 1, "f2d0fbc465f9f5de6aa4123106369dccde6e646f37497de93c9bd1ace5a8f1fb") -- Dying Light Original Soundtrack - Dying Light Original Soundtrack (798540) Depot
-- Dying Light 3D Printer Models (AppID: 798541)
addappid(798541)
addappid(798541, 1, "7bc6d5d780053a9fcbbdeefee19589f1f25d0f605257fe728ccad3fdac856b98") -- Dying Light 3D Printer Models - Dying Light 3D Printer Models (798541) Depot
-- Dying Light Collectors Artbook (AppID: 798542)
addappid(798542)
addappid(798542, 1, "1e00c500f2e145f7f8a0a8aa8c45ccc4611dfd78861964393520fd17ef6e7b01") -- Dying Light Collectors Artbook - Dying Light Collector’s Artbook (798542) Depot
-- Dying Light Wallpaper Pack (AppID: 798543)
addappid(798543)
addappid(798543, 1, "8bde9e319ea58e4958ac96151ab460a48039a292e0a10a52f919a64197c17f97") -- Dying Light Wallpaper Pack - Dying Light Wallpaper Pack (798543) Depot
-- Dying Light Book (AppID: 1034630)
addappid(1034630)
addappid(1034630, 1, "e44584224e62e8fb38c5cce8c820311b3417d72e509f5148a8344c0bb8123ad6") -- Dying Light Book - Dying Light Book (1034630) Depot
-- Dying Light - Hellraid (AppID: 1300710)
addappid(1300710)
addappid(335819, 1, "40a26d78e3a4bf01c8fab0eb0d87f084049fde55819456e234b90f2d2d9d661b") -- Dying Light - Hellraid - Dying Light - Hellraid
addappid(347091, 1, "59ef657142ff4d99f9d19904a59b20df2dd95f45aa64000ea026d46692841439") -- Dying Light - Hellraid - Dying Light - Hellraid LINUX
addappid(347092, 1, "bac768ef68e46f172518b62eef2a2ae670199054c7c0e8eec3114b5981a586b8") -- Dying Light - Hellraid - Dying Light - Hellraid OSX
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(302101) -- Dying Light - Cuisine  Cargo
addtoken(302101, "11315058037702565365")
addappid(335810) -- Dying Light Season Pass
addtoken(335810, "10419984102394371097")
addappid(347090) -- Dying Light Ultimate Survivor Bundle
addappid(435111) -- Dying Light- Crash Test Skin Pack
addappid(436080) -- Dying Light- Harran Ranger Bundle
addappid(436081) -- Dying Light- Gun Psycho Bundle
addappid(436082) -- Dying Light- Volatile Hunter Bundle
addappid(748340) -- Dying Light - White Death Bundle
addappid(748341) -- Dying Light - Vintage Gunslinger Bundle
addappid(1112521) -- Dying Light - Godfather Bundle
addappid(1174580) -- Dying Light - Harran Inmate Bundle
addappid(1184350) -- Dying Light - SHU Warrior Bundle
addappid(1184351) -- Dying Light - Chivalry Weapon Pack
addappid(1241570) -- Dying Light - 5th Anniversary Bundle
addappid(1272090) -- Dying Light - Unturned Weapon Pack
addappid(1354960) -- Dying Light - Volkan Combat Armor Bundle
addappid(1454750) -- Dying Light - L4D2 Bill  Gnome Chompski Pack
addappid(1468290) -- Dying Light - Classified Operation Bundle
addappid(1498210) -- Dying Light - Viking Raider of Harran Bundle
addappid(1524890) -- Dying Light - Ox Warrior Bundle
addappid(1543420) -- Dying Light - Harran Tactical Unit Bundle
addappid(1599030) -- Dying Light - Rust Weapon Pack
addappid(1647900) -- Dying Light - Savvy Gamer Bundle
addappid(1697640) -- DLC 1697640
addappid(1702060) -- Dying Light - Astronaut Bundle
addappid(1762700) -- Dying Light - Van Crane Bundle
addtoken(1762700, "18173262258780104649")
addappid(1822810) -- Dying Light - Snow Ops Bundle
addappid(1935540) -- Dying Light - Dieselpunk Bundle
addappid(2971370) -- Dying Light - Standard To Enhanced Upgrade
addappid(2971380) -- Dying Light - Standard To Definitive Upgrade
addappid(3454290) -- Dying Light - 10th Anniversary Bundle
-- FORCE-ADDED DLCS (BYPASSES ALL VALIDATION)
addappid(1112520) -- Dying Light - Rais Elite Bundle
addappid(1174581) -- Dying Light - Left 4 Dead 2 Weapon Pack
addappid(1177880) -- Dying Light - Retrowave Bundle
addappid(1336220) -- Dying Light - Hellraid Beta
addappid(302102) -- Dying Light - Punk Queen Weapon Pack
addappid(302103) -- Dying Light - Buzz Killer Weapon Pack
addappid(325710) -- Dying Light - Night Club Weapon Pack
addappid(325711) -- Dying Light - The Lacerator Weapon Pack
addappid(325712) -- Dying Light - The Constable Weapon Pack
addappid(325713) -- Dying Light - Wrench Kiss Weapon Pack
addappid(325714) -- Dying Light - Ninja Outfit
addappid(325715) -- Dying Light - Urban Explorer Outfit
addappid(325716) -- Dying Light - Special Agent Outfit
addappid(325717) -- Dying Light - Techland Outfit
addappid(325720) -- Dying Light - Alienware Outfit
addappid(325721) -- Dying Light - Nvidia Outfit
addappid(325722) -- Dying Light - Razer Outfit
addappid(415360) -- Dying Light: Razer Nabu Outfit
addappid(435110) -- Dying Light: Outfit and Livery 1
addappid(436083) -- Dying Light: CD-Action Anniversary Pack
addappid(675860) -- Dying Light - Harran Military Rifle
-- EMPTY DEPOTS (no content on any branch)
-- addappid(302107) -- Depot 302107 (empty depot)