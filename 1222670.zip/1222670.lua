-- DLCS WITH DEDICATED DEPOTS
-- The Sims 4 Get Famous (AppID: 1235720)
addappid(1235720)
addappid(1235720, 1, "76f4d3b559bf2c31e90d7fec4d9548d042c1c149771cfedfd97de04893a05a89") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - Content
addappid(1242600, 1, "d5794cd59bf286e57ee93ca20df0b3bf6a3a752a3da0191160155eee2778e580") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - en_US
addappid(1242601, 1, "4fc4e8b32ee969f118d0aef5a552fde772b825aaf604f8997a25fb3f59b7e6a4") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - cs_CZ
addappid(1242602, 1, "da31d7bc1e5ba1ba78fc5c11843a0231de395fbeaa39fd34cd4a16de23713e4b") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - da_DK
addappid(1242603, 1, "13fe96a21341864b8cc528852351c2fdbe313fafa5daa93dbbd74510728e9fd0") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - de_DE
addappid(1242604, 1, "75a5c57d23ecfdca2b118c3e334688d52274bba166e8810694b79ba09c9d5082") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - es_ES
addappid(1242605, 1, "7291cc2b79799427dca37d8d3c6936ef051f3d1a2a9e8e3e164aacc04019e4f3") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - fi_FI
addappid(1242606, 1, "52c4b5618684908bf6257b5ad8663ca1ca74a87a6cbca9362347fbde948f50ae") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - fr_FR
addappid(1242607, 1, "8150d2e48b256aeac4e6cb0292f5b2b4ed01bee603c8a29ba22238fa4568fa40") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - it_IT
addappid(1242608, 1, "8b24c57a91ff20e48394aecd85425531ee0596c86ebaa8aa6feebe568406c896") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ja_JP
addappid(1242609, 1, "d09a1607ac35d5ec3f9d99edf6ada4eeb238cd4d57f02d176af74986557fcbfd") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ko_KR
addappid(1242610, 1, "e176ec57ef5f82eea5d5f06a2004102d1c035ed9ac9d80a456d1d938b9f2e4cd") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - nl_NL
addappid(1242611, 1, "a41d3aa000f61f68c1e7f15886da25acde87768d62c99466b7110dc87cc7a4da") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - no_NO
addappid(1242612, 1, "fcd533f9aef2d7f5e0e16644cbd2fd16586cb02de3ed7e27e5e18cef78ced037") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - pl_PL
addappid(1242613, 1, "736b74034ad04a7c6ea9f789a03da7f4011d32a9189829ed40bce644116e252f") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - pt_BR
addappid(1242614, 1, "3d407d6d8165d31cf48f5782c2032680cb8880e189735287763ed8b4db4ead02") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - ru_RU
addappid(1242615, 1, "998c7ec70332931e03c530640fc9881e11c3488ae14761ec63e9dc4f7ed3d29d") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - sv_SE
addappid(1242616, 1, "8b54d895ee7bd768211472a6097701e9d8b0f46110c8355650d992b4280d9f52") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - zh_TW
addappid(1242617, 1, "2c22805745266e0c4952b11df8b4cd0c04f8b882bbcf5b982984a1115ccaa31f") -- The Sims 4 Get Famous - The Sims 4 Get Famous EP06 - zh_CN
-- The Sims 4 Cats  Dogs (AppID: 1235721)
addappid(1235721)
addappid(1235721, 1, "483dff514bd49bfb7ed68486c8f2f97834e6004126684107795cd576c12ba1b9") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - Content
addappid(1242580, 1, "b31829f51ea023d1c7a2835040c7ae6fa09c3327f2613c9b8173c000bf6af61a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - en_US
addappid(1242581, 1, "08de37fe5b88d9a4b60c76c79562a06d5ae157285158c1e50fa3cdc7ecb7fb2a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - cs_CZ
addappid(1242582, 1, "0691c52806cfa895467a0b75de948a7644f453e54511e37ff0415f86e41ffd64") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - da_DK
addappid(1242583, 1, "28f0cb2c70545a9a6247fe8e0584e708b3be82281a9b4c50b52d3579131d7a22") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - de_DE
addappid(1242584, 1, "8d0ec291f23725ee9f6491d7c74058e8bbc816abcf9f303ac2fdb50bb39b780c") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - es_ES
addappid(1242585, 1, "16d602d5159734e426121c1a8e59fd1c5d7a57b6fdbb0f5552b2339813d43cea") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - fi_FI
addappid(1242586, 1, "72ea442535bf9d43aef53468cc69bb70f9b27faf048b309f137334e4a133b5d5") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - fr_FR
addappid(1242587, 1, "0616f103dad25cd754ada16b1458d4804fa2ce91fea29073f265e667154f355a") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - it_IT
addappid(1242588, 1, "2c0d2db0f52a2d694ad178546346b0c4fd0d9e273024a94495f106a9ee687448") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ja_JP
addappid(1242589, 1, "47ba97d4de79282c9e236f89f31bf6f4846b75f924b56a092d53a3381bfe2010") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ko_KR
addappid(1242590, 1, "4d9cce1be26628b33d4b2e7aa06e6a2329dc7d74aad8d2036e3b059fe2965502") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - nl_NL
addappid(1242591, 1, "6e1f356250bc32b6f079288a45ae4dd895f38c3156d52ed6467302d160462e33") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - no_NO
addappid(1242592, 1, "84f3524ca6c25b77092b70d8f5b649c2223e6aa4c580d50676965dc01f14d15b") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - pl_PL
addappid(1242593, 1, "35f1d37b8e256ade785397b026864364246b38668cff2403d46764793b70bc54") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - pt_BR
addappid(1242594, 1, "316f289d0b4e99cd3a36cc15f5ff0277bedd314fd7b9382bbb6e21178ae3e510") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - ru_RU
addappid(1242595, 1, "5357003ca14ceb98c8b4312f5b2e5141e5ab90ccceaa3fd0fdc460d5fc560d1b") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - sv_SE
addappid(1242596, 1, "2c8ab95723e7cfed205a13b9ffae75993dedc7c9120124579e9b8decb8a6fcf6") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - zh_TW
addappid(1242597, 1, "caaa64c2a3ba798ae9cc7c10384ab47405ae0b471d8791118dcc92f2db6d9b61") -- The Sims 4 Cats  Dogs - The Sims 4 Cats and Dogs EP04 - zh_CN
-- The Sims 4 Discover University (AppID: 1235722)
addappid(1235722)
addappid(1235722, 1, "2545f32279adbfc9d01ae04b3f218c0a44a03f902bb0193fabbbd2742114f2bf") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - Content
addappid(1242560, 1, "b9cd7163c51538c85cd1184c755a7eab59c260455085c30e68e7a84190c9fafb") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - en_US
addappid(1242561, 1, "1f1d8d62b6cdbad96484e6ab498109254cadf1c22aab7bec4ad875c616080173") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - cs_CZ
addappid(1242562, 1, "6f34a99bdba362632647149f675d917e7a53de93eb28f7a6be51629279511175") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - da_DK
addappid(1242563, 1, "3d4291b91f19ebe58b7d7d7663cf515cddd014f08adcaff2f12c5b648dabc21e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - de_DE
addappid(1242564, 1, "8998da3a8d5a06310883b6d3cadbd927f6cb3cfc7e992dca2c822ae44da19e1e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - es_ES
addappid(1242565, 1, "093013a9c9629039b8c6384b9f9bc7f6d0857a09ff2e52e9440ebd8864463f9a") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - fi_FI
addappid(1242566, 1, "ce72c122e3d7a6e0f8069bd470e9e67c9a7ddf6173cfa0a0392e8b657ac5ca5e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - fr_FR
addappid(1242567, 1, "6eb4cd371843458b15fc4e7709ff3144200291cd1539e3ef374dd3e756ad08a0") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - it_IT
addappid(1242568, 1, "bc05bb9448cab6d8989a33ba9b771e4c613864c582f6c058cdd08e66a6ba4d26") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ja_JP
addappid(1242569, 1, "f0c66dc164ef8f25ec5365943b55dc7ba7b218617ce55105b3f6ad7929410dc2") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ko_KR
addappid(1242570, 1, "1241ca2804c37090794ec587b0c96bda7e29471006d12ff7cc89a1d53c83693e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - nl_NL
addappid(1242571, 1, "07f120a282f98bded6d82988edeba01ec91b96e6f445903ea8d9f7ec4913c7ef") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - no_NO
addappid(1242572, 1, "d9717961f568b90efdb71b83a05d9fc0d9c816c001f9be43bf3020afa9286c61") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - pl_PL
addappid(1242573, 1, "82dd006270258cce2d65345d9cb7e7ca01822cc648636de74296795bf9e5b8a8") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - pt_BR
addappid(1242574, 1, "9eed9f834d80ed1063e5bc4768e00a4bdc9f0ceaa06833a68b8365b208073f30") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - ru_RU
addappid(1242575, 1, "8a2f9f33a2a3ad963041546c7ada095ee3d24c4146857ad79ad0107cb426cf19") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - sv_SE
addappid(1242576, 1, "d13f25dc0273a49e5d58c85006cde6d7f7131cb78a3f6289396d3686ef76a047") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - zh_TW
addappid(1242577, 1, "7964888ea91e1727f2eba18024e36fee1b0649271d95da1b18bea53c589b450e") -- The Sims 4 Discover University - The Sims 4 Discover University  EP08 - zh_CN
-- The Sims 4 Island Living (AppID: 1235730)
addappid(1235730)
addappid(1235730, 1, "5e8313df06231219c9c25f8af37432ad21a315d8789674b1393840aa8fd2c29f") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - Content
addappid(1242540, 1, "03d316e616ad469cb44cf76fd6b4adbe39455fe9f765d845dfffe850200496cf") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - en_US
addappid(1242541, 1, "fb3b5ecc31b8f312d7fa89c0c1778f5d09189dabcf6c05cb72a2c6b4999b8164") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - cs_CZ
addappid(1242542, 1, "93867a55f077acdc38a577f1ab7c8a5040dbe25112c61f7a6caaab418fe7524e") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - da_DK
addappid(1242543, 1, "cb3e5919ce5d590d23b96a9922906634ac868685be42da871407f5a786c60538") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - de_DE
addappid(1242544, 1, "cedfc7394ed20e68bf8e6e684319f5f359ad6641fa40dcfb1d11c2266135ebf0") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - es_ES
addappid(1242545, 1, "ed2104cdfc541248a8b980fb9477c581636160ca770150eafd213c1d48570d77") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - fi_FI
addappid(1242546, 1, "c6b9718eb6293793ecdde475351186fc47ed4eb229a7afae93e42bcc657a2c27") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - fr_FR
addappid(1242547, 1, "09968dd4e6b6edd7adb58a65a575709d3bb3ac40af9082ffc4cb0e3121b6db5f") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - it_IT
addappid(1242548, 1, "216ba5c03bc607009f5c9174a44df5760cd785497be4b6f01454e84a98d31ee1") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ja_JP
addappid(1242549, 1, "cc669e800ac637a46abfe39d50604634bb7e617c0e9d895a5165cdd93605fe01") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ko_KR
addappid(1242550, 1, "61f5808a718df45a54cfd1e1f3d75d056ad7febc27af35b4af08ebb0de471a89") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - nl_NL
addappid(1242551, 1, "3e7ecf63b29610ff473167a6cc8e0c917fae3e56a77d37b07ad037a244b21388") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - no_NO
addappid(1242552, 1, "016f8e211657d1c3cdf350144ba4f11165807ea45383041ab3a94d040e36ef23") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - pl_PL
addappid(1242553, 1, "eb9833c4063ae4fb7c473219a14908cfa883c940e1ec5f23bffe742a1cbd486c") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - pt_BR
addappid(1242554, 1, "bde62fffe4097a2b87de0e67e44b6fd35c6dfe722c0ea44b098b546637fcf93d") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - ru_RU
addappid(1242555, 1, "4d131733e81de463cee8f3586724bc7ed8d335fd4b275469f31fb4955c0944bd") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - sv_SE
addappid(1242556, 1, "349dd497f2d68bc3c6dd62237d09c6aed51210f45a77976e4faaa2beea5c930e") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - zh_TW
addappid(1242557, 1, "4e0dd93a490320ba7a337ce69420313f040e6b455a8ed9347bd2a345655acd3d") -- The Sims 4 Island Living - The Sims 4 Island Living EP07 - zh_CN
-- The Sims 4 City Living (AppID: 1235731)
addappid(1235731)
addappid(1235731, 1, "6d7aab23cbaec96118a4e48b93128cb763d1ad95c1bfd5c1cce3e6d5d6ad0d3c") -- The Sims 4 City Living - The Sims 4 City Living EP03 - Content
addappid(1242520, 1, "5f1533c8b0e89268f59e03a873b1bac518cfe6b6d44a74ba5aff8708d6132de6") -- The Sims 4 City Living - The Sims 4 City Living EP03 - en_US
addappid(1242521, 1, "3dee0b2e8737fc05ed6d505a5777a9d1a6d392eb026edaecad3b9c188187475c") -- The Sims 4 City Living - The Sims 4 City Living EP03 - cs_CZ
addappid(1242522, 1, "c88843e35deb5ac665644528237813e260dea0f76839b9d2ac83a12283ca1676") -- The Sims 4 City Living - The Sims 4 City Living EP03 - da_DK
addappid(1242523, 1, "8e3db3c5a8814013480b6f0fcce791d3939702186a68f4701b432665ae81acf6") -- The Sims 4 City Living - The Sims 4 City Living EP03 - de_DE
addappid(1242524, 1, "6b0d762043b55dc20a1d57c10e91f6946f8aad9fca82169bf603e989de3fe393") -- The Sims 4 City Living - The Sims 4 City Living EP03 - es_ES
addappid(1242525, 1, "7987c0ec5c9630736a97fd7a40e94a9ea80a20c092158dd1e210042044569404") -- The Sims 4 City Living - The Sims 4 City Living EP03 - fi_FI
addappid(1242526, 1, "f35a35fdc3d81e3bf65d5ccbd5d9d6d3f33bfc28bc77cdfcb9d6d8515a6f5284") -- The Sims 4 City Living - The Sims 4 City Living EP03 - fr_FR
addappid(1242527, 1, "5fc267f6f983f0fc41416b6f9b9f3f620826b1b561af6fab7ecfea71d2a164c0") -- The Sims 4 City Living - The Sims 4 City Living EP03 - it_IT
addappid(1242528, 1, "7d99b15647b43b650f9118dd9be36d3f84631260430ae0cbffd7ebc54c4fbe6d") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ja_JP
addappid(1242529, 1, "61607aaee4a594e99ae54c5f3964a5bd85a5eb61d4ae5c1aea34af1951dec8be") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ko_KR
addappid(1242530, 1, "13222ba49ba7a42aaa1f3a7e43ada1088b014dbf6ac6290f6491a737a4731294") -- The Sims 4 City Living - The Sims 4 City Living EP03 - nl_NL
addappid(1242531, 1, "0c11ebadaa5b3078c720bea79128c7e2874dcae86d24210ac6069e5ce654a03f") -- The Sims 4 City Living - The Sims 4 City Living EP03 - no_NO
addappid(1242532, 1, "438855c72ef9f2679e27fedb05b78708674a6d74f004451656e4c221e36d4894") -- The Sims 4 City Living - The Sims 4 City Living EP03 - pl_PL
addappid(1242533, 1, "0df2f0bbf333fcbb1f65d8d4d31fd3bc0afd5a5d8929f201b747fcad2a5a4dd7") -- The Sims 4 City Living - The Sims 4 City Living EP03 - pt_BR
addappid(1242534, 1, "4412d858bade6fa72315ff27f8f8234a89fa90e82555d0239eff971b3e090ded") -- The Sims 4 City Living - The Sims 4 City Living EP03 - ru_RU
addappid(1242535, 1, "d35c755226e8219a44930695c8de852b69bbf7af485c24b5c500c5f379c8ff98") -- The Sims 4 City Living - The Sims 4 City Living EP03 - sv_SE
addappid(1242536, 1, "389251124fbd8e802d28d030ad042d53c155ea30893f43a021e3dbe806c63329") -- The Sims 4 City Living - The Sims 4 City Living EP03 - zh_TW
addappid(1242537, 1, "5fbe2eecdea9c52bb8b6de52d5f11e2feabec1be35d759648323216ffa6b1d9d") -- The Sims 4 City Living - The Sims 4 City Living EP03 - zh_CN
-- The Sims 4 Get Together (AppID: 1235732)
addappid(1235732)
addappid(1235732, 1, "8bc663d1862329d5e336025099a6283180bdd74641a56449c76eac28468ca2cd") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - Content
addappid(1242501, 1, "d58f23b65647bc328733eae187997ecfa33936ddd7aea09eb258b677f57f7977") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - en_US
addappid(1242500, 1, "934f95c36fb3f0efaee4cc715331294694119b0f41767f0cbd35e0b182c8a8ca") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - cs_CZ
addappid(1242502, 1, "3ef787252f49be7904a1d69000c937c2192e555c7b4709fb345003049d04cd0b") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - da_DK
addappid(1242503, 1, "9d3073126fcf43ebc6bcd8f64ee713bfd6e4d0a0a0dd68a0ac9c35c050b0c0e1") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - de_DE
addappid(1242504, 1, "3af973b39a580769e7358175398cb70b8b7e7ca7c3cfc012d39c9fd6cda50968") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - es_ES
addappid(1242505, 1, "4ed4b2eb49caab04ff97e8db56fe49661f2addaa2656c627a5b2dba4d9c7a678") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - fi_FI
addappid(1242506, 1, "bce117fd50204ab12af561a06be5307e1eb757462ef2cda046a259c098f7961b") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - fr_FR
addappid(1242507, 1, "01e387d2248626f86e28256fe1f8b015d84c6401e85dcc841a3d462979b8df27") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - it_IT
addappid(1242508, 1, "ce84fe991ba98a3190b1c269a13f602001990791b0c24e35bb7afd2479da45c6") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ja_JP
addappid(1242509, 1, "cff56860521df4b7cf1fa11c7f3db98ef569600b78f3354eabc593fdf17a4dac") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ko_KR
addappid(1242510, 1, "0b8676560a7b96b8571c14fc1528c0efb15d0b27c0f90936e73ad52c99fac9f4") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - nl_NL
addappid(1242511, 1, "d0b44ded560bf148c636a96d85a138fe4bcb9e8448f5c86f9578372576412b52") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - no_NO
addappid(1242512, 1, "1aae5163b86cb73c2c6e6a7d02ec73987c176148b213d777436c7a87c315deea") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - pl_PL
addappid(1242513, 1, "8b788f23f74167ca0519244a5966cb8af44278ae0ac0fc34b9d99dbf4ea57fd6") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - pt_BR
addappid(1242514, 1, "c9a71e883489fed647ee549d6d684f8d4507e02941cb4bd26fc028b7a3ef362c") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - ru_RU
addappid(1242515, 1, "8ffb76a4e64cbd3a9e3c2e648fd3ac333fb828252e228f6ba67e53271388134f") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - sv_SE
addappid(1242516, 1, "04a7cb531d4f08c7900e4c6366b0d54ab4a066cf869bdee0cfa422669eaec696") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - zh_TW
addappid(1242517, 1, "cc1a1cff83c5a22a6cb99c0cfb3a59536b5bfb3c917adcec2846ee6e7edb88b9") -- The Sims 4 Get Together - The Sims 4 Get Together EP02 - zh_CN
-- The Sims 4 Seasons (AppID: 1235733)
addappid(1235733)
addappid(1235733, 1, "af51b2f926d4bc8e82a0fcd3e1fdd584dd195a11b8f1ac833418a9caacdc84b3") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - Content
addappid(1242480, 1, "7fd9980d2e5e63eb951f1623930db503cc757e096bf70abe40fdc7b792df5921") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - en_US
addappid(1242481, 1, "2667e2fdeed7236bdb427c57402d9559b0cf515dba4082e763b57cc64c9eb956") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - cs_CZ
addappid(1242482, 1, "a17aa075b8d644536ca55642105716e565af7eeb57ecc770a14cad90fd63fe1e") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - da_DK
addappid(1242483, 1, "cfbc271f35a9ca1179907d6c6a5cfbbeb1e7389fc42275bd78c97ab61cc2dc76") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - de_DE
addappid(1242484, 1, "4154289dcc74fe2a1692575d351b62a534b8e6adbce712d4e885679784b07af7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - es_ES
addappid(1242485, 1, "888c22e5eeec6283f2ded4cc99994dd7c17a037f89ac209e4b04b8a13f8e0aa1") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - fi_FI
addappid(1242486, 1, "49834d70704b7363d7c1fd0b260379a46a433a4430eb41cae17b619b8be930cb") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - fr_FR
addappid(1242487, 1, "3301ce54343556bf1262c94adc28dff951bc47edcf09b4618eab00684e356358") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - it_IT
addappid(1242488, 1, "f483c7678b4d8f80d83fc1fe38840487de394536eeb8edd8a247d7777b9711cb") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ja_JP
addappid(1242489, 1, "2080b6794a8346cb9d4d933701e336441bde57b5ae1585967fe2208000406ed9") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ko_KR
addappid(1242490, 1, "ece50ee0ecbbf0aa652fe65467abd4a62c8b569d2c2b8248c5af221219e21f20") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - nl_NL
addappid(1242491, 1, "a1cb00bd18745c274be1eb3ba9609a99f745d2aeb2555163fd0a879c2e26ad1c") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - no_NO
addappid(1242492, 1, "3ee9f309b95c2c3427460c93e319aaa69b78b0b52d3a4ac400ce229803acdfa7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - pl_PL
addappid(1242493, 1, "70bcb9893e7889943329fc57e4e5edb178f98bc04133231e931e81ed05d305cc") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - pt_BR
addappid(1242494, 1, "2f4ed3ed8659a49fd5942a44adef2004c1b7cdcad9f28a1429627a7bdb46f0e9") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - ru_RU
addappid(1242495, 1, "125097402c1413608a32f4d4b6cc493e4ae2113de325e85ee8ee6578d184d4aa") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - sv_SE
addappid(1242496, 1, "0859bfdeadd8c2b68502e1460be81e373f028b61d395cc1a50e326421dbe6e3e") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - zh_TW
addappid(1242497, 1, "923533be8d3da5bcdd85371b4d444cdd7ac69b8698b976d834bc72dbbc8ed3d7") -- The Sims 4 Seasons - The Sims 4 Seasons EP05 - zh_CN
-- The Sims 4 Get To Work (AppID: 1235734)
addappid(1235734)
addappid(1235734, 1, "8dcebcd1ba1122e8ff0237500bb6707d7f86738ac4484321f7b09fec2ae4be57") -- The Sims 4 Get To Work - The Sims 4 Get To Work Content
addappid(1241890, 1, "c806939b2c0069b74813ee73c89f203207ff783f7074118b267fef8de493d72d") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - en_US
addappid(1241891, 1, "bfc4d3683d81a83f15b8b0ebaf8ad8181507e16023053a952294cf9706a97385") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - cs_CZ
addappid(1241892, 1, "e671aa4f3a7e351e1d14c9760c6b737eda6166b05df19f12e4f5772e46e5a47d") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - da_DK
addappid(1241893, 1, "18e39893a8289c96cf1b0994d9e3645419c1bb99d9dfde4aed6d77aa4aac5d0e") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - de_DE
addappid(1241894, 1, "c82ca76a5e7932baf01caf209a62ea5613125353aae200b46f0646c8e5a15c74") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - es_ES
addappid(1241895, 1, "dbc9d0dc563f898c77655e48d19f33f57552752a7accfa7b20a33d28d06a93d6") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - fi_FI
addappid(1241896, 1, "4ce8e73ddd2dc1dd809dbb4c9437d7445ae2a31e6aca9beb0589881f1c81719c") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - fr_FR
addappid(1241897, 1, "ebb3f1c9c197b10e71312726cf2b7675893245c51d1424f806a49785c95e4e04") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - it_IT
addappid(1241898, 1, "aa1ee8c4b4c9a1646b9591e052d0efa1213b0a0ec1833c5281ca9d359c3f2a6a") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ja_JP
addappid(1241899, 1, "939f76eaa28302ec078c5eb4dd61d4040495bcd3ac3b3f8bcfc711167fd5050a") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ko_KR
addappid(1241900, 1, "539b1cc8408a7bd25e596d03f201ff6b51aaff85871bbe5454c3574e082c5422") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - nl_NL
addappid(1241901, 1, "c9e58204f73924284a6c5d15af4deefc4cdc32c22455367a0e3bd65056a239d3") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - no_NO
addappid(1241902, 1, "337e656c75f8bd43052510b9f5d5d18d88e87dad18b0949552e1168346613dc3") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - pl_PL
addappid(1241903, 1, "87bd42449aa8726f6b316f64d92e66996012fff78c3c06dd3358458f69a7315e") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - pt_BR
addappid(1241904, 1, "c180a0df0de6b9914bca37c7d66c17bcfb53ef31a7619f4b446788892916ac5b") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - ru_RU
addappid(1241905, 1, "a6e6bc835088d989f990ca283099823919050bed19843056933366ffc846c36f") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - sv_SE
addappid(1241906, 1, "8cc02aad2ffc7dbcfe0f589d1ed68b35e7b3bb05efb99449254a85424558df49") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - zh_TW
addappid(1241907, 1, "4878197bf6a8e3efcdec2c963a50b2b92e67277e59f4ebcea91c2b76f5ecc3a8") -- The Sims 4 Get To Work - The Sims 4 Get To Work EP01 - zh_CN
-- The Sims 4 Spa Day (AppID: 1235740)
addappid(1235740)
addappid(1235740, 1, "046a6953baedd6038887f74573a2bb3bef55ed18df04f0e08f1cd11d1c06be34") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - Content
addappid(1235748, 1, "2ef232496679e44bee1e4dd6ff4f0b7c0caf9ff4726ac5a983f85793f45eab92") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - en_US
addappid(1235749, 1, "8a0550195480f372ecf5b53e1eae2b0fc00949f0ae0196994c36a4ab68720974") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - cs_CZ
addappid(1242461, 1, "23f7097ca66afc99aa1a3542946e6cfde9c7a859df6c4aa2a530cd33e90d47ef") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - de_DE
addappid(1242462, 1, "554e337d38cc7f07a9340adab0d6b93b0bdfa95bc3a1a5049d042f6071c04d7e") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - es_ES
addappid(1242464, 1, "6bf24132e86958bd2fe332b2ab3b08e0abcd63b245540415d33587675890f7b5") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - fr_FR
addappid(1242465, 1, "b551403fce9c432ee67c9e99b5916a8cfdce135ebf14ff9fe51b618813a5d658") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - it_IT
addappid(1242467, 1, "c0d34a0c772250c5dacc86ba33924d16a56d4fb7d6c3f6662cfb230cb7aeb41f") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ko_KR
addappid(1242468, 1, "46682f7482d8b9cdfe9aa650cd2f3fbd88e140522ba6ea3730cf127eddcf119c") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - nl_NL
addappid(1242469, 1, "de9062c92b4b22e00312520909a75b09945926f5e9d957972639a6fabe592123") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - no_NO
addappid(1242470, 1, "5df1f74426df363694fb1009cb210db4d5a3bba3b4b950a89a0d0e4bb60023f3") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - pl_PL
addappid(1242471, 1, "7f3293c5f911ed171913e740b1c6c1a56b6e225a1697e2589d93557e52478bdb") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - pt_BR
addappid(1242472, 1, "d8139387657cc705947d83a1b3ab4ec2b1f0a9e86b6774b2bda0f2253100cec5") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ru_RU
addappid(1242474, 1, "82b20cff19442cacb8fe8edb07b4621da37eb3db094994a0607c380ca10a751d") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - zh_TW
addappid(1242475, 1, "5e37a17996eb1197d77d260ed148479ccfe30eb64482f57024ab86ef10ec10b6") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - zh_CN
-- addappid(1242460, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - da_DK (no key available)
-- addappid(1242463, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - fi_FI (no key available)
-- addappid(1242466, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - ja_JP (no key available)
-- addappid(1242473, 1, "MISSING_KEY") -- The Sims 4 Spa Day - The Sims 4 Spa Day GP02 - sv_SE (no key available)
-- The Sims 4 Outdoor Retreat (AppID: 1235741)
addappid(1235741)
addappid(1235741, 1, "d52ba28c7f9084f59080a16bc9f45d94fd1f949d876e8ab79f0a87157e548c2f") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - Content
addappid(1242440, 1, "ffa8d2569708613c0a3a8754c9a1132d101f643660fee7f8b0587b56a567b6a3") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - en_US
addappid(1242441, 1, "fb20390884604d510f55d474c7175438f569c5d86600cae071552a68b6004c20") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - cs_CZ
addappid(1242442, 1, "a8b5b0a1a596eac1089dd8e9eb87a85b3a9511ee3051ffe3e03ac9fd92e42198") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - da_DK
addappid(1242443, 1, "496ee2e61acbae96ae5b8dd40605d71fe039284afdd2b6746308799d86d8b0ae") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - de_DE
addappid(1242444, 1, "380646b49b04df47fe67ed4f2c3ef7a2b865c351bae53a0a2d93f1f1d1367710") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - es_ES
addappid(1242445, 1, "30c407c0d1a771887b2a32da3c8ba69fdd2ec821a9eb28e989584a28390ca2c0") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - fi_FI
addappid(1242446, 1, "fba0d5d8daf28ed5770b23016bdda87932e00c0f7a53616faefdd66397e1b261") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - fr_FR
addappid(1242447, 1, "7af2973fdb84802348895a6f6f4d6dfa2ba3a49677689f4fe1ac605f27bd8df2") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - it_IT
addappid(1242448, 1, "447d47855080ab2f6d1131f1cb0e8fed8f45c58a870fb7de7bfb3672d260e194") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ja_JP
addappid(1242449, 1, "cd2cb0c9894631f06fccff2439792f2fbe54e897d1280046ee9947eca2275f03") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ko_KR
addappid(1242450, 1, "36e884d0e010c4586d5d8c4ad3da3dab752898ee3bdd33fe7f79042b36e74dd2") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - nl_NL
addappid(1242451, 1, "6d6a444b61437edfebcce5cda8207d1c29685396147f16fe3e1a417de1e2c1e7") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - no_NO
addappid(1242452, 1, "07d3c83b1848415860cf286e3d03ba5a1597c2a13b4eab44819ffb8ff25bbb14") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - pl_PL
addappid(1242453, 1, "1b9978cbf9bc88c4942391488d95b926cd76706b2033184c2712522bfa5f596b") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - pt_BR
addappid(1242454, 1, "0d9641c085c0ad448849a166647e8258776419db90271cab4c3b02656fcdd058") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - ru_RU
addappid(1242455, 1, "63b71162d20e9f5fcdd6c65840cb6ad507e683bbb44954df491ee4967f255209") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - sv_SE
addappid(1242456, 1, "f52d4424606dc11589946cc8042950764f5e4e7e0496f3af0e126dec3f97552e") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - zh_TW
addappid(1242457, 1, "e7ae8732614bbf08b35a543277c51f09ddcdc689c484950e61f30e7a42d5edc3") -- The Sims 4 Outdoor Retreat - The Sims 4 Outdoor Retreat GP01 - zh_CN
-- The Sims 4 StrangerVille (AppID: 1235742)
addappid(1235742)
addappid(1235742, 1, "3799b6a868ec9c3485d62a52f4820ab27eeeb86f1e99e3472863be2bfea2d92b") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - Content
addappid(1242420, 1, "67be7f118d8265ad41c7f7d8ac3f7c397b51677c9d301dc409f591a4842bef9f") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - en_US
addappid(1242421, 1, "11d63621f7109047cbd0ba663fa4b7231a006b7e283a544140818d6704d48f65") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - cs_CZ
addappid(1242423, 1, "baef1066093469854f2730722bbd92a8a254f32586443bda3a9376431cca728a") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - de_DE
addappid(1242424, 1, "3a4449983e0bfa7853c6f682de0a912b50ae88af0f14a28bf47aeb5cea090057") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - es_ES
addappid(1242426, 1, "7bd48d70d7f0db9e5971a4cc5424307f411303cab3f2a151099d4e8fa1440b33") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - fr_FR
addappid(1242427, 1, "fdb7d14be227fded751f87e1c4df5fda28fb40286ce38a6bb06506534d075bac") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - it_IT
addappid(1242429, 1, "16337689578cadc7aca3388bffb373548c421f07ee4c46d4a756702662b79dba") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - ko_KR
addappid(1242431, 1, "fc944eb3d5c19d54890e35217c4508f54f54ca13c2f447232921cf85c6ce2858") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - no_NO
addappid(1242432, 1, "d7defa495615219bf083dbed31a191081bde580a40711b2ca65018e2d6576357") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - pl_PL
addappid(1242433, 1, "81d7490112ffafa28032372d79e9eed966c3eefb7f291eba2e223abc173bc62d") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - pt_BR
addappid(1242436, 1, "8cb6a7045f0171bcd1fa83c4b11d1f4d0d3ce486a462147aca7f53344dc1b888") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - zh_TW
-- addappid(1242422, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - da_DK (no key available)
-- addappid(1242425, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - fi_FI (no key available)
-- addappid(1242428, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - ja_JP (no key available)
-- addappid(1242430, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - nl_NL (no key available)
-- addappid(1242435, 1, "MISSING_KEY") -- The Sims 4 StrangerVille - The Sims 4 StrangerVille GP07 - sv_SE (no key available)
-- The Sims 4 Vampires (AppID: 1235743)
addappid(1235743)
addappid(1235743, 1, "bccad078d050f5b15d0cf21e579fb25316b34ae9ca0bd100d85bfefb1b6a582b") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - Content
addappid(1242400, 1, "39adb755791854f4ba4985ceed56dac020bd593b2c5bd94570a0743bcc860c2e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - en_US
addappid(1242401, 1, "7b9013be2b01896bf2781e80d4bb851390cece38d68789c437857a183248a11c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - cs_CZ
addappid(1242402, 1, "ba3384cc66c7bacd98a857f8e32eb3ee998d5b6ba30b98606a6a68605b77dc9c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - da_DK
addappid(1242403, 1, "f5c16424975d1ae5f6fe5a3fb9a1450bc3a52e11cff60477a1506a077aae6851") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - de_DE
addappid(1242404, 1, "82b04a05575316905c663c2ba341dd1c76627a3a9f9c64e7ffbfefb9c00b0c61") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - es_ES
addappid(1242405, 1, "35e65ec257068a815681f88d07c1b7ac020b4d0ab9be4ee1196fc8daaa55977d") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - fi_FI
addappid(1242406, 1, "57e50ad790679709691994aeb1e6728d92ab5bfe22f9d8ae647fed2205922671") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - fr_FR
addappid(1242407, 1, "a03c6fb84c546c840d6c1f64560f6393e9b11a153c6fca60024ffdd9b362eb7e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - it_IT
addappid(1242408, 1, "4a3dbed094c8ba5a81e9baa3155b840b9514f7879160f7fbccdcc7b989a1639a") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ja_JP
addappid(1242409, 1, "7e22b15a1d71d5795a7e4eff3294f9e43a9a39409ab40b80232c54da0b8d023b") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ko_KR
addappid(1242410, 1, "a4c0f3b12af21c700c4f826dceba7a4f10722fd9f228eee17a149a35e11d1ebe") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - nl_NL
addappid(1242411, 1, "7f40bb9f59dd99678d0aff0a61bd10bac4001dd1fb2623f7d66d4b29dd1980de") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - no_NO
addappid(1242412, 1, "d7482a6408de37affb28947d26a0dc2e7da8adc83c59d75fb555ae93ea54c9f5") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - pl_PL
addappid(1242413, 1, "5a21af566723b17790438891c998190c309152007fb3b132bbb1d97192a15eb6") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - pt_BR
addappid(1242414, 1, "50995abc32a63611e39113f4a1d222f0a30efc12acee7ae365c0a4cc53b6f201") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - ru_RU
addappid(1242415, 1, "af176e23c65b750a17f49e9d6721525fd5db813701759331749d9b2b2b417b9d") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - sv_SE
addappid(1242416, 1, "731133d479cd78beebc3c226ca6c0d9df1fc8dabf173288faa9beb8f4413d58c") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - zh_TW
addappid(1242417, 1, "998137ba93052015344782f47562f4f0f7b48489d7ad9f355a7d57f06f01335e") -- The Sims 4 Vampires - The Sims 4 Vampires GP04 - zh_CN
-- The Sims 4 Jungle Adventure (AppID: 1235744)
addappid(1235744)
addappid(1235744, 1, "072c8049081ef4a4677d0ebedfc10a2dd9543f920e8e2dce09015f439b7d0e5f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - Content
addappid(1242380, 1, "fc75a14a98da4dd176e1fbeed23e83491919bc505324b719b8ab1b4b2160e3b2") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - en_US
addappid(1242381, 1, "a0eb5f3fa73a387ded2ff51a1afa8fdcdac322b4819a5bb351d5fee8f189331d") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - cs_CZ
addappid(1242383, 1, "307a234ec5d3e1a906aefa05e6806c841c4cc16606ca324b110692962c44abf2") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - de_DE
addappid(1242384, 1, "8f3bb50a4d6d95c44529e22d8cc8b99a256fc1f79d4c1ee85ae29a07a3864d7f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - es_ES
addappid(1242386, 1, "977beac8a666b5ab1f2dbf1f4abdd2d7154b6e4b5edcc8928a6181825bda6584") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - fr_FR
addappid(1242387, 1, "4fdd614af5559658afd1906c78ccd7db787d156c35686f1cef34e4ccd9293031") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - it_IT
addappid(1242390, 1, "fe16b41de217b82eb0e90edbce80091f41d87d68fb0a9ac7e364689219453c5e") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - nl_NL
addappid(1242391, 1, "2b03573aba8ba457b1a94f7db1cd777568378e34c2dec9a84ceb5a95a750ddfd") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - no_NO
addappid(1242392, 1, "87dbfaba78f71d8b15ea467eb1fe4c82b432f479caaa43afcd10cbba2b3eb1bc") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - pl_PL
addappid(1242393, 1, "12961371b100a000b2a5620dc45f0e4123be17acd80f354df1a234832caa1cdc") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - pt_BR
addappid(1242394, 1, "2b4ac38980c5b60727b62c34210162633b67030051617c9968d2def85bf1136f") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ru_RU
addappid(1242396, 1, "709fdafc7790b68547a7de5815eed9f98c9ee78fc081c0630fcf0c4eee2d4c8b") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - zh_TW
addappid(1242397, 1, "d50719dc4294e9a0947f2641e344970c3c2a858946c62b6a6971189e9b05dbdd") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - zh_CN
-- addappid(1242382, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - da_DK (no key available)
-- addappid(1242385, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - fi_FI (no key available)
-- addappid(1242388, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ja_JP (no key available)
-- addappid(1242389, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - ko_KR (no key available)
-- addappid(1242395, 1, "MISSING_KEY") -- The Sims 4 Jungle Adventure - The Sims 4 Jungle Adventure GP06 - sv_SE (no key available)
-- The Sims 4 Parenthood (AppID: 1235745)
addappid(1235745)
addappid(1235745, 1, "b1e6d2e9faab7a55e326962f56d84c1602536645064ed5d7e1afb4600c150c2e") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - Content
addappid(1242360, 1, "0e81c1891faa56030af5e8da531ee6318e6a843e2bd15e06ee182df75a4cb125") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - en_US
addappid(1242361, 1, "6000878a4fd90b184b92ad4b931b40b97d58f313a329ba5dc727c62750e1e375") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - cs_CZ
addappid(1242362, 1, "dad7f54c4d9dc12632c7a1e6ad041f1a362bf5b707cc1cb3c8890b8bd6bcb8b9") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - da_DK
addappid(1242363, 1, "cac85be23bb1feab89447cc40a5daad7ecaf19eb0df9f61d5c66cb2a85f1d6cd") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - de_DE
addappid(1242364, 1, "6357c0191fb589f767715b73726ddbca75b09499ca0fd8dd79875018f437be4f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - es_ES
addappid(1242365, 1, "421df882511fad9bd60c2eb7b6615e39299497de9b659c2af7d33ec3aec6f908") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - fi_FI
addappid(1242366, 1, "9febe0625c2c0f615aad39c09a47365e9c2a8890f58f2fdd5cfaba885ac1588e") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - fr_FR
addappid(1242367, 1, "9f6dc5699ed09f8401a35a741305e3f5b6b79d1fa0890f472d771c49b9ffbfaf") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - it_IT
addappid(1242368, 1, "f9b8b7d10b2b323c6ed672ad75d82652cf7f0246a703d2b0e4a315dc9ca47a69") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ja_JP
addappid(1242369, 1, "0d2e5b8e485d3e24fbf234004027cc24f456025e5b141bea7abd70014a13d079") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ko_KR
addappid(1242370, 1, "d26eabaf8a040ca96608ae8e3f4f1b5280214d166e2a4152afaa91980bac658f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - nl_NL
addappid(1242371, 1, "2e81b849f44eb227af77fa92cfd525f1380671f159793441ae4cc07d16075f36") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - no_NO
addappid(1242372, 1, "dec20d90e612dcdcd5f73216eda47e1312b168d12ed6b6178fe93305d263057f") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - pl_PL
addappid(1242373, 1, "3f5cf66fd10a8b18af8e3ef50c215846933e4ba9bd77cb5b479a6a5c6d2553a3") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - pt_BR
addappid(1242374, 1, "c77fafcd1cb71da645a043f74db9ffbd4567b2a4f03adddb6622c9345502481b") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - ru_RU
addappid(1242375, 1, "3ed1107995cf431a0e0af472044d54c32e2f8165c9330c7ad2b2585445c9945a") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - sv_SE
addappid(1242376, 1, "d9157fa3ae556e7c5a91859dad4b11d451b34c3d2a367bc0850d8865de8d2de8") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - zh_TW
addappid(1242377, 1, "dd7a0e826091c9a387b3cd19bcc9e86e744b87488e86cb9d1d116208e8e620df") -- The Sims 4 Parenthood - The Sims 4 Parenthood GP05 - zh_CN
-- The Sims 4 Realm of Magic (AppID: 1235746)
addappid(1235746)
addappid(1235746, 1, "40120eb998073f62f37746f631c0f9584736dff5a600169e7ebd48f1b63dfc4c") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - Content
addappid(1242340, 1, "353009c37e681baa68377f046ddfe1ec50197b26d5853cfafaa0f03023969c98") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - en_US
addappid(1242341, 1, "edab6fa9c86f5e905e8bf6238fa3dff22cd48e19bcd4b62c388aa757b76a763b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - cs_CZ
addappid(1242342, 1, "0ff38ae9e936f0993fce8fd993aab67f5d547211cbe81e11cc836f4ae2943c40") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - da_DK
addappid(1242343, 1, "7e6fb691f8441e26e592cc50a73d2326528b6c09f1081422fcd2b16fb334e34a") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - de_DE
addappid(1242344, 1, "afc32d4e3e06e23fbfa9013ba1608d34184973fffb2dc2b256a76d0068be04ac") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - es_ES
addappid(1242345, 1, "8eddec28149c328d7ebdc508312cb16894f30addda23ad0bb3080eb5136c77ba") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - fi_FI
addappid(1242346, 1, "6691a98cb13ca15a4e5fa3da61dcb5c43b1c249b6e62e398ab657d2ed6a1c90b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - fr_FR
addappid(1242347, 1, "8d333e90d55732e2ef19c57f80aabd23d2e4ef26cfaf5e65d420a6528c9d6ecb") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - it_IT
addappid(1242348, 1, "620868a47d39bb4cdfb4702879c5a939eccd185322079ff1b19d027a6f1cc22c") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ja_JP
addappid(1242349, 1, "7bf857ec793a02801a7e79b284912688fc5c405236ba98c294dbdc54940e1509") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ko_KR
addappid(1242350, 1, "cd1f8524001e46ce69f435bfa29c64c3b888267fec010c7f0c147fb60d072c76") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - nl_NL
addappid(1242351, 1, "71ea8662b956514e4a50cd7a7068cee6106da98f28c54cdb3d8020304b70594b") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - no_NO
addappid(1242352, 1, "3fd4525d615e8d1aa234e1cc89700405b5a43df7eb40e5cd6796625cd9e35abe") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - pl_PL
addappid(1242353, 1, "a03dbcf04a340d2b1bf8e87a38e4689db91cec971e9802d819308d2d46f2802a") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - pt_BR
addappid(1242354, 1, "d589e52d6154d71ac6901893c56ea47d73c23ee2b0102e11bd11a4c39a4b6471") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - ru_RU
addappid(1242355, 1, "5baebf8719a522ec6421a607dd3a10f0e1547caad34432fcb6239af5becd1071") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - sv_SE
addappid(1242356, 1, "8cc9db96924c2d5484989a391aeaa89820d81f80e518ea539b928f1653ccf360") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - zh_TW
addappid(1242357, 1, "e94140716d2153251b16e08377cf0ff141887f476dae5721de2cd634a67c7e5e") -- The Sims 4 Realm of Magic - The Sims 4 Realm of Magic GP08 - zh_CN
-- The Sims 4 Dine Out (AppID: 1235747)
addappid(1235747)
addappid(1235747, 1, "9fdefc05ac6cb4b5cf8dadaea3c861fae7d4a4ff3357b788a8e76d21d2344704") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - Content
addappid(1242320, 1, "afb39cd95f1ec4b18808d70e280487926fa4be91f5f36256067c45c903e1110b") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - en_US
addappid(1242321, 1, "1c63d5afc9c62806d3b04c51b61ab482db186f704c878eca701cd3aec93e52ca") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - cs_CZ
addappid(1242322, 1, "7681c449652e8234a3be2adadf804c1e9875494f522a711b21ed95efdb4271e6") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - da_DK
addappid(1242323, 1, "373cfcc09f9817dc004820a3bbf6d338b1445e682334b618c8ef6d4b0bd5b861") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - de_DE
addappid(1242324, 1, "b4fec8ef1c79e4141bd81ef22cee3e14817fe950f63b65c22d8ae58b9a9887b3") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - es_ES
addappid(1242325, 1, "cbd6e491cd82142f60a2d6aad597d0bd02cd9a2b7e77bab8e61e26475d8a11c0") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - fi_FI
addappid(1242326, 1, "3e1463ac74ccf9093d801e5a36bdb6a6dd0384a0834bdf14ac144a6f8482e149") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - fr_FR
addappid(1242327, 1, "1b7d8e81078c47d20febbc5346eb5e2a8b9933b115fb490a68031704ad7efcc9") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - it_IT
addappid(1242328, 1, "ad3f30375908e90e00a2388da13ff378202d9d6532a16e50c0914122793e8b1c") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ja_JP
addappid(1242329, 1, "13eceaaa34022c2ccb1b1371fe583a691a6becc9efc2a038fbf56baf6619b1ca") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ko_KR
addappid(1242330, 1, "7ae8a7f2298e12d67f1092565b675486102320048ff13fdb69bb2f430d91657a") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - nl_NL
addappid(1242331, 1, "2f09edd0aab5a5ebb1adde728b1671a4f93e1be28438bea3344e6320c4f74d1f") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - no_NO
addappid(1242332, 1, "0751f87508d20e2be8df0cf32f6b4765f23c7b32a58a6f5f1428ea286ca64774") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - pl_PL
addappid(1242333, 1, "646806902785aa56c7c2c9ba2839359969007a26bf348220a6e1f20a7c177eae") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - pt_BR
addappid(1242334, 1, "16f95eb7c7cc6bb4b8cbc2c4520413f314ac032b070e2d457befe3f6c86b54ec") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - ru_RU
addappid(1242335, 1, "6c496eac1a43a21db3c4d999a76070c63ec63e8db63ef6f4b165d0cdd819f447") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - sv_SE
addappid(1242336, 1, "82b9feba221d67f2556fe639ae77050d76eab57b5cdf6ee9c9f58f910309ddd1") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - zh_TW
addappid(1242337, 1, "4df32494235dfbf52519e859f02d36da28a085cf2a89884affc1e0da0ba93cc4") -- The Sims 4 Dine Out - The Sims 4 Dine Out GP03 - zh_CN
-- The Sims 4 Fitness Stuff (AppID: 1235750)
addappid(1235750)
addappid(1235750, 1, "f3b2fced0e2a886adfaf6153b53298703a4fe98e10d574b5b5861d4e6418aa9b") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - Content
addappid(1242300, 1, "569ba30aeef20e2828a3e4eb9ea553c2edd2ee32ad4ad93733b0ba894f1499b8") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - en_US
addappid(1242301, 1, "f7d66aa69a4099d3689519b59344e9dbf676aaaa468a4491e1a739b5d098c77e") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - cs_CZ
addappid(1242302, 1, "62b23aded42cf6d2318e7719f213676a5f01e3175f1a570850bfb91ca673fa85") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - da_DK
addappid(1242303, 1, "64042f7ae5e3616c8a4f6a4f8ffa50c5f9c565defacddb865ee509d1d97ab23f") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - de_DE
addappid(1242304, 1, "2d7d5e8ff5d09f30233718d6056f6f5e9cf2e09fdcac011da7e535768d58412c") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - es_ES
addappid(1242305, 1, "c455aee02536d7ad500d74c1efaf66cc94c9bca80a703a50b5ec9860760ba724") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - fi_FI
addappid(1242306, 1, "2331ab71c43fde2f34459a855741dd1a1600b9c339475b38700d8eb9010b56b7") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - fr_FR
addappid(1242307, 1, "0a2d2b90cdf2d0ce4194691cb24da3d78b4060d89c9eafe5ef9734eaf42b5068") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - it_IT
addappid(1242308, 1, "21eafcebd37c6d53488776d747801f190057c4b81d22716bda523f3b7bdc86b4") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ja_JP
addappid(1242309, 1, "d622c85e461dceb633c05d2d67f24b8ed4e61af6c464dc82fbedcf8eb8d51d09") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ko_KR
addappid(1242310, 1, "435e17741ddcc7a419a59756ac252df2e847dcda9c0bf2c4718ca434a04d3eec") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - nl_NL
addappid(1242311, 1, "c68aafaf637b90c1cab4ba9b0d7c59b0cd2d2e96da8fcc6b0142c557cc9a33ca") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - no_NO
addappid(1242312, 1, "56e3c8dd355cbcf27882ffee39ae6dbdccf2ce834b5bccbdd75e9dbfb2d74652") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - pl_PL
addappid(1242313, 1, "72b1ba12e0b354c41d114b3a973b69eaee88b15193a7bad811965ed01e367e56") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - pt_BR
addappid(1242314, 1, "329dbd222036e7a62bc974b74602dc3a0e8d6a0062d02aaee81042bd850ac8de") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - ru_RU
addappid(1242315, 1, "a8a538004957d8765bcf2a66f7bdb4da225c5d27a1141127ba8fa2d33c926bfc") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - sv_SE
addappid(1242316, 1, "4dacf075e4a1c2662dd3bd7bda3f350174ff1db89265c9d84bdbf654965a6c0c") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - zh_TW
addappid(1242317, 1, "62a494e1de476fb6fa122472812be1a3f6fe5d2b8150f80129cb843cac243ff6") -- The Sims 4 Fitness Stuff - The Sims 4 Fitness Stuff SP11 - zh_CN
-- The Sims 4 Vintage Glamour Stuff (AppID: 1235751)
addappid(1235751)
addappid(1235751, 1, "57e9f90f6cbd1e76059e634c8774f422167062b9176b6285ea3108817cefc86e") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - Content
addappid(1242280, 1, "63488492e367ad8ab255e00ec99768b75a3a9af57089d781e2ee83d113b60f90") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - en_US
addappid(1242281, 1, "1d818890218931929b69f6c3bc9baaf33fda7ec4f7611e40bda97fbf6ce3dab6") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - cs_CZ
addappid(1242282, 1, "8ea0215806d222a1e91fd76f8bc3021656924c8c6fbcf0ca604ce2045942b22f") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - da_DK
addappid(1242283, 1, "f02fc06e810f550a510aee0290366fcad4d81f50b1116f41211322fbb7b1df24") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - de_DE
addappid(1242284, 1, "4f2f57f5a748f4c105fe8b66812bec76899835ddf2a89983b5da357ecce3e78d") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - es_ES
addappid(1242285, 1, "8fa5c5875633cdb4918762bbc4e7cf772f7e9f43cc0af1b967f63acd98930026") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - fi_FI
addappid(1242286, 1, "09dfa8461636a5324c4f099e02ac51abf6f0aa80779e461726b69b269dc31155") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - fr_FR
addappid(1242287, 1, "d99293adfc74604c2e2a83faaa178a5c8ccaf6f5c0323e3ef38d4b09b29c7c19") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - it_IT
addappid(1242288, 1, "6ef189c9547a3689ff62d30270c4b27d8a65dbce483bd41037ff98959d3979ea") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ja_JP
addappid(1242289, 1, "99bd520c044052a265c86337802f26389bf0fea01b97edcbddfc97cd365fd086") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ko_KR
addappid(1242290, 1, "e40c8f8f6a6643ebebf352e4e62cf22f5ca3aa5b44c3e41f7dccf56411f44f4d") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - nl_NL
addappid(1242291, 1, "70349fd28642932fb225ae70ceb0661630b31e289b412977f8e3193d3a0badc5") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - no_NO
addappid(1242292, 1, "0db0b2bd2ca6f4d8909851edbf58ae63a3a3d614e3cf1da69eef13d54ee96229") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - pl_PL
addappid(1242293, 1, "40862083b4957fda4f102dc07802785c4816bb6327b88482266ee48a9a4f4c35") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - pt_BR
addappid(1242294, 1, "59769f9739acac8ebf59d9d12ecb49273f26b155cb76ea1d30ebee44816b57b4") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - ru_RU
addappid(1242295, 1, "c117cc9a14a50603cebc683f78e563c99856a5d656d4a6616db2950c0652472e") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - sv_SE
addappid(1242296, 1, "c22dd3f89f02047e267c3658ee5c01b169e0f0e078c2fe92b07066b6c153b662") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - zh_TW
addappid(1242297, 1, "4a3408c946748e25718ee457b5790d8f7a96b45010868f49ac690073674052c1") -- The Sims 4 Vintage Glamour Stuff - The Sims 4 Vintage Glamour Stuff SP09 - zh_CN
-- The Sims 4 Perfect Patio Stuff (AppID: 1235752)
addappid(1235752)
addappid(1235752, 1, "f24a455d56e4ff5709317bf583092885075065e9bb74d8a5f806e09da39fb20c") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - Content
addappid(1242260, 1, "1e5fcea21c4169b77f5f3717523f4f30538bff2179fe2dc702de19727e3f8fa2") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - en_US
addappid(1242261, 1, "23fcaf84fe2af140afb1d51bd89cee2e3819dac2cee3400a8d1a25fbc1c0ce30") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - cs_CZ
addappid(1242262, 1, "40183b943f4f3be0d3bd527c0c0cb165e8d303ed8f7cf2ed3693531668745744") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - da_DK
addappid(1242263, 1, "c6c3f17a7377efc4cf11673ed9501d2422ab1754cd1e3c29a3bb9e298dedc719") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - de_DE
addappid(1242264, 1, "950a23fd609f093dfe47cefc1695aedc00ee928ed1fd2c95ee9df2f9857a2917") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - es_ES
addappid(1242265, 1, "193f213275bf4d354803e822f0114f3b039b1b19899eabaa4b38ca44504bd38a") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - fi_FI
addappid(1242266, 1, "9a00e06eda341e6d6ff2631aac1bd231b6494fa4c5d67be1b7a9dfae9e819a48") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - fr_FR
addappid(1242267, 1, "d61ea0f5480b7f9a98df944a4db316ab562bd7f6c0380f1621eb93d4ade2a092") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - it_IT
addappid(1242268, 1, "9d6e5f3428a0f80c3bc917db49840ba3c07fb84f8bb0a2a6d0f521b895da8690") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ja_JP
addappid(1242269, 1, "709e5c5123662a388f551c0fc70306a010ce6c01f222ce535e0f2c52c55186e8") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ko_KR
addappid(1242270, 1, "5991f065b7c12f9bd42d863c378d114634c931ef62711b4e991668938c81f201") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - nl_NL
addappid(1242271, 1, "bce5e045a8933d59dd50942c2791424b55f4a8f2a76822cee36a606ffb0ca7b0") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - no_NO
addappid(1242272, 1, "e2362367ba581609fa210275e9187b380868214c7f2f5b97d6be59af5d734181") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - pl_PL
addappid(1242273, 1, "b33bf42dc85c2fb9eea178cc33328ef833e0099a8df43a6ded84de8b800732e5") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - pt_BR
addappid(1242274, 1, "6459adfd4eba8cb92a0402746aa8ffabb01c58e4470b756536d1ceb4a2ed62af") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - ru_RU
addappid(1242275, 1, "01f72456b88ec960f9ee5af7ce8963a94f9618041d52c571acfd9592e02d7d5c") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - sv_SE
addappid(1242276, 1, "d5a18864a0649f7c173974c926fc5f5d4066dabb481bf890750290edaa43f708") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - zh_TW
addappid(1242277, 1, "7fcfcdc5503926b875f2330bf1d4f52ffca28bbef16fc1e08b41fd276b89e797") -- The Sims 4 Perfect Patio Stuff - The Sims 4 Perfect Patio Stuff  SP02 - zh_CN
-- The Sims 4 My First Pet Stuff (AppID: 1235753)
addappid(1235753)
addappid(1235753, 1, "11f55c1b2b2ffae5e4133cf0833c45107709ba59de2bc7055ee68f1eacd18e82") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - Content
addappid(1242240, 1, "a3f1e151cb176a3153907a456bb0132c23f3ffaf583460efe294e51de1be5479") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - en_US
addappid(1242241, 1, "4cbfc11ff0fa7f394132c758ed1bafc874787804a7d7ecaf603a2ced67772c1c") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - cs_CZ
addappid(1242242, 1, "2e6bc3a876ff391ab7e665a9fe91cff046bbdaa76b96404188e69ca09b6241d5") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - da_DK
addappid(1242243, 1, "c4119417997869eaff4b8481fbb7e8106d30014ae110a01fbd4242f4ec77b322") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - de_DE
addappid(1242244, 1, "8abf9d4cadfc767ea4353aad8efff6e604e4820a1ff5d8ae56ccea3e80479677") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - es_ES
addappid(1242245, 1, "06c68dbdaee86844b44e3365ad29c237a708196e7d2409b33d75f5657691bf3f") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - fi_FI
addappid(1242246, 1, "69a7f0f2d481e96379a7edf7f75af99615f9146a557c566c95bad35a840955f3") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - fr_FR
addappid(1242247, 1, "44f8465d28f586209b89484cee29068d14d02913f61dc84d415dab53b54751bd") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - it_IT
addappid(1242248, 1, "25f7747003e9f5be88078b769d3509afff61f0f2e4496d338f2e23ba8874a8b2") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ja_JP
addappid(1242249, 1, "335d9815ee121f8c87f3fe3cd56e35cbd683de5514f5c5345d71123b63a5a5fc") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ko_KR
addappid(1242250, 1, "6166a6a7ee24dc460a57b76ea7e0c6360e9246bcd3b2630452d988e0fdca36b1") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - nl_NL
addappid(1242251, 1, "128416e91fdd72a9a6cd9b2022fb865ed30f70500f1087f582a81d6850a659e6") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - no_NO
addappid(1242252, 1, "503571290c5cd25a2a28b74c4ee33822d21e77503840abccbb0008764543dc58") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - pl_PL
addappid(1242253, 1, "344c213473213e2188031b1b38d18f4495b6f8a755da4cd0266d90eca786fa8b") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - pt_BR
addappid(1242254, 1, "7dc7f7a2e3a14a947a5ab5cc5b72a1e981c34dd933db91c38cf96eb8ff3a0a06") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - ru_RU
addappid(1242255, 1, "c7b8e82fd86e949e705ac321a5df36ef421d4286758132b04cfdab87d4c217fc") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - sv_SE
addappid(1242256, 1, "5bfadf785d819672fa9513f0a5729028e7bf3de5cb0640c73f087983344a67d1") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - zh_TW
addappid(1242257, 1, "e8cfce0a35badf4a3409297b57b723e98a216c24daabfc5697d89028e284aca3") -- The Sims 4 My First Pet Stuff - The Sims 4 My First Pet Stuff SP14 - zh_CN
-- The Sims 4 Luxury Party Stuff (AppID: 1235754)
addappid(1235754)
addappid(1235754, 1, "7aa8a0384924f70690672a790c8dcc0bda83b72289db9c4042e62d0400d48be2") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - Content
addappid(1242220, 1, "aa8dee9f289cddbbc377168cad0b10b7d8fb61c802efdbf72bcf3a58884490d3") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - en_US
addappid(1242223, 1, "5fd2e6043e6cb5273625edceb95be9df823eebee236f471ad0c936f997f4f03b") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - de_DE
addappid(1242226, 1, "5ed6631456ef9f1f95fc3f77ad59417a70e6508d7c146fac886831934c93a69c") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - fr_FR
addappid(1242227, 1, "e38e37f0d378c53448c026beee90b24bf83623179bf392c0bfb6584ea714d9d1") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - it_IT
addappid(1242232, 1, "526141e42a3dd57740da5553eca1e61a0962e15ddc3a40f3857e6d12bd6c1c98") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - pl_PL
addappid(1242233, 1, "424334ee8a1cc8002d7ab0efd373cecd6a2ba28e4ef7b4e61e70a68e626dc334") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - pt_BR
addappid(1242234, 1, "64b1cf2559d937d99106162977f4d28512636ccfdb5189d467a7ed968986dfb7") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ru_RU
addappid(1242236, 1, "735d44b33ae22e82b3fcd8a525ca388f1b8fbcfa91f521f687818df008622ee7") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - zh_TW
addappid(1242237, 1, "a77fc4d5437e76c50c2e3ec4cf29c61540767c872b035a3a8e1b52379f3876e5") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - zh_CN
-- addappid(1242221, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - cs_CZ (no key available)
-- addappid(1242222, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - da_DK (no key available)
-- addappid(1242224, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - es_ES (no key available)
-- addappid(1242225, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - fi_FI (no key available)
-- addappid(1242228, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ja_JP (no key available)
-- addappid(1242229, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - ko_KR (no key available)
-- addappid(1242230, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - nl_NL (no key available)
-- addappid(1242231, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - no_NO (no key available)
-- addappid(1242235, 1, "MISSING_KEY") -- The Sims 4 Luxury Party Stuff - The Sims 4 Luxury Party Stuff  SP01 - sv_SE (no key available)
-- The Sims 4 Moschino Stuff (AppID: 1235755)
addappid(1235755)
addappid(1235755, 1, "f43fa48516505fa06c7ca71371295b051f4522302dd4521c4d10b0be523c7f26") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - Content
addappid(1242200, 1, "1e4faeba323189cfad294385f9901b815011fa9fa6e9f151a9903aa0cd8015b2") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - en_US
addappid(1242201, 1, "c422cead6c6e0db743677b389b6e52b835953910cd6584f2de1f1022a991c911") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - cs_CZ
addappid(1242203, 1, "78449ae02b5ba293f8d95f8a2f1d4c31beee31fc6f9c82caac4e8eb5a34bad18") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - de_DE
addappid(1242206, 1, "a295c6a7cea24f4ded674a50b480801252147c82f7e0af60a0155e4309241257") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - fr_FR
addappid(1242207, 1, "021f1f427e50794b1b49f948a6b9cab58256de0d2f47dafd36ec8cd716b7d75d") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - it_IT
addappid(1242212, 1, "c78fa572c2125d1a1650943c1740ef1c959cdd0e0c78109dc1b2770a422b6562") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - pl_PL
addappid(1242213, 1, "ebabe801a62dde99904ae05d3cb164466ba931acfd8ce70d79e9e26820c3ea58") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - pt_BR
addappid(1242214, 1, "d22effec4fe68c534589f862df2ffd094ec4ec1c2c81437c515f0facd9c89fac") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ru_RU
addappid(1242215, 1, "4420879e63ccfcc25b9a1045ef75182f5e3a2e379473fab1a05b8d3b183508e5") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - sv_SE
addappid(1242216, 1, "0a833239f0c08e827bea95762e1d3f6aad58d668326b4ca803dcf6e5d5e095d5") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - zh_TW
addappid(1242217, 1, "10b94e0f026ef1ee4acfb2b43285064189c75b5efae7586864ea933e4bfc9ad8") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - zh_CN
-- addappid(1242202, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - da_DK (no key available)
-- addappid(1242204, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - es_ES (no key available)
-- addappid(1242205, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - fi_FI (no key available)
-- addappid(1242208, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ja_JP (no key available)
-- addappid(1242209, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - ko_KR (no key available)
-- addappid(1242210, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - nl_NL (no key available)
-- addappid(1242211, 1, "MISSING_KEY") -- The Sims 4 Moschino Stuff - The Sims 4 Moshino Stuff SP15 - no_NO (no key available)
-- The Sims 4 Cool Kitchen Stuff (AppID: 1235756)
addappid(1235756)
addappid(1235756, 1, "2625e691cada411ccabb251f1ffc80195ab864db76d7a00e6954a9762e6b89c3") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - Content
addappid(1242180, 1, "6ed7855d76af0e383dcd8ee422046382dbd4a6cf8913a80bf835d81aed78987d") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - en_US
addappid(1242181, 1, "1ab59088384416e95919a5822f2932790d77068ebba60d402e4d3fcffce8efcd") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - cs_CZ
addappid(1242182, 1, "1bfe9f0005a70d1c58ac5db00a92e61df1a5caaf12c7614a5a2f93a1bfa46227") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - da_DK
addappid(1242183, 1, "54869b4be883199323b39aa157c3be2fbc8d7ac5477e88424b51fa963923fa7a") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - de_DE
addappid(1242184, 1, "03d56dcc0393b1b34bd533248db6b36a097ca79e7489e5fee78a30ab3c9440c9") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - es_ES
addappid(1242185, 1, "7b400bf3f115c0f7e65bc366355219d1fb6a4747de9146f564cac2f6d9a874bc") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - fi_FI
addappid(1242186, 1, "f9e319a930b1d8d4d93f38d7acfa938683c53f4bad1446f6ab980ba747a7ddbf") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - fr_FR
addappid(1242187, 1, "7952982940e04afafdf4c6db7a5b3cd462a1e9193b9048243f9109f4b2b8814f") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - it_IT
addappid(1242188, 1, "139be2f7dc0eace902b3ea6c39928b23a08203c4e6a975b2e996597f2ffe4451") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ja_JP
addappid(1242189, 1, "6f1dd19aad0a9c82354095e47ef8034f6a9171db4500e19c4eda26431e327175") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ko_KR
addappid(1242190, 1, "d4fcf2b4bfdf02e90d130e886cf08ef0ac2800db7da14ae46b69eab579a68bf2") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - nl_NL
addappid(1242191, 1, "e3d70e77a1a3ef786d2f200db3c623ee85ea2b996f30bae12b9f386f2ab4b5e5") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - no_NO
addappid(1242192, 1, "07a9b426f3cc9ba0a0e095aea96bc92e151e94a9a42636731b87238182a9d026") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - pl_PL
addappid(1242193, 1, "835a819fefcf3f969d12a57a13cbe449939977d54d396b8fd0dc3175b4900322") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - pt_BR
addappid(1242194, 1, "c65a10e9bff5988b5cc470eb659a1cfebfd558034ba448680f9e5c8b6932d43c") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - ru_RU
addappid(1242195, 1, "cf1b3d7675a1bc15aebe1ccf35c49ac654175c35b8468489744340b9165748b9") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - sv_SE
addappid(1242196, 1, "5c7eee4c352d29cf32ea5307ee9f87257925ea47f6472226ea1fe02e66013626") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - zh_TW
addappid(1242197, 1, "b18d8d304bc69e6aab30df9632d3c1361452495ae91d3ee52d493a9b25f4a2a7") -- The Sims 4 Cool Kitchen Stuff - The Sims 4 Cool Kitchen Stuff  SP03 - zh_CN
-- The Sims 4 Bowling Night Stuff (AppID: 1235757)
addappid(1235757)
addappid(1235757, 1, "6bb80b7887c1d94dc4bd79e1bfd5a2fedc61d5c268f21901d97564f29e72a8ac") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - Content
addappid(1242160, 1, "952fe929ec30f191fec4cef63c21890464c171de5de6efd48b3b59d98baba70e") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - en_US
addappid(1242161, 1, "203d04926b94b516f1afc0d8b8fd93ff65831e0d7157b9cc4ede9908001a8464") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - cs_CZ
addappid(1242162, 1, "b1976d97ee9af072d7fd14c4a492b4fc96a8fe2ce31b09fcb46fee1ea25c6384") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - da_DK
addappid(1242163, 1, "824d248353c60a63075481b7d0782de23b28db3a2d51f0cb0f5498c2f0109eda") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - de_DE
addappid(1242164, 1, "12d0423943401e36e6fdd0bcf2c2204581183596d9aca06440fb6cdf89710ab7") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - es_ES
addappid(1242165, 1, "d9d1d6a6a3e95ba4e744bda1caa311ac947fb88d3d9a64403f7490852f95a583") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - fi_FI
addappid(1242166, 1, "ffe1a53a5f7ebfad4f5b8f49dd1664ca78370d2a8facb18247fd0994d2b99d62") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - fr_FR
addappid(1242167, 1, "71f9016e86a71a728d4c927c66ef4baf48a0aaef98272eb0b00406ef935534f1") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - it_IT
addappid(1242168, 1, "7a8075ed6907653b29c68f7c51df5ac828855d85076af712b14254c698a2b22b") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ja_JP
addappid(1242169, 1, "02b387b767873aa516ce13806195e0a4645f20e27448dd22ee38a5da1715e5b6") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ko_KR
addappid(1242170, 1, "859038de9b769c452048e3207e3d4ad1d682744391586f91413546be874f1795") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - nl_NL
addappid(1242171, 1, "fd046f289738197d3d10b42bbfe9cb6563413acf0a8592ca72f9a258d3aff6e0") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - no_NO
addappid(1242172, 1, "5f5dc21a961cea60e2c2392490587327f5800b01eb4fbb109abd835d1d51a2a5") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - pl_PL
addappid(1242173, 1, "ef4e0561e5809f1a226d498f185611ec7eebad936b99e6cf89d16e9a7458f66e") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - pt_BR
addappid(1242174, 1, "2d9e1a6950696774e70ffeecb00c05b1b4031c09b2528dd56954d1c7aad62d14") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - ru_RU
addappid(1242175, 1, "4dcfd68bf7ac9b209649fec02d069426738b9fc2a619997e6a7a670322dfd5c4") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - sv_SE
addappid(1242176, 1, "2a5bc5adfe5a595c7c83288cf8d39289b8649a3e6249f4cd05c7552cf4d905b8") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - zh_TW
addappid(1242177, 1, "19837f94caba2f5223796a91c565da35927f6f8025718ca8181bf4125e6420ae") -- The Sims 4 Bowling Night Stuff - The Sims 4 Bowling Stuff SP10 - zh_CN
-- The Sims 4 Romantic Garden Stuff (AppID: 1235758)
addappid(1235758)
addappid(1235758, 1, "fd86ca3e321d5a746127ec26dd6fa088e9b3c47826d3d282d44441d9d1f6d5b0") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - Content
addappid(1242140, 1, "19d1ce2e30642812ad159059db7b5d0ad782b9a7e3835fdc1cd1177170ab1c54") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - en_US
addappid(1242141, 1, "b98e01bad1fdf36352e4ef2ac94e68aa08494c9edf4c15005c6ea41e0992e239") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - cs_CZ
addappid(1242142, 1, "366145957def453fcb17901dd70559fa1d79b63437aad39093413dcaaed0121c") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - da_DK
addappid(1242143, 1, "e50b08acbf762a9d0551efa39622ee35dcb1c21cf6e13aca093b03e6a34ea28e") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - de_DE
addappid(1242144, 1, "5b217ebb3e7ed9470172a020bcf3c9852aa080b7a2ac6ba91b9935d932b7f6a1") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - es_ES
addappid(1242145, 1, "032524f744d78bb2b95c36e9a6ae0a419e1f03835d85243db25e4d0400f7b45b") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - fi_FI
addappid(1242146, 1, "df9f6ed35f708780693fd412fa27e5ed581cc475f230ee3765d445e564014e59") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - fr_FR
addappid(1242147, 1, "a70c5cc151dae0ebb97cb7ec77aaa9926a88626e1ca1fe87f535dff60d3a8a72") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - it_IT
addappid(1242148, 1, "d5bcf093c0206f065e20159bec2b65b049a6a39bd783ec6159d3651172b66c5f") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ja_JP
addappid(1242149, 1, "749d9ea302efec49faf2573e7aa0e28023d1c480cc08045865074f9e1b5e3678") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ko_KR
addappid(1242150, 1, "354e0a14299bdb7a5da5a5ccf3395e81fa5207f58982376d1db114589e4552d0") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - nl_NL
addappid(1242151, 1, "65f77b7e55b005adf77da4fcb4e756dbccfa1e4104e3684ace79eff891a8e0cd") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - no_NO
addappid(1242152, 1, "6460586ffb02e4ea203cdb6838a9487b9c4e0428f5209e593894d3c2e678973c") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - pl_PL
addappid(1242153, 1, "636381064a8920948780a97c77eb65ef7d0f619eedf0506e367e3e570a33043a") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - pt_BR
addappid(1242154, 1, "9f20417f5027c7720dc03a2280370b1e7601b010b3390585a902797e352f6fe2") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - ru_RU
addappid(1242155, 1, "dd171ee60855c108cc05e581ac1ee06be2264077dd77d052cd82ed36da3e8217") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - sv_SE
addappid(1242156, 1, "b3253455b82652969997f408908aec3ab6ff8a1db391d5556cac0a83dd7b158f") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - zh_TW
addappid(1242157, 1, "d5fda8e63da383c6fb566ca351c654af5be282ea898a03945dd03aa1c89dd7ec") -- The Sims 4 Romantic Garden Stuff - The Sims 4 Romantic Garden Stuff SP06 - zh_CN
-- The Sims 4 Spooky Stuff (AppID: 1235759)
addappid(1235759)
addappid(1235759, 1, "2aafcdce1a4406bc20732069711a0b852be5f19a1fc8a2ac81f9f448d642a1f3") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - Content
addappid(1242120, 1, "f9600393300ff31bb49f49a2f9b64b8601612c9fa94b2a57c8f3edbe4a3ed4a5") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - en_US
addappid(1242121, 1, "cbcedd08942cd3b1b1e371aa301111418c5a283ead5c6d39648ef727099a5e32") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - cs_CZ
addappid(1242123, 1, "9210523a60f12cba6c513c9c22a1d90e1332069a860b71ac30a4559273e14458") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - de_DE
addappid(1242124, 1, "e0f3167688d2ff6c39a3a3a3807a64f66cf4a9dcedcc924ab6e04cdac5642788") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - es_ES
addappid(1242126, 1, "a67c862281e7b42d155b73cab7e2d40828edae539f49572914b4356b24ffd525") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - fr_FR
addappid(1242127, 1, "f6f3c2290ba0d802c8eb252a940809819ad1b4ec44d1695bac73e4ab03d42258") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - it_IT
addappid(1242130, 1, "8c632755f956d93545711fbb62e438d531de4fab313a819c09598ea1db05453b") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - nl_NL
addappid(1242131, 1, "0f2d0a56508ac6a69ddc7e3593e73d2bb1c74a4b807087fe8b245ede54ca4f4b") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - no_NO
addappid(1242132, 1, "9c741a64bd6c91052b6d8a2eb4e157ab6367eb25ad6a973f7e2854d25e6e72a2") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - pl_PL
addappid(1242133, 1, "5888af3a8df48ca42fd00fdda6e971fd25e9e931c7962bccd7bd6304c8aa0546") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - pt_BR
addappid(1242134, 1, "d0df8bee4c3357cc7a16f5634c1522326d18f5937f847cece53499be17e750d7") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ru_RU
addappid(1242136, 1, "9c15c3d0feb09fbe25a6deaca570f26ebace4876968a53afc6d2dae4097ac3a3") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - zh_TW
addappid(1242137, 1, "3f0a507b60a89fa699df0f7ef6be76ff3bf00cfcca2e36b7ae0f1ecaa65580a8") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - zh_CN
-- addappid(1242122, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - da_DK (no key available)
-- addappid(1242125, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - fi_FI (no key available)
-- addappid(1242128, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ja_JP (no key available)
-- addappid(1242129, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - ko_KR (no key available)
-- addappid(1242135, 1, "MISSING_KEY") -- The Sims 4 Spooky Stuff - The Sims 4 Spooky Stuff SP04 - sv_SE (no key available)
-- The Sims 4 Backyard Stuff (AppID: 1235760)
addappid(1235760)
addappid(1235760, 1, "de560f5a41cbe450aefd2021baf2319462f8913ca8f050f530fef74e1179ce01") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - Content
addappid(1235768, 1, "7fef112aeb7bd2000b4776da4b83c0763232450c022db99fbbeb03af6042da92") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - en_US
addappid(1235769, 1, "f498a3445149ae6c8b8a9e8ab49f06faff4b339a021959b569674b0baa08d7ac") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - cs_CZ
addappid(1242100, 1, "af79ff5458495fc2a525df96d29a9d84e24d4ca1dd8caa84db38278c7ed99f2f") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - da_DK
addappid(1242101, 1, "1ffc9fb0ca3f22330afc76169b41be90f7b9e414a6ec9428e8bead7456aa2904") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - de_DE
addappid(1242102, 1, "b6c9b2947237ed7526ae24f38688b8223277ac70a2d0de3752d0efc7ed812e2c") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - es_ES
addappid(1242103, 1, "9d070357be3404a9c7d75d5ea2d81c949b473c02010f27deed6a26b01913e138") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - fi_FI
addappid(1242104, 1, "59a31efa8754168c4582a012aaa22f5ce459493587cc116315538938360382de") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - fr_FR
addappid(1242105, 1, "ec1af767e068d90883c130c7e7f2be10b36fdb351d7d34ea463845114f043f8e") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - it_IT
addappid(1242106, 1, "5ad968b27c97204cd2277369024d1fa3ed89a117bbcc36af970ed13bce1b95f1") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ja_JP
addappid(1242107, 1, "08d0e37a6fc0363eee0b6b50e38fec3627ebf9877dd763809c639b17af78d711") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ko_KR
addappid(1242108, 1, "5630d6a3a8abe6a7c137b5e5acc7b312d2aa43dbb29f7ef8209f31c27baec9b4") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - nl_NL
addappid(1242109, 1, "529809d021147e63f34f2336f3d7fb0fd4760187e24004451dcf919f337adb57") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - no_NO
addappid(1242110, 1, "3cd161e74e31ef9ba3ebe0ac774d756c741acabcc097bbab384563628afa9715") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - pl_PL
addappid(1242111, 1, "ec40dd2d52ace017116ef82e6d000c44e34ebb89df6d0af050d13f1da5deedac") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - pt_BR
addappid(1242112, 1, "50d594e441df651b18db0facbd553d8e1854dd564db04e298fa2caac6702f8b6") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - ru_RU
addappid(1242113, 1, "92f7ddeaf4a79224f3ca701548bfce9a0a97e95ef85aebed57e7a8deab527751") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - sv_SE
addappid(1242114, 1, "c2277dc3cb32655c86ae3406778654011e6592570f93c9434232f5894a347e6c") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - zh_TW
addappid(1242115, 1, "fdc68fd51c54f245965ad08508e148abfcda48a40fd80b7fc528f4b8f95e17f2") -- The Sims 4 Backyard Stuff - The Sims 4 Backyard Stuff  SP08 - zh_CN
-- The Sims 4 Laundry Day Stuff (AppID: 1235761)
addappid(1235761)
addappid(1235761, 1, "5069421aeb0da6c9302aa412853473bce3813a6e010d1b7231a83ac2eb7294be") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - Content
addappid(1242080, 1, "3c139023565065583700445340e21d911982c6e2455a144e7edcd0326e1ec2dc") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - en_US
addappid(1242081, 1, "111c2e9451a2b9de00b7c00c64856d7267846903e787784d4ab202d005a3b461") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - cs_CZ
addappid(1242083, 1, "fc86e929bc011f83fd4ab7d7a68545e068ba23cc93f6cd2dd85a55f80a578465") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - de_DE
addappid(1242084, 1, "d7200f94248c6c8fda845de84c0384e9e4e952430b9d3f41392dfc723f5857e3") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - es_ES
addappid(1242086, 1, "193252afc1531b1604ec628a02a4f3b5b5b95942cbf9149f965168f7f9536575") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - fr_FR
addappid(1242087, 1, "6786ac8a7826337736a778b8b447f232faaf062fa9d21001ece511e873d31b3f") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - it_IT
addappid(1242088, 1, "ceff036ffa217d8eceb58abc87340895d3ac49d3fc356e8a2b99015c60aedd14") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ja_JP
addappid(1242090, 1, "2030a779413a412603668cbdcda3d7c8f7cbcabbbc2c5bb1bc01949967d0227e") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - nl_NL
addappid(1242092, 1, "df28dd62cf9b460016bf82c2f5ed00b3a6202d62ae29c3d4fb08da077a35f47c") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - pl_PL
addappid(1242093, 1, "ef6e641cd213e2b4d14ff239c1f123b545d013729d4d09e77d34922f946fe48b") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - pt_BR
addappid(1242094, 1, "cdaf9b426d80cd9a4c6e95564e55793dfe17c915011ee26c589c6fec063c21e2") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ru_RU
addappid(1242096, 1, "9f2cea352f9f77a92b014e3e193aff52dba7dfd73a1b42f45ba5b64a4af491e9") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - zh_TW
addappid(1242097, 1, "13f87fb55e31352e7bf3a5336cf009b50965d68f878564fe239c3db5d56e724e") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - zh_CN
-- addappid(1242082, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - da_DK (no key available)
-- addappid(1242085, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - fi_FI (no key available)
-- addappid(1242089, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - ko_KR (no key available)
-- addappid(1242091, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - no_NO (no key available)
-- addappid(1242095, 1, "MISSING_KEY") -- The Sims 4 Laundry Day Stuff - The Sims 4 Laundry Day Stuff SP13 - sv_SE (no key available)
-- The Sims 4 Toddler Stuff (AppID: 1235762)
addappid(1235762)
addappid(1235762, 1, "3ff64685a83f07516b8d1976a9dd3504ca915107d2454fde4df863dcd2a01a46") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - Content
addappid(1242060, 1, "84a84976e176a8dbefde2631cfc0ea2aa7d2bd82b6cd9b1b10ce5d7630cd0cf4") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - en_US
addappid(1242061, 1, "1e80355aaf2021742975ab6b00183336e221b9ea34360a3e4c6fcaaa1a78d1aa") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - cs_CZ
addappid(1242063, 1, "7b001c2c903b359b4859caba3d679ec4fa29e603fc83965e17e6d72d1fc57165") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - de_DE
addappid(1242064, 1, "fac3fcc3bfa233b90587b899d5f691d837d664101d927fa670c50b20a48d687d") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - es_ES
addappid(1242066, 1, "addd710d2587cbed3e9d8afc5771c51adcae64dc354443cbd9e629374c5364df") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - fr_FR
addappid(1242067, 1, "8cc8aec46a66d456a39130e2c4d2f206e793c6aebafaa083120927eb03304e5b") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - it_IT
addappid(1242070, 1, "ac608b00cc91e9b2d11cf581a698de4d6419a469214b5cbc5ed3b38013372608") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - nl_NL
addappid(1242072, 1, "48c256e78d0e18567ac8ed04a65d2848f4f82456f09daa28185780e129fb16f5") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - pl_PL
addappid(1242073, 1, "745e6a6fe38ffd2c48f63c5240c29bef30ccc1d0149ba50d73141685f8a9eac8") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - pt_BR
addappid(1242074, 1, "5e13ef1eb46e5160df1eab9bab040d103dd60af50e8fa797880f9aca210d6bb4") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ru_RU
addappid(1242076, 1, "7e622f4154e55d7196a45bdaa670bbd90c80bf0f28d2a05ee0b0b81eef20a68e") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - zh_TW
addappid(1242077, 1, "5393af73f00817c49f11105fa4d0f1d1240b5932fce257e1c531f60c33d6af0e") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - zh_CN
-- addappid(1242062, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - da_DK (no key available)
-- addappid(1242065, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - fi_FI (no key available)
-- addappid(1242068, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ja_JP (no key available)
-- addappid(1242069, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - ko_KR (no key available)
-- addappid(1242071, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - no_NO (no key available)
-- addappid(1242075, 1, "MISSING_KEY") -- The Sims 4 Toddler Stuff - The Sims 4 Toddler Stuff SP12 - sv_SE (no key available)
-- The Sims 4 Kids Room Stuff (AppID: 1235763)
addappid(1235763)
addappid(1235763, 1, "9aeadafea38c37dd3bf1252d227a7fbb61ca715bf3f9e0a12659a036696ddbaa") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - Content
addappid(1242040, 1, "5a478f6ac9ed24b7d4cb07db4e4878743715b7cfc2c8b59bc197a8ffc9adf272") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - en_US
addappid(1242043, 1, "090aa34fbf56ac20f6687e340ce6e7e582461d9b700747bb21536b07566204a8") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - de_DE
addappid(1242044, 1, "f073e0d3efee063c14805f51e328555385cb29068d4de70ec04bdc20a7d71842") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - es_ES
addappid(1242046, 1, "4dfd13e430b286cf17cf48c32cc6597276bf307180211853f4830666edadf5f7") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - fr_FR
addappid(1242047, 1, "4ae16c988fc8b7e455c1de48387445b9c705e5501a09bd4dfe0c3c9f6baabf6b") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - it_IT
addappid(1242050, 1, "1f3a0b7ce650ff0c453de543977e9d64b1ee389346ba7b5c158ad0b7c949e057") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - nl_NL
addappid(1242052, 1, "f4368b30d0a67454e75c6d844ad88c488319fa0ba43a03eeb0df143ba16b420d") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - pl_PL
addappid(1242053, 1, "1cd22a4e5446b82679d278fcccb3b7c45df0cbdf7ec48f29cde1ff204b6dd286") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - pt_BR
addappid(1242054, 1, "15b7ca649feb4476b305e0a0b11f4015b4aba988c8ea8e9c554a7364ec81d21d") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ru_RU
addappid(1242056, 1, "6fcf3fb4928411738737ddeee01b4189c761641ee024cc3b8fc5565dad108e65") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - zh_TW
addappid(1242057, 1, "c867d6c0f6c2178724e5a89f3188888307984492925289f4e07b4f0ff2c08a21") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - zh_CN
-- addappid(1242041, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - cs_CZ (no key available)
-- addappid(1242042, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - da_DK (no key available)
-- addappid(1242045, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - fi_FI (no key available)
-- addappid(1242048, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ja_JP (no key available)
-- addappid(1242049, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - ko_KR (no key available)
-- addappid(1242051, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - no_NO (no key available)
-- addappid(1242055, 1, "MISSING_KEY") -- The Sims 4 Kids Room Stuff - The Sims 4 DLC Kids Room SP07 - sv_SE (no key available)
-- The Sims 4 Holiday Celebration Pack (AppID: 1235764)
addappid(1235764)
addappid(1235764, 1, "a7d93e506487cdc1f932dfa11f97da90b7d5a8e34501095048b33c8eb124f350") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - Content
addappid(1242020, 1, "8d3f0e8447287376df147ea5222fec4d0061c70ea57ac12c97bf13dbd93e4704") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - en_US
addappid(1242021, 1, "2123996a94ce75c99c0158a77078eb134402ed61ca62fedb0b3ecddbfb36d44e") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - cs_CZ
addappid(1242022, 1, "b9339d900562e222e0ea3ca3f6fd450af9d66a9872e4fd100440711f0d0d9f2a") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - da_DK
addappid(1242023, 1, "e46d065807a6a0c26a2dfc9b6fc8e73aa458a9474da830bba8c3f3a6815f429a") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - de_DE
addappid(1242024, 1, "c9d6e7b56dfbd524752ccbda3a156f1969b811d44d9ea7bf38ee6d13dd9b6b37") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - es_ES
addappid(1242025, 1, "b162112cc10ea914ea7464a559ad9ea58310d9e11064e56e2c3bdf54242e8053") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - fi_FI
addappid(1242026, 1, "0df4d10fa509bb19c2a660e0e218fc0023135107a7b40f402003f6db38db37f1") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - fr_FR
addappid(1242027, 1, "369e0e0887640e19969f53886f5ead7bff53037514423874237b3a39cce54fa8") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - it_IT
addappid(1242028, 1, "f4c063eb669837f9337ece3c53a250e9c4b92197f5d3619d3bcb8faa33bfe611") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - ja_JP
addappid(1242029, 1, "4c1c939472e47927a0d5c9b6cd1e34ab2daa9f9e182e8e9a4fa648bd84f50496") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - ko_KR
addappid(1242030, 1, "93d5229b951a77f188907a34463514c76153e9923418e6d4680c331302503467") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - nl_NL
addappid(1242031, 1, "cef649f8f262a44b52437f5c82734c8cdfad1fd489e03d5f613164a2b0e6eb7f") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - no_NO
addappid(1242032, 1, "063444e86ab4707c70633fd9c034631be553ba9e76925430fb487b94aff3409b") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - pl_PL
addappid(1242033, 1, "5c77ed6b3f5eb10c763e03301c9f154226017227ab4db7ab7bbbd90b89fc5a53") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - pt_BR
addappid(1242034, 1, "fbb60dabae3ba2d92924c9f30032a0b4d6ba4ed3fa5c8fca1145d7887c263fa6") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - ru_RU
addappid(1242035, 1, "31a2b037eb63fb9b44e70a5a2d157396708c0bd7d3638fbb3e2b111b6f163051") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - sv_SE
addappid(1242036, 1, "c9d681a1757c9d842832f992c4ffd7636fb829867c47228b26f0ce3e218be15b") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - zh_TW
addappid(1242037, 1, "0c621fd6b1cec19817f73f0c911bb859b11d2c5a3c1ee96d7e8a86fa36cc39c3") -- The Sims 4 Holiday Celebration Pack - The Sims 4 Holiday Celebration Pack FP01 - zh_CN
-- The Sims 4 Tiny Living Stuff (AppID: 1235766)
addappid(1235766)
addappid(1235766, 1, "efcf0dc7b24eb7a88f94e85e76a86cec9b8e67f158c7be8a364ce66277e6f888") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - Content
addappid(1241980, 1, "8963ea5f2caa283bb0ce38311855ff940485c7f1ae0e361bd2e548e4ac96a34c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - en_US
addappid(1241981, 1, "9e1166f635ac698900d3ebc5579d353889c9843ca1fde92a465ce134bef0c2d7") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - cs_CZ
addappid(1241982, 1, "1599519675edf82cdbc34d6e852f81e21bcb78b4ee55a62878c2040f11fcec18") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - da_DK
addappid(1241983, 1, "2f89df032148229f02ad9eab1c87921fcd35b8852ef91e7bbda71a6bb5211827") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - de_DE
addappid(1241984, 1, "79002c3ccacaf12ad89bd60ee6211d6d85d2bca984041bce9569a2837d0ae3e3") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - es_ES
addappid(1241985, 1, "cf2a415d28647d14a2d880c4bbfd60fe77f9587e5db4cf0ef85d3a4ac58a54a3") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - fi_FI
addappid(1241986, 1, "483cd18b3dd8d23cdb91b26a3d56814a45945acae70c56100b4f342516973842") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - fr_FR
addappid(1241987, 1, "ec2423b31d4e6975aa7330291b8110000720da25fcbd7bf1cb4ddc9a56cd0ec0") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - it_IT
addappid(1241988, 1, "551cb489f867764c45fcff4f0a8ecf1c50cba78efb8074122f38f7ced0bb7d3c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ja_JP
addappid(1241989, 1, "1c38333540322eef8382df34881b3e63a02c18fc2253adc33303a861bcc59c30") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ko_KR
addappid(1241990, 1, "f4be7b3cb637188f2c81b18dc2f399c38c28353e72124be7d90af535cd0e0fca") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - nl_NL
addappid(1241991, 1, "bf39757ffbb78948245023333591c1acc2050a2ac272fd37ace909a8fe1e6b36") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - no_NO
addappid(1241992, 1, "d8ae20cd2b2661315c7ce6ec0ea9fd2e5890c809bc5a0a970b47b8a7071ae013") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - pl_PL
addappid(1241993, 1, "ed3c668284f105736bb739793b24513d8f4314515d56cbdb32e4911d7c6f7c0e") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - pt_BR
addappid(1241994, 1, "c3c4d69a0f449932e29e38555369f4788a9deb922276e0eed570741ae2486360") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - ru_RU
addappid(1241995, 1, "eee0d9d132429a14e55f0dd2cbf782a85a56317955f2688989c030622262176c") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - sv_SE
addappid(1241996, 1, "4499d725336f7813f496bff0ee544034f7d2d8603ef667af98e1ad00bfd4ae66") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - zh_TW
addappid(1241997, 1, "d6122e2895c598acd345095c6cb76327a96db1a5aee328c775baa648b585e611") -- The Sims 4 Tiny Living Stuff - The Sims 4 Tiny Living SP16 - zh_CN
-- The Sims 4 Movie Hangout Stuff (AppID: 1235767)
addappid(1235767)
addappid(1235767, 1, "406954c37bc4e86fe902b7bbee18b417ab24a49bb25080c8a37d0f18f91bdda3") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - Content
addappid(1241960, 1, "76d99a5ee110917e0d063f66738f467f4d6bd4ce22ec4179ea1a716570bd7ce9") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - en_US
addappid(1241961, 1, "0ea7828d25fedf5c78fcec43bd7d41bdbbeb6de64c7af2c2e26e149f0871f9e8") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - cs_CZ
addappid(1241962, 1, "3f393a6ba6788a7df2586afb13a1b441ddbc823769e27637f43d505e0e901b9c") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - da_DK
addappid(1241963, 1, "bfcf4da651cb456aeef6d748c09996e7021d27be73bf3cf605f3b18685478886") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - de_DE
addappid(1241964, 1, "1d07962c808ea176cc079e2058a5f759fd89f1ba52f836a153fb70e94b5bee2a") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - es_ES
addappid(1241965, 1, "8d1193b8091e5d40458b7ce1e345405ad1608f99ae768c393e7dbe7330017086") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - fi_FI
addappid(1241966, 1, "6302e2d34517493cdb4864a2023e389b7ab9aa58c05816c55217f7bef0f2b7af") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - fr_FR
addappid(1241967, 1, "3ea53386ad284dbfa5e0ec3b3b5a1e3e5c9e0519c8e0e8322f9dcd36aeafba78") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - it_IT
addappid(1241968, 1, "1a10131d41e060781953c2115724635722138e5abf0f9630262e295bb9240354") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ja_JP
addappid(1241969, 1, "2f5d1ce7ce55719b6a718df5564fa30187a0e4a484e2cab4fcdbd355388145f2") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ko_KR
addappid(1241970, 1, "6bfa4290076075bb4ddfe07837491f6a8b7f772df0d768b3b2ed20a9498f20ec") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - nl_NL
addappid(1241971, 1, "7fa0558edd8ef6608cb9e1b1c03457d1c96baa15e3582980844d12e8b6f30c3b") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - no_NO
addappid(1241972, 1, "9d2b302dcdb049e87e4da0576ec30ed031172faefc46c633b16d2c441c9ebc9b") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - pl_PL
addappid(1241973, 1, "383aba4fb5d79ce2f901605b757b1c690bf1ca37084a4dfbb6d36cb754721fbb") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - pt_BR
addappid(1241974, 1, "11def70d63d2eb9c5a95a8b5758053bde74a25d90e3b00a255cfa824c31362bd") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - ru_RU
addappid(1241975, 1, "017b9c2c1e0522b084eed7977f3c652dd957113adfd2fa53f864969afd24b300") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - sv_SE
addappid(1241976, 1, "76c87c9b6d203344e83f3f8790b8a4d730856018826738f5877c5b3f2aba98b7") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - zh_TW
addappid(1241977, 1, "51a46510c1d41948bd7281d9e6f2caeeddfdaf095593fe26faeeb1be3e61b040") -- The Sims 4 Movie Hangout Stuff - The Sims 4 Movie Hangout Stuff SP05 - zh_CN
-- The Sims 4 Digital Soundtrack (AppID: 1271130)
addappid(1271130)
addappid(1271130, 1, "65b09123aaeb364c31b839838e2d9dcc4a54e5345c0ef1074d6495879d83f773") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - Content
addappid(1271134, 1, "a5efc3c655724516c9768230846c02e1d424d871dc9a7d7fe576efaaf05ba9a2") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - en_US
addappid(1271135, 1, "d6793dc08449897375caa52712cdcdcc143f501d888fdd4112f0c9b87019dc9f") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - cs_CZ
addappid(1271136, 1, "6d9af6f7453573e3b025f52d7b585b1d588b6c590eff4b035b457c84fd2f3402") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - da_DK
addappid(1271137, 1, "5bef13a6fb82157fa8d0afaf01ac12e91ed51e120c85b67f49aea45d6e975911") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - de_DE
addappid(1271138, 1, "c66ab1186d2d945d237f9dd00de6f74cd290338cc563f58f3fff68b00a184723") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - es_ES
addappid(1271139, 1, "49d7d53756c107e9b87587f78ab8e41f457d09c3a17faf30a8b22a33502a107b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - fi_FI
addappid(1301190, 1, "9ae4fde90114f83c4685971283b2526a53b1ee94366b1ade09611ed2bb0577fc") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - fr_FR
addappid(1301191, 1, "29b8ae792ba2781c26a1b5b4d780f3914a19fd22cbbd234856679cd5a739e253") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - it_IT
addappid(1301192, 1, "1b4f988a0a642c32714e2096202bc4268a5e5cd5c74d24b1fe2eaa8cd1f6a089") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ja_JP
addappid(1301193, 1, "31af35a6964c82c70c96bdf39a46a7b9c7412d67dc8d5d91420a5eed24d40b2a") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ko_KR
addappid(1301194, 1, "0178d47c0eae18d2d3e81013323300dc73eb89f37ff81a9a36b82f3ab7fdcf7b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - nl_NL
addappid(1301195, 1, "858472e14966b33c7cca2d3366bb8a01ee160c67454cde8bd409308e2d835a5c") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - no_NO
addappid(1301196, 1, "c05319bb0c046f164c7950bc4db07bfaa421f06ccb1213f2166a67ab4bb22166") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - pl_PL
addappid(1301197, 1, "1db3cde6be9cb6c38932250b7fc5bc40f74d50f52c62634141601c9abc91e974") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - pt_BR
addappid(1301198, 1, "e2578362cfe5018e4bae70ffd44789477d80c1622b5cd5c45d080e6f9dae8c12") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - ru_RU
addappid(1301199, 1, "a5eb70d608010f36bace2a79c80f499617b5dee66b6dd402e879bfd551ba15cc") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - sv_SE
addappid(1301200, 1, "b2f9ecab245e15c1a3ee973f5b4388d8ff850047c86695f660dc04d9f55654ca") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - zh_TW
addappid(1301201, 1, "8d32fab3e50d78d62a02116ee4eef9d62d2080ff6ac48f06685236d75ef3f77b") -- The Sims 4 Digital Soundtrack - The Sims 4 Digital Soundtrack - zh_CN
-- The Sims 4 Eco Lifestyle (AppID: 1301020)
addappid(1301020)
addappid(1301020, 1, "e539edda978a6777debc3a267022920caa8b27fcc1bc448ea1ef8504d797d6d9") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - Content
addappid(1301022, 1, "7d559751990df0008bc4019ed3eec7dd2135ec2c8fa6bea0428714cc8280b256") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - en_US
addappid(1301023, 1, "7fb26229a1d8f23265b3b0d16c446bf8b5548dfdf650f61697181747afcbfa67") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - cs_CZ
addappid(1301024, 1, "7463c409c859360f87c9caff544f45e0cbda9fac140baf5a9c60e468ae59a82b") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - da_DK
addappid(1301025, 1, "554e4d95b48e663cdbbcf14dee12fdea072703b77c02c52b165e385efc7abc5f") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - de_DE
addappid(1301026, 1, "e1162bf5b7e94d6f09978d0e89e1aada0ec257f07e4439f4caf64c0321276560") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - es_ES
addappid(1301027, 1, "8268108e6398daa1d452bdc640bcb381409835375e1c13b6ba027a949ee860d2") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - fi_FI
addappid(1301028, 1, "e306618d739c67fd4613284b0e24646188e22ee32dd72e3cd9bcc1d3a94c8d12") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - fr_FR
addappid(1301029, 1, "9e9151370fd289e1b60e934e2e28926c2e711a33fc7c9ec2d3717784aa0a0151") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - it_IT
addappid(1301170, 1, "18c6daaa60295c6c6620a1bd2b954d2f0cfb62e4b04302fe60aec7270bafe17c") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ja_JP
addappid(1301171, 1, "94134dde0791e8d91ae8e6e5d4c94d9fece4cd52eebda30ded3341ad65eaf5f1") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ko_KR
addappid(1301172, 1, "445f19f11b3d678b8e738e3ea734a7693e5644fc18e2f02551e3288db35181ca") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - nl_NL
addappid(1301173, 1, "3c2101c4d79caa94c70c4c6af614e27a28f68a6bc9be117dbd4ffc0c30c55f0f") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - no_NO
addappid(1301174, 1, "6254a24c2ac11c3c8f01ab5b6170dc843ebe287bd9e95db8748b66e4cca574be") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - pl_PL
addappid(1301175, 1, "4ae0e7b667e08dc79b0e9b8bc3ad560b26e58aabb60e363ae75caf7724f2c9f7") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - pt_BR
addappid(1301176, 1, "4612df155f65683e8328e4d4624b0e9d2a29375d9b92e778209d723240322028") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - ru_RU
addappid(1301177, 1, "10eaabec31414739b6b2a4a9fd785659cf66c77b7d2db7d2061de5ce8fe64865") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - sv_SE
addappid(1301178, 1, "0e65ea84b4d41ce5dfae4b49c69cb32860824edaf5b3c8ec82c7ca470ac46f7b") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - zh_TW
addappid(1301179, 1, "392fd1c9fb87a68d47454241afd87296e9b2aa86c7e8fc247ed993122f14355d") -- The Sims 4 Eco Lifestyle - The Sims 4 Eco Lifestyle EP09 - zh_CN
-- The Sims 4 Star Wars Journey to Batuu Game Pack (AppID: 1301021)
addappid(1301021)
addappid(1301021, 1, "7fe53f4931975351d980dcb6a12230dd180f71c187e7c73a9d4b6e6930c3a00e") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - Content
addappid(1301150, 1, "53fc29e4979b9c1b7f3e0f19b2f05aa39dd138d7d78db2aff461d454f0bb6a52") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - en_US
addappid(1301151, 1, "624afe285a5e85c0cf9ee096577d2aff61573318f7a0a76bb8c6179fec5de292") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - cs_CZ
addappid(1301152, 1, "a686f6b96ddb19888589d0b34a4fa772ab44db866b3b7256cd5f05f2df524e7c") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - da_DK
addappid(1301153, 1, "c238b5b15f8a135b43c8d3e277ad5d2b602578b9fbc78524e642c695d55727c2") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - de_DE
addappid(1301154, 1, "b8d64d87a5157d0ec3adb29c38cda2b1291838ed31eeb25ad60aa4a11d33a9e4") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - es_ES
addappid(1301155, 1, "3ca277e3ee68982f5a3cb0fe368492fce049c061d5695fd40dbb7c0f1d202d72") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - fi_FI
addappid(1301156, 1, "4daf823fbe0133ad6508195c046e698b160ad5d25fefec1d3e3158a90858a853") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - fr_FR
addappid(1301157, 1, "f55cd229d08bd7295512b412854d8e6e796909a0d941d2d31dac1866a69a88a6") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - it_IT
addappid(1301158, 1, "efcd79e1c916843f040e2449d562016b5939df7c61387a7f7fdf883899ca592a") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ja_JP
addappid(1301159, 1, "0f0fda415dbf0aa0245db62bfbd5dfba33f36d27106fbd04011afffc081276f5") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ko_KR
addappid(1301160, 1, "5aa74103d1112e817e2ecbd950b6d6aad6b3570ea351a4f17fafe91027aaa9d1") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - nl_NL
addappid(1301161, 1, "8c9fa1103fc9318a9662fece7e9b70889fc295172d5d636300a8b9ae787440b4") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - no_NO
addappid(1301162, 1, "4b882398c93e75936cbdda77c6c6b6099c9fc7f7459be5d258b0919e555f90d1") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - pl_PL
addappid(1301163, 1, "2f3d0360f5695d37afbd15126086bb409749aee8f2e9e2896a509b601fd881e9") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - pt_BR
addappid(1301164, 1, "f81e28bc49accacb52e6c9e1fc0088d48f53a8dc23c65b8f7eb5c19c5b1aa20b") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - ru_RU
addappid(1301165, 1, "429a3cc739fb92c55d59f04b92c2c1793de3e695b7c57338b3c2a703f8dad807") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - sv_SE
addappid(1301166, 1, "509e1543003de001f951d3d81cedb10b4fe78aa0181d1571afe8716e847e1b2f") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - zh_TW
addappid(1301167, 1, "fad9ba1aab67aa4f9f993d475fbe4ad74f4e373ddfe1445e457c86888150db9e") -- The Sims 4 Star Wars Journey to Batuu Game Pack - The Sims 4 Star Wars  Journey to Batuu GP09 - zh_CN
-- The Sims 4 Nifty Knitting Stuff Pack (AppID: 1368570)
addappid(1368570)
addappid(1368570, 1, "d35ed1839c643cd948ccc4faff06aa33ae75b05a43242601f9315723f4a7fc7d") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - Content
addappid(1368573, 1, "570fda4c4f60a9635003ad3d2702aa79d7fcc11a99881db6f7c0cc1472510bc4") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - en_US
addappid(1368574, 1, "8dea31443e0f9edbb3b2da6a1eba31cf0efd42e88239b248ccbbec387a83c5bf") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - cs_CZ
addappid(1368575, 1, "bb59a26c138d6281ac84dec72d749a6ac7808b42032a3da11f99ccc50a7e2953") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - da_DK
addappid(1368576, 1, "393906ef46fc02ea66180b7be18a41d95c758b3adba543427502325072d66930") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - de_DE
addappid(1368577, 1, "3a32f66334ffc70a609e11b0bd7a6f2905ae4b2e47da32529e43db3163da762b") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - es_ES
addappid(1368578, 1, "93d0e55eedc7f2cdc3d3b08e0cbb908fbe7c51712f645c0e82050f22f816cc91") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - fi_FI
addappid(1368579, 1, "505a30e4a6f95188a115dab5a8ca369ee20cb549d7083c6ecc058459b109d958") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - fr_FR
addappid(1369590, 1, "fcf1462f8f8b3ee52321d1a756a03437dca66813027e5f63eec912d6471f59dc") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - it_IT
addappid(1369593, 1, "a8c4a98d90711d5254dff43abda527d77f835eae1f04139fce23a7e606486d03") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - nl_NL
addappid(1369595, 1, "0755e203b244edea5429801ce42282def827815d90c43b7681c8b0e5af07e3af") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - pl_PL
addappid(1369596, 1, "cce15c752b9513fd29c9de8339c29e214060f253939282b0eac2fad5c83b00a8") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - pt_BR
addappid(1369597, 1, "e4bfedbb2dd47e8dadbf6d671eeec6fe3d6d6f58aa7f1f5ca0dd8c389c7eaacd") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ru_RU
addappid(1369599, 1, "426e3c350d694d5dd02f45f87f22509d85c9a5d80dbb71228eb5707421d549c0") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - zh_TW
addappid(1369600, 1, "71078da38605290958df77e0112594ef5f7e2bba6b5da8ab705a2107e38b28ac") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - zh_CN
-- addappid(1369591, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ja_JP (no key available)
-- addappid(1369592, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - ko_KR (no key available)
-- addappid(1369594, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - no_NO (no key available)
-- addappid(1369598, 1, "MISSING_KEY") -- The Sims 4 Nifty Knitting Stuff Pack - The Sims 4 Nifty Knitting SP17 - sv_SE (no key available)
-- The Sims 4 Paranormal Stuff Pack (AppID: 1368571)
addappid(1368571)
addappid(1368571, 1, "849729a55c7573e72905d6de64304e59c7ae397363f8f91f711589d66ce90c31") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - Content
addappid(1497410, 1, "d137718d1b396316c88d8828f16b659e4d3feacd07d8bd8f1d06b1c817f9a6b8") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - en_US
addappid(1497411, 1, "a802fb953dc2b9df22231f7659a9e13a421bda37b188e64b77c3e984ed20f1e5") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - cs_CZ
addappid(1497412, 1, "4edafb301e9b767d19f94ec7f68cf082524f6c8cbb80c643094df01590268125") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - da_DK
addappid(1497413, 1, "8ca8f6ac48ee7e5e508992bc6ceecf8017fb729dfa92f319988fea58a9d6db80") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - de_DE
addappid(1497414, 1, "e6c0206bcbf663632bbe28957978577200b3f8997ff4fd4834a0a157be53df9a") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - es_ES
addappid(1497415, 1, "2bb92ef4f7a1f52432a798c656bf9d2fae7c126030234074327a0459204ec0ef") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - fi_FI
addappid(1497416, 1, "fb212dfb4133931b5ffe7c41afe35e0569652153096d3f4bc645244cd36c52c3") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - fr_FR
addappid(1497417, 1, "ca4edb18fc6cafda238c0f8c0f07f28f894c3830ecfc47cd0e6932da78fbf701") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - it_IT
addappid(1497418, 1, "0c7c294ed1c8bcc8fc235e2e99adf66eacaef3ace934e346afdb77abd9e516da") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ja_JP
addappid(1497419, 1, "9e217c19ca7ef9b4dc20e1e0dd9e9c95f879db4834707b07a0abc4f8e5390f7c") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ko_KR
addappid(1497420, 1, "df7036bf55ee969203c674cfa5b208321cb994c85991048d2799ebea19655e3d") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - nl_NL
addappid(1497421, 1, "dcb8bb21c122f1e30a16b0750f289e1991106bad8291f84cfe674bea33b78858") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - no_NO
addappid(1497422, 1, "7c087349865f524c71d8d82eb80e7f1f4653d6474fa2318ba8bf04829f9ebeea") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - pl_PL
addappid(1497423, 1, "970ee94ed6fd6fcf9f001c52927cacfa9c21f9187a966c142217f851dd38a665") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - pt_BR
addappid(1497424, 1, "8cfb1f04bfd9fde1bd306733be7e1a35b58bd657c2195017c505b80eb3dc8207") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - ru_RU
addappid(1497425, 1, "299189ff6761465037a781c44641c0c7074e2ed7544356a26e4ee30484c8ce32") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - sv_SE
addappid(1497426, 1, "915a9b05d436073aaf33176496f8af2d080ca58d41ffafabf65de8e36ff1bf53") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - zh_TW
addappid(1497427, 1, "8a8011a749f370f1135b3d367f8539b3d2549e1aa2e20ddeed91c0f7428d1647") -- The Sims 4 Paranormal Stuff Pack - The Sims 4 SP18 - zh_CN
-- The Sims 4 Snowy Escape Expansion Pack (AppID: 1368572)
addappid(1368572)
addappid(1368572, 1, "ce8d5290e87af0a8e0d85c1332b86bb99ed3abe038ee1fe994eaedc89f37fc00") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - Content
addappid(1451590, 1, "a1b00f3a0d6604a2af9c505280be15f3e3a99abccbfdce7d4e1b04259e194fa0") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - en_US
addappid(1451591, 1, "7ac2c8f6370d7e443ff6a898995734a0c7c67d42bef660bccf0160d925107a45") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - cs_CZ
addappid(1451592, 1, "189a2123dda57c3faa72a9c52472ddbb2e674a8cf6f234695fe884152d8699b0") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - da_DK
addappid(1451593, 1, "0fdf6907b340753512776e9902e831ce0bad6540422f24d8f49148073655ed87") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - de_DE
addappid(1451594, 1, "296fb5bc6c582b3b75a6831c349ab7e6559163fcec8a5e5072547ad76660a323") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - es_ES
addappid(1451595, 1, "a6b579de1d0f8bc8114cbd8ec2a1d2e92e8758262dae10acfd5790fc3e486287") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - fi_FI
addappid(1451596, 1, "1a73ade768a1f892d9b02b5c7c43688bfe11054ace0dedbd503e12bd680e20bc") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - fr_FR
addappid(1451597, 1, "e55389bf52a74a362cec24448e70b1da69de8765830bd30867a830c44b2075ba") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - it_IT
addappid(1451598, 1, "3d577d9737db5b8316653833ff23365e655a650f9b391e400190dbec29d2564f") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ja_JP
addappid(1451599, 1, "35c39fcf471c915c12e649ab94ca43c6fdc2f99776b6019efbeea1512215d5de") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ko_KR
addappid(1451600, 1, "9e8dbba6258e6fde17fb09ead2e170ec845432609c35b805182b7947299f923a") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - nl_NL
addappid(1451601, 1, "a186893e97f3b892f3ee02e25a82c98b1796ba4e38ca78106bdab7d7933bb51c") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - no_NO
addappid(1451602, 1, "729457410b198d3cd757fe19aac736ba1d6336187b393f58ac0167fa54b1f354") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - pl_PL
addappid(1451603, 1, "590c1d2344fdcc9b0178779e86bf37d0b8160b6e2223ea60261d900164119ab9") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - pt_BR
addappid(1451604, 1, "645dc909aadb5c76bc5a54db3c9a5536212eb011146fbcd37459354000aa1bfa") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - ru_RU
addappid(1451605, 1, "fd8e8bb299374bd3104a19c55df09345158a2f9d7c9ea18a4a669c75392d3024") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - sv_SE
addappid(1451606, 1, "5394ff19e6ef73fd1a1810ce11d72d3681a1a02571d440fe346868acf23ebf6b") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - zh_TW
addappid(1451607, 1, "4d4f1842f0b0b3515f33da793bff9acada5e60423d414e0736b199ab521988e8") -- The Sims 4 Snowy Escape Expansion Pack - The Sims 4 Snowy Escape - zh_CN
-- The Sims 4 Cottage Living Expansion Pack (AppID: 1458150)
addappid(1458150)
addappid(1458150, 1, "f9934097f977b2d842c58012e6ad448adb5822fcf6195574741d2653a49b904a") -- The Sims 4 Cottage Living Expansion Pack - The Sims™ 4 Cottage Living - Content
addappid(1458156, 1, "03e8eb17ec62baa02b2c511d298fe38e7444b72d2850410329cb5a9a5d8e6469") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - en_US
addappid(1458157, 1, "fe6769c0499eccd96623e6e86273c86f8ae8f8352e9498e35b4f024b223e3cd7") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - de_DE
addappid(1458158, 1, "6d887fe7633efe5b478dcbcd0edd323d1d3b9bfa1361431603764755304d5e7c") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - fr_FR
addappid(1458159, 1, "66a4d49b1273b15e7ec18bee51e6958f56c6fe37f843e595faf8af494a86ae17") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - it_IT
addappid(1497370, 1, "a7eb2f99fbe253df3aa03d56ec19390b545f9370729a0ff20a18ec24cdfd5a2e") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ko_KR
addappid(1497371, 1, "52d1cd107399161a63cf32d5fd8ce689c63d992c4c90d034539b169fe757d405") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - es_ES
addappid(1497372, 1, "31d2357798d00a3542594517f0c12d4e24cf7031af7f7b2280a21aa6056f5091") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - zh_CN
addappid(1497373, 1, "8c940ccbda8a44d493352d67661d0cfd7fb049c5453972cdcb2c01c392f8b2d0") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - zh_TW
addappid(1497374, 1, "374e5db242713a7f487a762b194cc2a2553182e6d5258474ef6a20daea68e862") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ru_RU
addappid(1497375, 1, "3927bfe87b0624658eb197c2f3659e63d765356a39a5f8d6d76f15775dca965a") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - ja_JP
addappid(1497376, 1, "20a063b44ec23d8585be69dbea8a8e4d4df710a1b54aea08cfac25e49a9cab75") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - pl_PL
addappid(1497377, 1, "9a85cf3ee4d27242aa6bbbb11e6cb7056691ba568e96585355d359c90bf0e7ff") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - da_DK
addappid(1497378, 1, "56216140832b72cec435bd8a0c3beb6d9a80ac8c400fa46bcd1fd50768ed59c5") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - nl_NL
addappid(1497379, 1, "cb1729a2fc697d47912eb1ace5562e3f42cedf8a14c5bcbb97733789fb41c25c") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - fi_FI
addappid(1497380, 1, "4ac1ae1cd23e93c1eb270289150a416571d5243d4d7eb547d35478755873db44") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - no_NO
addappid(1497381, 1, "d1bed1b8d38fe6527fe0cdef15e4a03f1f3ce42df08d9bb7220b5ca590c60534") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - sv_SE
addappid(1497382, 1, "4ac82123b51bfdef68b6397a17a6f527d0b7d7ba06df811a44cae57a781541c9") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - cs_CZ
addappid(1497383, 1, "aec941fb973a8c338ba1529cd8f19cb2aa74555c2f55489b5a3a74b8f5ffcf6e") -- The Sims 4 Cottage Living Expansion Pack - The Sims 4 Cottage Living - pt_BR
-- The Sims 4 Dream Home Decorator Game Pack (AppID: 1458151)
addappid(1458151)
addappid(1458151, 1, "ffd37d4996390c8c988758e9a5190d3fdadaa40fd050947793f5761552a87b65") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - Content
addappid(1497390, 1, "ac76fea33f9d26cf01401a732d99c2d8300ce6011ab57093b7a2960e59091faa") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - en_US
addappid(1497391, 1, "c0a16eee4e180fbc745311b96ef96d6c21f922b94dd5e734503033f316816ad2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - de_DE
addappid(1497392, 1, "fdbce02dafc8ceb1960cf1d01ec3e7fa6d82bfdd7fbe95c00cf5a2a535f851f3") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - fr_FR
addappid(1497393, 1, "6eca3b14629eba6a166b6b15479e849e68200e8594a3e66943b203069cfdb22a") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - it_IT
addappid(1497394, 1, "486335a51d9008e1c0b5edb6cdda4235c4d46a86c0c26e0715db0248daf02e5e") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ko_KR
addappid(1497395, 1, "15a5e762810a381d54d1a80c77dafeccce47c896235108a5481004f9a1311f09") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - es_ES
addappid(1497396, 1, "e608ff3c8f2c61bd56f023fde6a251bb88ee3501964ddec264ba685a7ec735cd") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - zh_CN
addappid(1497397, 1, "15cb6dd33dbed378f7345b1a0330d3e1ac7813747a2993cc4eb0f8aa1e17b8fb") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - zh_TW
addappid(1497398, 1, "ecaebdb9b4ee1bd1ef36820862836dd5d4bc0c65af93cff9a484a50a69c1bbd2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ru_RU
addappid(1497399, 1, "31938cd38c41cdb8ceace01b6065f5a0ef03cfb3c827db5b8b981727602c06bb") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - ja_JP
addappid(1497400, 1, "09917bfda89b9568e0a7f318dca86c385be108c2435d14d92ba2ce56c1141d13") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - pl_PL
addappid(1497401, 1, "e94327cbb8ea0941374a5b4effa53db30cc38b1624f7e883095488037874495d") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - da_DK
addappid(1497402, 1, "574c4e612bf55c3897af79dc5fb0b53b61f6e881f4a293e9ff10318312732dd4") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - nl_NL
addappid(1497403, 1, "9bb0803a0e9a6302e5c5ff2b6569ed169d0b226cf05c6fb093422d8638b014d0") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - fi_FI
addappid(1497404, 1, "6705f6f7ad9f4fc3b60fec763a1773f51883df2c60e320ff00cc055c4319a38c") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - no_NO
addappid(1497405, 1, "cbd778f808510d69bc133522144e485e17158a708e7e5425378f9a0d21f42b21") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - sv_SE
addappid(1497406, 1, "1778570260629f14bbaaf8b5c127e2e6ae3c8609d42409ef6f521debe60ff1d2") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - cs_CZ
addappid(1497407, 1, "430af2e4a05f72b39de667af537728bb47d91466b5744829d6eeff6d2facd199") -- The Sims 4 Dream Home Decorator Game Pack - The Sims™ 4 - GP10 Depot - pt_BR
-- The Sims 4 Fashion Street Kit (AppID: 1458152)
addappid(1458152)
addappid(1458152, 1, "a5597a022fa1db03de58f11fd701496629d67ffa4e6aa427c6b3e00ed4c933cf") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - Content
addappid(1537180, 1, "6b08714bfa67e6073beed7fcebebdbc8a4991445b31083242776970a42a4563e") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - en_US
addappid(1537182, 1, "9012db1ce9b8dae017240ea1a5de21384ddf4b29aecaa25153aed7af1af341e8") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - fr_FR
addappid(1537186, 1, "cb7324ffa0173c6decd484547d23d8e493b0b3ecf4793d31e1015a382e5d5b5e") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - zh_CN
addappid(1537187, 1, "f0ee4692d48fdc47748793382a634c640cb7c3d3277150c48cfd79c612f1608e") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - zh_TW
addappid(1537188, 1, "6b307ceb09ee9e385a4e08f6c3ebfd0ddaf37193b7c29e369176139e3d2a220e") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - ru_RU
addappid(1537190, 1, "04ffcfdc3e0c43c6dad540dc92fd1cfaa977d04031374046a0f192271c1f2851") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - pl_PL
addappid(1537197, 1, "8b182cad772e221f0f2468d8ceee5fa1c5888ea195aba69425b7226f7ab57e8e") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - pt_BR
-- addappid(1537181, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - de_DE (no key available)
-- addappid(1537183, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - it_IT (no key available)
-- addappid(1537184, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - ko_KR (no key available)
-- addappid(1537185, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - es_ES (no key available)
-- addappid(1537189, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - ja_JP (no key available)
-- addappid(1537191, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - da_DK (no key available)
-- addappid(1537192, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - nl_NL (no key available)
-- addappid(1537193, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - fi_FI (no key available)
-- addappid(1537194, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - no_NO (no key available)
-- addappid(1537195, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - sv_SE (no key available)
-- addappid(1537196, 1, "MISSING_KEY") -- The Sims 4 Fashion Street Kit - The Sims™ 4 - Kit 06 Depot - cs_CZ (no key available)
-- The Sims 4 Throwback Fit Kit (AppID: 1458153)
addappid(1458153)
addappid(1458153, 1, "5f1275c1e6a53c6247f2c828503e665e5eaeb922b0cb4497f5ace6754a1adfd6") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - Content
addappid(1537200, 1, "475dd9dbcb234c637a443a9199149af7bfbc3fae5d7022ab9dc9f144334c5ed5") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - en_US
addappid(1537201, 1, "5de973f19e30b458035c7e1124252f03f4d269f69c188bf2829c535fa60f8a0b") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - cs_CZ
addappid(1537202, 1, "2b53a16e4673ef5bbd1b5cac5783245f5efc60370bbf3accdfd673a974b431b3") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - da_DK
addappid(1537203, 1, "8c39a71b47b47375a6e6490593589272e18a7abb4d58e3599bb23635d5226522") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - de_DE
addappid(1537204, 1, "dcb137547362fd040d9cfe13b3c17a73d55be8f9f2405eaa18f39eb4dc08acc6") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - es_ES
addappid(1537205, 1, "55e5ebd480e5ad1cc5709da3fae3814ccd3ba9f84be9e5e13d86a13668214615") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - fi_FI
addappid(1537206, 1, "2df95a204a264ec79b769bbf070eac413ef6d1d2a8265eb6d3df17d4f0456ae4") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - fr_FR
addappid(1537207, 1, "e8b9171719670c83f4c119569f923bf18c274bce5cad42f31d39c0cb03e817cd") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - it_IT
addappid(1537208, 1, "9c80b3b4561117bed122665f7de9951ecc17e87d5e9a70c66b2c1fb530ba18aa") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - ja_JP
addappid(1537209, 1, "43017217421742834cb8ba98c8b8dd6cd396efccc3d296ea315f27fd11d77d60") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - ko_KR
addappid(1537210, 1, "d86d7a7bca125521e66c5faa64222fd60b8335071043e8197594668fd5e3556b") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - nl_NL
addappid(1537211, 1, "ad8859cac37a6aa0fe4e7a14750b416920304e54c113706dba262bd3852547a6") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - no_NO
addappid(1537212, 1, "c816b111e646b1d487d3a4ac29e42ea445be560f5144f6f235b34412224dfd46") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - pl_PL
addappid(1537213, 1, "f0e276d65ffadfaae6e645bbd2a0c782e78b7157420be24cf00944d539eab135") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - pt_BR
addappid(1537214, 1, "645c92eb7c4ea7f2959cc0771d3208778def1af37f3f405378c90104389aa99c") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - ru_RU
addappid(1537215, 1, "85bfe7f5499b82bc748b31ea18c1cb04bd0080d598803e5f71f307c30bb89328") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - sv_SE
addappid(1537216, 1, "203af429aa4bd62bd5bb104de5615e12f863bb4d2835bf750b4b94db0ad39c4f") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - zh_TW
addappid(1537217, 1, "6dce2206ef8370f5378032512ba1d21423046ea3d12cf9fdd8174f3ba77bde53") -- The Sims 4 Throwback Fit Kit - The Sims™ 4 - Kit 02 (SP20) Depot - zh_CN
-- The Sims 4 Country Kitchen Kit (AppID: 1458154)
addappid(1458154)
addappid(1458154, 1, "1f5f1d7fe28998b617b0ded5ffb4109f351d21639f8d42e39a42da120373fed5") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - content
addappid(1537220, 1, "56f6ce4b3b5656442126cba84cf9a0f37b0a7da222949ab788372b6708b30c40") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - en_US
addappid(1537223, 1, "428899140c32507254509ba728366c97ee89f08330ebd7a3094a435f229082b9") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - de_DE
addappid(1537224, 1, "cce2241d564cb7c3e3264de64dfd898f14b5032359d9e05a7eba73cbc387fe9a") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - es_ES
addappid(1537226, 1, "a1fd5568c742659b8ca527405a2e3698b11d6cf2cef41fd9eec484965efd1b5f") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - fr_FR
addappid(1537227, 1, "e5b0738078bee4a6549e4d882b332be1bb5f597746180f9bd58106aabe303d7c") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - it_IT
addappid(1537232, 1, "9372b056edcdcfd57b79c53004bb9a4c09f1be8199a81459c8360d7bb278b162") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - pl_PL
addappid(1537233, 1, "a97e5c7dcf42a559fb8e89fc3276a4c132529cd1941170290c51a3f8d761d324") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - pt_BR
addappid(1537234, 1, "954c3948cdc342a04beb56d485752da0696d3e521c9983e5a0477b254995cb89") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - ru_RU
addappid(1537236, 1, "088fd4d57fabd6fedc31b967d1d43bf610d389a7c427a662c843cb580a1d18f1") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - zh_TW
addappid(1537237, 1, "c51f486a7fbe8e1fe7d12315119af498fa42cd7a5a8ae903d2ea9c0cf3d34fca") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - zh_CN
-- addappid(1537221, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - cs_CZ (no key available)
-- addappid(1537222, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - da_DK (no key available)
-- addappid(1537225, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - fi_FI (no key available)
-- addappid(1537228, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - ja_JP (no key available)
-- addappid(1537229, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - ko_KR (no key available)
-- addappid(1537230, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - nl_NL (no key available)
-- addappid(1537231, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - no_NO (no key available)
-- addappid(1537235, 1, "MISSING_KEY") -- The Sims 4 Country Kitchen Kit - The Sims™ 4 - Kit 03 (SP21) Depot - sv_SE (no key available)
-- The Sims 4 Bust the Dust Kit (AppID: 1458155)
addappid(1458155)
addappid(1458155, 1, "591978389c49181a3c855b5546275d5aec1289421141c1bca56dad7e1edb3574") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - content
addappid(1537240, 1, "92c3a4eebcf6f0103bef48cdfcae72353b2a786e7a383ff83df2f558eb3c9396") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - en_US
addappid(1537241, 1, "0ddb8087ecc71e96236a6caf8b96b2abfacbc9d6dbdf6cff546559efb0efdaf4") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - cs_CZ
addappid(1537243, 1, "558226bc6fb63fa0c13e604dadabe2fffb7c24da4f4388d2f02c3adad8c7a51e") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - de_DE
addappid(1537244, 1, "7d8f2d384ae36431ecab97cfc1abfd5ad769cb0d7fd1f7908f11dcd73179b259") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - es_ES
addappid(1537246, 1, "9f0165f7132b7f9e29c04fefca4523f65447557a8cd1ca20ff053df489365e9a") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - fr_FR
addappid(1537247, 1, "fefcab5b40c8ff8c841128072c34192d9b664707f3a3ce0a170d337bf158dfaa") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - it_IT
addappid(1537252, 1, "a287284e532244ae21f889cab7b3d9a495622bb91670016f23ad08e6d98da799") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - pl_PL
addappid(1537253, 1, "e6d9489c65c3aef7086eb95db6f3eb5c5f1cd339ede587dc7f18f622d8f2d2a0") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - pt_BR
addappid(1537254, 1, "85924462c3026524e6255ed9ae754ac30b03eea1c3808721d14f7976e02ba473") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - ru_RU
addappid(1537256, 1, "015526c0e566862aeda5703c2f971c699c1b241046438ce687fcd5b20a975418") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - zh_TW
addappid(1537257, 1, "746b4f26414ed2e82b76d89a5d6cabcdcae39c96fc14eed08c3dacf22c03cdd1") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - zh_CN
-- addappid(1537242, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - da_DK (no key available)
-- addappid(1537245, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - fi_FI (no key available)
-- addappid(1537248, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - ja_JP (no key available)
-- addappid(1537249, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - ko_KR (no key available)
-- addappid(1537250, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - nl_NL (no key available)
-- addappid(1537251, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - no_NO (no key available)
-- addappid(1537255, 1, "MISSING_KEY") -- The Sims 4 Bust the Dust Kit - The Sims™ 4 - Kit 04 (SP22) Depot - sv_SE (no key available)
-- The Sims 4 Courtyard Oasis Kit (AppID: 1561770)
addappid(1561770)
addappid(1561770, 1, "e1597471cb23dd0df4dcc1d5e5adbfc69338f1d1dfc1fbd9375ee77b325433c6") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - Content
addappid(1561771, 1, "783a95d3c6c5fd182b64f6071920c1eec34858474225821ae3ed827ae1aaf404") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - en_US
addappid(1561772, 1, "d2d8deafaa0ff08ae047af8a5963b895e19c5fdcbc87df616d72db00f7f9ddc3") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - de_DE
addappid(1561773, 1, "5e07d1336fcd2ad41e18eb076ba5ff0005096d012e6255d0a810d730036144b0") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - fr_FR
addappid(1561774, 1, "45bc36a84ea95f5487058e2badda5bc8b59f3c769f4576ad41698de39acbb877") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - it_IT
addappid(1561775, 1, "1a013b8af47d8cb9bcb75dddead245792802b6d934fbb4f3aaa0124792d56514") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - ko_KR
addappid(1561776, 1, "8767cce7332a16b4fa48cdbfd87e3a5b74ee41696311f2231b1d218996dc21a6") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - es_ES
addappid(1561777, 1, "8a68d455c2d9db5e90d45e84e0cfab03aaf79433c836421a905b44813ab21542") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - zh_CN
addappid(1561778, 1, "905f6cf945da8b3ff2fd9fdbf044f8c5a7989a01dad81f4f6d5fbf012aa402d9") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - zh_TW
addappid(1561779, 1, "be37ec14812441919fc5b8b18392b6a0c579876a4de4e7e7fe7d392426deed66") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - ru_RU
addappid(1612441, 1, "f428ef3ef217c198a242c6987ec7101a3852b586f75e13c1e412dac9d2d41bee") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - pl_PL
addappid(1612448, 1, "b96ba8aeaf725c1f1b31070965cee759036da19ee4dd905712aaad2c0797e93f") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - pt_BR
-- addappid(1612440, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - ja_JP (no key available)
-- addappid(1612442, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - da_DK (no key available)
-- addappid(1612443, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - nl_NL (no key available)
-- addappid(1612444, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - fi_FI (no key available)
-- addappid(1612445, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - no_NO (no key available)
-- addappid(1612446, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - sv_SE (no key available)
-- addappid(1612447, 1, "MISSING_KEY") -- The Sims 4 Courtyard Oasis Kit - The Sims™ 4 - Kit 04 (SP23) Depot - cs_CZ (no key available)
-- The Sims 4 My Wedding Stories Game Pack (AppID: 1621460)
addappid(1621460)
addappid(1621460, 1, "28046ed8b2323d2d16d2579f6d3323cf6d2d46454d37794c3f2cf424b918a70f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621460
addappid(1621461, 1, "7e31e7558c7dc87b0ac4db95c4b2e6a959784fea034a37826529c702f3618646") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621461
addappid(1621462, 1, "f24a201cc2af9985b0dab298810506fe08bd6cd11c0051abe1b8ffb77feac167") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621462
addappid(1621463, 1, "065f63aa0c61303316da44a94da51d5ed5666de1c45cdf6a8d069325d4b5e3f7") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621463
addappid(1621464, 1, "e9eefce6097f97f652dcf52931a119ae2ae376953a087d4eefcaf3e0242dc57e") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621464
addappid(1621465, 1, "c80f2d9c279e32e779b1f8e4318d128630422a626cf55e884968a6ce98fd6070") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621465
addappid(1621466, 1, "dd414190bc7ced1383e5e2fb0759accca67ae43646a5cefadd65170df182d59f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621466
addappid(1621467, 1, "bdfd89e82e34dacd4a5c705da9ab31903d70709c7697a989a89a087d1deb8d4d") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621467
addappid(1621468, 1, "0c71e07783dc6a70cb613ba7399d13d195f02cec6bec43b4d27342222150671d") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621468
addappid(1621469, 1, "0d3d8af04741c93af8adcad1ffdd01c519d0b3c8c2415089dd349105f5c8d16c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1621469
addappid(1887460, 1, "7f7b4dd63f5fb8420949b160177bfa4ea279b7394d5c5cca66e9d4907e15d078") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887460
addappid(1887461, 1, "e2837d562ea6c2087738246131ba6ebc0cfb1c3076c3560113d9ce7fc973611c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887461
addappid(1887462, 1, "18982b0ef7b419eca156c6d67572e1fc58fe98167b3181d04bcf9ddc9d5252a4") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887462
addappid(1887463, 1, "0d2519d51abab2f1fef228be9f65e17120c0d6ecb1428b434ae09a15ee434513") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887463
addappid(1887464, 1, "24991f82f1b91f3d57bd78689e9c065defc6ef79b4e46aee10f0f90d72c8c22c") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887464
addappid(1887465, 1, "15d5cb185a208f1ea0225f8de67211d0876f041d09aa1cda4d4309bc20580b2f") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887465
addappid(1887466, 1, "fad899341bfbb5f7e64f88f0487b7881200c9f588dc7660ad01ab1bc137e83f4") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887466
addappid(1887467, 1, "053afcf3d1030073242ac2c33e6683e013b41e9bf941ba0b8c150e218c8bfe94") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887467
addappid(1887468, 1, "df386664e8cbcbc12f5a10af21eb1369ba749dd077cecbeda681a5c1a67a4125") -- The Sims 4 My Wedding Stories Game Pack - Depot 1887468
-- The Sims 4 Industrial Loft Kit (AppID: 1621470)
addappid(1621470)
addappid(1621470, 1, "6b2c2923436f2495e121ed7de840bc4711d79a544100ad7a2dd5ee9f5d28c659") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - Content
addappid(1621477, 1, "890ebc22bbbbe39ad3f345fb35d3e571390e08afe5d66f898e8540058fb90492") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - en_US
addappid(1621478, 1, "b71bfc5ff211d93bf52be3c55683570d75923274179044e7b299b57c21c28787") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - de_DE
addappid(1621479, 1, "d5eea1a5ee60b682232cd4b6ebd881d1aceef00315e6dd4faec6e1f50fff396f") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - fr_FR
addappid(1705800, 1, "974ca8e4d3a9515a759c6aecbb3900e0575f37442e130bd9d6f21e12e318b1cc") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - it_IT
addappid(1705802, 1, "d774e2e335bf59e81ec042c5e8ddeed6c2c4fc6503d2e5374188667aefa337e9") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - es_ES
addappid(1705803, 1, "84e78abadfc7f5177a26bc9e065fa497a6c3c2049dc9899965f597fee85c1381") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - zh_CN
addappid(1705804, 1, "8d4a3c12a368a364a5a76390789a93293f60ccff19438f4b201a9dce8ee6bdea") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - zh_TW
addappid(1705807, 1, "58d4000ad00bf4fd5f6a33d61927d28333ba2a640ad3d1966009546ee159b92f") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - pl_PL
addappid(1705813, 1, "d4e18bdb5637ce9e9a0fb3add7c98ec9d7640cfce4cd15d5acbe00a083282cef") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - cs_CZ
addappid(1705814, 1, "d204692d4f7631d274b265c297f07df523aba613211902111224007781fbf612") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - pt_BR
-- addappid(1705801, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - ko_KR (no key available)
-- addappid(1705805, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - ru_RU (no key available)
-- addappid(1705806, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - ja_JP (no key available)
-- addappid(1705808, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - da_DK (no key available)
-- addappid(1705809, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - nl_NL (no key available)
-- addappid(1705810, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - fi_FI (no key available)
-- addappid(1705811, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - no_NO (no key available)
-- addappid(1705812, 1, "MISSING_KEY") -- The Sims 4 Industrial Loft Kit - The Sims™ 4 - Kit 07 Depot - sv_SE (no key available)
-- The Sims 4 Incheon Arrivals Kit (AppID: 1621471)
addappid(1621471)
addappid(1621471, 1, "ee2743144a3dc0fb2e9cbf830ba644903719db175dc12155f1e2f09631f64aa3") -- The Sims 4 Incheon Arrivals Kit - savecancel
addappid(1745590, 1, "1d30716a8810a6cc21bc26ce35246c75c8fbb24de0e0b4a7c4f1f51b892474f8") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - en_US
addappid(1745591, 1, "8fcbc27e9d726a7c8714a25f888308f6d31e63bf553d4f857076096c262f1fbe") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - de_DE
addappid(1745592, 1, "9f57706188073be12f128b1765b139a71de0cec2e47aaf5664017cc82f45279d") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - fr_FR
addappid(1745593, 1, "592641fbceec5456ce7ab4663c1d80c4a98079e593994ecb097edc388bee5fca") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - it_IT
addappid(1745595, 1, "ca37f0d2e900cb6851e23b1fb76d665f21bdd5f8157e97bc43d9e912fd4abcae") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - es_ES
addappid(1745596, 1, "ff7f78868109c994a6a7e7857d5075998676c7df1819906711092f89a4553d39") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - zh_CN
addappid(1745597, 1, "04a1d5e4ff064588360ca4708463f2ed4f48fbda3cbc3b8a916e83a22aed3313") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - zh_TW
addappid(1745600, 1, "a42f8e790522bfd6541753799e74f854a05d18ee0665c29c014c90a138eff5b7") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - pl_PL
addappid(1745607, 1, "8704cc0cf450b2a8c75a2a812a93685796b0dd7899bd8e7934921b72b7926676") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - pt_BR
-- addappid(1745594, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - ko_KR (no key available)
-- addappid(1745598, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - ru_RU (no key available)
-- addappid(1745599, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - ja_JP (no key available)
-- addappid(1745601, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - da_DK (no key available)
-- addappid(1745602, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - nl_NL (no key available)
-- addappid(1745603, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - fi_FI (no key available)
-- addappid(1745604, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - no_NO (no key available)
-- addappid(1745605, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - sv_SE (no key available)
-- addappid(1745606, 1, "MISSING_KEY") -- The Sims 4 Incheon Arrivals Kit - The Sims™ 4 - Kit 08 Depot - cs_CZ (no key available)
-- The Sims 4 Modern Menswear Kit (AppID: 1621473)
addappid(1621473)
addappid(1621473, 1, "831428fbef61283f57b99ac1e6863ed21e79ed22c8ece32c12ee3cc691ba9cd0") -- The Sims 4 Modern Menswear Kit - Depot 1621473
addappid(1810380, 1, "984fd014c3f12d12455995fd33ae08aceefb2c87394b1955146dfe0021f0e3a5") -- The Sims 4 Modern Menswear Kit - Depot 1810380
addappid(1810382, 1, "7620da83a1fd6440db687b501c07046330cd058a188c7d4166e88eb32105f672") -- The Sims 4 Modern Menswear Kit - Depot 1810382
addappid(1810386, 1, "ba10838aedfa5281fac9b8d39a34b7b56cb2e6d90f695b0e39a608d1abff4f0b") -- The Sims 4 Modern Menswear Kit - Depot 1810386
addappid(1810387, 1, "f1296e89e1af09c288a3305a696941b853038359424554bf567c71a055a6133d") -- The Sims 4 Modern Menswear Kit - Depot 1810387
addappid(1810388, 1, "c40a90b1b64d33313fe2518b6ea4ca4cdae09d4a1b899b2ce854c75491693144") -- The Sims 4 Modern Menswear Kit - Depot 1810388
addappid(1810390, 1, "5c7876464cd04464cb45dff06bc19eab306ba6fc19516ae8d97a7584fbc36885") -- The Sims 4 Modern Menswear Kit - Depot 1810390
addappid(1810397, 1, "727ff8e2bcdc2d7716855308de136d2875d285928837a26ab57c6e3246932031") -- The Sims 4 Modern Menswear Kit - Depot 1810397
-- addappid(1810381, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810381 (no key available)
-- addappid(1810383, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810383 (no key available)
-- addappid(1810384, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810384 (no key available)
-- addappid(1810385, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810385 (no key available)
-- addappid(1810389, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810389 (no key available)
-- addappid(1810391, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810391 (no key available)
-- addappid(1810392, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810392 (no key available)
-- addappid(1810393, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810393 (no key available)
-- addappid(1810394, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810394 (no key available)
-- addappid(1810395, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810395 (no key available)
-- addappid(1810396, 1, "MISSING_KEY") -- The Sims 4 Modern Menswear Kit - Depot 1810396 (no key available)
-- The Sims 4 Blooming Rooms Kit (AppID: 1621474)
addappid(1621474)
addappid(1621474, 1, "04d9dd9c58070c142bd2a811b306dac8c35b75958db163be6807f52cb51946c7") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - Content
addappid(1789860, 1, "c9776b7596394c0d2c7d87d0edee2e1b212b7e27b83358f5c53b87d12b101c17") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - en_US
addappid(1789861, 1, "07a95dc80cf512bbe7b054f544d174c9eb809505be695d03c5700eec1f9f692c") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - de_DE
addappid(1789862, 1, "209313b73fbd1a45a6fe612746cfac2541c3d45cef9886ec81293fa574dc8700") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - fr_FR
addappid(1789863, 1, "4d524692208a044eb3991560ba2afcf2f0f936ecfd2f49abdf7e9ddc8495c517") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - it_IT
addappid(1789864, 1, "3e8ee724e88c01ced59ebc91a13f1a785563ea8b09ed792d47a623ea5f92c710") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - ko_KR
addappid(1789865, 1, "649e39ab20880643f4ee907b6f9b8a84d0cc22a56fc71af528e4e4d232bbdcd2") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - es_ES
addappid(1789866, 1, "116f71233727ce9ac9a10af03449ebf5d4d69fbebe155ebc71e7e2329d5d41f6") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - zh_CN
addappid(1789867, 1, "1417f80601fef908c030f5328c0223e13f9b2b6a393400da7d8a069fc145dc87") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - zh_TW
addappid(1789868, 1, "94783f07f18b94bc721ac37b6374ee27769dcbbb6bb6d227e309ba5a3a8ac02f") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - ru_RU
addappid(1789869, 1, "7667dd45d11f57e0dc42810f4315ee4cf5995c43b448982fbd3fa3d9e0ba75d4") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - ja_JP
addappid(1789870, 1, "d5a6376f8a25a79df52691c59c51859c77b6409383d195937b7f766d9dfb1dc7") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - pl_PL
addappid(1789871, 1, "4d20384e1b05db7d1a2439319a98a4ee403b82a148daf6aee3bb8e8a4f790f7c") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - da_DK
addappid(1789872, 1, "d1293473286bbf3f32f2169dcc7ce191da0a71bc3419192cae68ea5c0af510e0") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - nl_NL
addappid(1789873, 1, "591765860ccabcabecb412896a0550fecfeb3891078b3e284e7d8e993c7243bb") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - fi_FI
addappid(1789874, 1, "dfb88baed6bdf5aa4cc690abc3870b51037acd244fa1fdcb270b2c7863fe8ed5") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - no_NO
addappid(1789875, 1, "c37a6fa71d0b27f658233a0efdf0518c619c1f25bcf54fea0b607b5a78871d30") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - sv_SE
addappid(1789876, 1, "fbdb608e7261ef1f1110f2547b91a0becdc2b0b6a37733374d301111525ce086") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - cs_CZ
addappid(1789877, 1, "528d2fdf6794a81a8490871786116daaf0bc409953e65777a660c9642e10de23") -- The Sims 4 Blooming Rooms Kit - The Sims™ 4 - Kit 11 Depot - pt_BR
-- The Sims 4 Carnaval Streetwear Kit (AppID: 1621475)
addappid(1621475)
addappid(1621475, 1, "2ba7531f226f4a14d9c5da08e39e4b403aa8f37cd3b7de54b73a638a9d501e2d") -- The Sims 4 Carnaval Streetwear Kit - Depot 1621475
addappid(1849980, 1, "8538bdf3b8d85de35fe32b4141bf864e4449be134d3ddeb70f9e9c7b48a549e8") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849980
addappid(1849982, 1, "09ec731f11fc43b03a467e0306ab754430bc10a155db3559344c2499b370d5a5") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849982
addappid(1849985, 1, "3deeddc1d83b0b8a0dbbe5a86b5d8d01c82d52804def085c188edaabe817940f") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849985
addappid(1849986, 1, "766e15c51f0ad6a8a7834c0ebee0d4a0ced729ed11885ee26633e29712da696c") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849986
addappid(1849987, 1, "da57d7b47883990e4e80a40c73c8d8fd5dbf45d240d28aab3ae76eee68788bbe") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849987
addappid(1849988, 1, "0121119759fe42e1a35d781561bb8e63d06a098cdb12728afff027ec4c05a3a7") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849988
addappid(1849990, 1, "68ca81c5d159e7e119f72cd765be3794eb9489a29521c9ca257d6d76b326d344") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849990
addappid(1849997, 1, "ae8e3017dfb85947d659356ad9b0e026a5d31acf0a59cd96aade6ded8a876cf9") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849997
-- addappid(1849981, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849981 (no key available)
-- addappid(1849983, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849983 (no key available)
-- addappid(1849984, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849984 (no key available)
-- addappid(1849989, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849989 (no key available)
-- addappid(1849991, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849991 (no key available)
-- addappid(1849992, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849992 (no key available)
-- addappid(1849993, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849993 (no key available)
-- addappid(1849994, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849994 (no key available)
-- addappid(1849995, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849995 (no key available)
-- addappid(1849996, 1, "MISSING_KEY") -- The Sims 4 Carnaval Streetwear Kit - Depot 1849996 (no key available)
-- The Sims 4 Decor to the Max Kit (AppID: 1621476)
addappid(1621476)
addappid(1621476, 1, "09b646f0f1a1fcce97d324325ae2f5a8a357c7c317344feebd991fa23790d42a") -- The Sims 4 Decor to the Max Kit - Depot 1621476
addappid(1922460, 1, "4f947614f1fe8583c5aaa10705163c5feb90887336991eaf441f07e96826f6c3") -- The Sims 4 Decor to the Max Kit - Depot 1922460
addappid(1922462, 1, "0944f6bdae6477eb3b7e22847f4384abf1421d4e26727cc033cb46f60853d654") -- The Sims 4 Decor to the Max Kit - Depot 1922462
addappid(1922463, 1, "f6fc64356c64373073a8d1430f17be92b125daf2a6452bbbfbadbdfc8fb1882b") -- The Sims 4 Decor to the Max Kit - Depot 1922463
addappid(1922465, 1, "5cb109f7fefa40eb4275c62f34254e082bf97c258114f9d7e1120f8388419c79") -- The Sims 4 Decor to the Max Kit - Depot 1922465
addappid(1922466, 1, "b6e7949e9f8279b311bd04ba88b932875de4f8baf6cc12690f498b12c8e937e2") -- The Sims 4 Decor to the Max Kit - Depot 1922466
addappid(1922467, 1, "6b3b14b3576e2dce900df80ede315898fa34433ccdaf755798507d12f60b629d") -- The Sims 4 Decor to the Max Kit - Depot 1922467
addappid(1922468, 1, "b8b6378f211b353fe84607d3c63f50a8f676e08636a6bd2261a0bcf4c3d2bfe3") -- The Sims 4 Decor to the Max Kit - Depot 1922468
addappid(1922470, 1, "0d18c524584d3d03f41551a8f93f72b0fa08919a742299a038b68ee6e1981b1e") -- The Sims 4 Decor to the Max Kit - Depot 1922470
addappid(1922477, 1, "11b3c5eaf55eed5ae3b8adb87bc8333d39eccdb8776c8df74d73d05c252653d7") -- The Sims 4 Decor to the Max Kit - Depot 1922477
-- addappid(1922461, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922461 (no key available)
-- addappid(1922464, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922464 (no key available)
-- addappid(1922469, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922469 (no key available)
-- addappid(1922471, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922471 (no key available)
-- addappid(1922472, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922472 (no key available)
-- addappid(1922473, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922473 (no key available)
-- addappid(1922474, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922474 (no key available)
-- addappid(1922475, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922475 (no key available)
-- addappid(1922476, 1, "MISSING_KEY") -- The Sims 4 Decor to the Max Kit - Depot 1922476 (no key available)
-- The Sims 4 Werewolves Game Pack (AppID: 1776780)
addappid(1776780)
addappid(1776780, 1, "581647324a77ddfcde726021db1659f00427fedfc80c62c10ee326bbc22095a4") -- The Sims 4 Werewolves Game Pack - Depot 1776780
addappid(1776781, 1, "af14d1368191f66458cee36dd613f5bacce0f83e138cfeda0833dd219eb5621d") -- The Sims 4 Werewolves Game Pack - Depot 1776781
addappid(1776782, 1, "ab76fb18e704719a7a016d6d56af2f66f25280ca8d2d628bdcb72f6fbfa3ce8e") -- The Sims 4 Werewolves Game Pack - Depot 1776782
addappid(1776783, 1, "285c10016631a147917528b0fd27f0b6b49101615a5fd93167eb0623d953117e") -- The Sims 4 Werewolves Game Pack - Depot 1776783
addappid(1776784, 1, "05c9ef8d532a2d29e8501228fb9ca6e136823883b147bd3ae9a7de13e5b9ac9e") -- The Sims 4 Werewolves Game Pack - Depot 1776784
addappid(1776786, 1, "2e4b478c603c7241afe0473572582253464a6c06ec2cd71807919b06197b3a2f") -- The Sims 4 Werewolves Game Pack - Depot 1776786
addappid(1776787, 1, "e32cc1612e4a44aadd7cee3a0c69507079158fea474fb6cefedac44d3f1d60d9") -- The Sims 4 Werewolves Game Pack - Depot 1776787
addappid(1776788, 1, "289d849006fa543cfc2c325af9a7e4fdd21f8b730945e431d90069e332cd7880") -- The Sims 4 Werewolves Game Pack - Depot 1776788
addappid(1776789, 1, "39fc1b17e808063ede225647f39f0bcdbe5ec0b9f2661e8421b48d14fa4c075a") -- The Sims 4 Werewolves Game Pack - Depot 1776789
addappid(2009981, 1, "5ded80576ddab62f4b9517f7330ef5719575dd2a12320d9ebe39e3aee1fa1626") -- The Sims 4 Werewolves Game Pack - Depot 2009981
addappid(2009983, 1, "e06304016e18f9fe6d18bb4d632a8b7ee05a16ea300b5ccefc916733bffb5279") -- The Sims 4 Werewolves Game Pack - Depot 2009983
addappid(2009984, 1, "f733316909e5ad6e18f5b7176a4d22909c2e131981ed87a62d6cb77ba9e5ec4e") -- The Sims 4 Werewolves Game Pack - Depot 2009984
addappid(2009985, 1, "fbaa96f88e8565ccd47ac447621f734f237537ebd031c0b1d8f870455b153849") -- The Sims 4 Werewolves Game Pack - Depot 2009985
addappid(2009987, 1, "090f76513474925e36322d95edad835860f7319ba6a404f05baff899cb27580b") -- The Sims 4 Werewolves Game Pack - Depot 2009987
addappid(2009988, 1, "aa14c1267fab491768e0aeee17ea86a3ad52d1e6cc04051f80c90adc40cb3b31") -- The Sims 4 Werewolves Game Pack - Depot 2009988
-- addappid(1776785, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 1776785 (no key available)
-- addappid(2009980, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009980 (no key available)
-- addappid(2009982, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009982 (no key available)
-- addappid(2009986, 1, "MISSING_KEY") -- The Sims 4 Werewolves Game Pack - Depot 2009986 (no key available)
-- The Sims 4 High School Years Expansion Pack (AppID: 1816550)
addappid(1816550)
addappid(1816550, 1, "fac953358c31f7117fbdcbbbe788235f57d94d0d8a2404e18effa46e4e200209") -- The Sims 4 High School Years Expansion Pack - Depot 1816550
addappid(1816551, 1, "444a2ddd006be4a9e433a8660ed7234d54f16f764c8f30030584e06994377506") -- The Sims 4 High School Years Expansion Pack - Depot 1816551
addappid(1816552, 1, "1ca8d407f53f48dfa54e4c620b5c942ccdbc7d5d8aaff5cb5a5bcdc39c4c2285") -- The Sims 4 High School Years Expansion Pack - Depot 1816552
addappid(1816553, 1, "afa2f7322142fecd39b23f1a9a05f675ce877eb4e7110f6d9cff14769b00a326") -- The Sims 4 High School Years Expansion Pack - Depot 1816553
addappid(1816554, 1, "959e56ef92858841d61d9ad311a88fd07cd09317fd175973bb9502e6d8e94fa9") -- The Sims 4 High School Years Expansion Pack - Depot 1816554
addappid(1816555, 1, "cb4296d1943075dceea6ef4941407873dfeb27356d8de938ae03f0e3f43f7a88") -- The Sims 4 High School Years Expansion Pack - Depot 1816555
addappid(1816556, 1, "616b5284a3ce5ea8f1f0436c5fe157174a089c9cec57e9b73e6ce3bdc3e6536f") -- The Sims 4 High School Years Expansion Pack - Depot 1816556
addappid(1816557, 1, "c75df932914fb2f3331d9b7b77cb4683d3500e13b81ddfa112dc90867a9b471f") -- The Sims 4 High School Years Expansion Pack - Depot 1816557
addappid(1816558, 1, "0146049a3c4dd0be433c3361e53e0b766ccf445dc63ba8335a3de55a5a5c8b5d") -- The Sims 4 High School Years Expansion Pack - Depot 1816558
addappid(1816559, 1, "87ce2619c97bbaa5c9f57167c9dc7027203bd976830c4e4455ebab5394f5df08") -- The Sims 4 High School Years Expansion Pack - Depot 1816559
addappid(2082021, 1, "36b783d21fe6f6dfc8c879683d1d99646eb1f1eb9c6ff9b018b68e0fece4c56b") -- The Sims 4 High School Years Expansion Pack - Depot 2082021
addappid(2082023, 1, "d46f82e82d82546c4dc695b1c138398b19ac6988b6efede8dc891a5409c13af3") -- The Sims 4 High School Years Expansion Pack - Depot 2082023
addappid(2082025, 1, "85dfdf623ed8f6fad99430f8e8f141d0baf3eecde1edf0985f602b37d86f9b91") -- The Sims 4 High School Years Expansion Pack - Depot 2082025
addappid(2082027, 1, "fdf8f96b05793e2ce0cfeeb1ea3b720e323bad61a3749e8610149525387bd67d") -- The Sims 4 High School Years Expansion Pack - Depot 2082027
addappid(2082028, 1, "f3de462f1718baa3143667ac0ead33a1f3579e5c79988a90785aa1acf4d56b88") -- The Sims 4 High School Years Expansion Pack - Depot 2082028
-- addappid(2082020, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082020 (no key available)
-- addappid(2082022, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082022 (no key available)
-- addappid(2082024, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082024 (no key available)
-- addappid(2082026, 1, "MISSING_KEY") -- The Sims 4 High School Years Expansion Pack - Depot 2082026 (no key available)
-- The Sims 4 Vibing Streamer Gear Digital Content (AppID: 1904370)
addappid(1904370)
addappid(1904370, 1, "4b47e953b713a8bc2ae131563db8f5134180ae07dc1c448924ae8d5f19df8764") -- The Sims 4 Vibing Streamer Gear Digital Content - Depot 1904370
-- The Sims 4 Moonlight Chic Kit (AppID: 1904390)
addappid(1904390)
addappid(1904390, 1, "2289cf614b5728458ca14e84edc144100dc1abce19a2b93bb161dc7e2b9993a8") -- The Sims 4 Moonlight Chic Kit - Depot 1904390
addappid(1904393, 1, "10b6e0e952d3347dd8ebb7e2477efec16934ecde41deee98026b98400c2e56da") -- The Sims 4 Moonlight Chic Kit - Depot 1904393
addappid(1904394, 1, "9506ca2e98bf4ab89e26b43fd355c2faa1df71925b4b09fe44ffc2a4266e5f48") -- The Sims 4 Moonlight Chic Kit - Depot 1904394
addappid(1904395, 1, "890b888024e6eef44ad1802a357e75dcbe42555af6e8602ddd7c9305afe4d719") -- The Sims 4 Moonlight Chic Kit - Depot 1904395
addappid(1904398, 1, "13fe357a3150179b7326fa63646240c63b490394e2401158979587fd79022fda") -- The Sims 4 Moonlight Chic Kit - Depot 1904398
addappid(1904399, 1, "9b2d255ea872d4878bd6ea133f9e84268fe250b83b0c1231d7980ec4acc41ac2") -- The Sims 4 Moonlight Chic Kit - Depot 1904399
addappid(1985830, 1, "a3d8e5ab7b3fce0fba42ded7b53a9d69ff60643727f3c5b1cb8b9e601f3647ee") -- The Sims 4 Moonlight Chic Kit - Depot 1985830
addappid(1985831, 1, "de648307ae7c8777059d292cb8d9f531a0b824c546b148dbfb98ad76bcb36e51") -- The Sims 4 Moonlight Chic Kit - Depot 1985831
addappid(1985833, 1, "58decb98a1a75e3547ca45cc48213a3a92cc77fea013065d0f6979806e2a9b4f") -- The Sims 4 Moonlight Chic Kit - Depot 1985833
addappid(1985840, 1, "e8c9a846362b774e217114d4763bab68f034b9f68e4cd0f0e0cf88dd6a89b009") -- The Sims 4 Moonlight Chic Kit - Depot 1985840
-- addappid(1904396, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1904396 (no key available)
-- addappid(1904397, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1904397 (no key available)
-- addappid(1985832, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985832 (no key available)
-- addappid(1985834, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985834 (no key available)
-- addappid(1985835, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985835 (no key available)
-- addappid(1985836, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985836 (no key available)
-- addappid(1985837, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985837 (no key available)
-- addappid(1985838, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985838 (no key available)
-- addappid(1985839, 1, "MISSING_KEY") -- The Sims 4 Moonlight Chic Kit - Depot 1985839 (no key available)
-- The Sims 4 Little Campers Kit (AppID: 1904391)
addappid(1904391)
addappid(1904391, 1, "fd444b7cf12d072499b64815569f8a585711da705fc96ce3f45e371339e539e1") -- The Sims 4 Little Campers Kit - Depot 1904391
addappid(1985860, 1, "b009ce5134cdb6e629ca7f523fd16677e44d1c2decd69722e589510a2c1556d1") -- The Sims 4 Little Campers Kit - Depot 1985860
addappid(1985861, 1, "ecdcf285a1ab309e79f0160cacb9506fa9420cf6f96d873ff3671eb27c544a5e") -- The Sims 4 Little Campers Kit - Depot 1985861
addappid(1985862, 1, "bd1efcda4c7c8031cb2db186698285c26761369eb75b97df1d924188f6f7d857") -- The Sims 4 Little Campers Kit - Depot 1985862
addappid(1985863, 1, "771ece9937e6d06488d9cc021e87d0725531d9d0396d25968394860c1f267eec") -- The Sims 4 Little Campers Kit - Depot 1985863
addappid(1985865, 1, "cb93f82954cc5260037f9309f916caba18943ecab0c23a6a5a1bb7f5e6b52d63") -- The Sims 4 Little Campers Kit - Depot 1985865
addappid(1985866, 1, "ce250b7b466e3d9277e884c754b9020ca4dff1f281c0ca2d813381b652a0e52d") -- The Sims 4 Little Campers Kit - Depot 1985866
addappid(1985867, 1, "658dcb69343317a137a7001cf4746c37b6d09099fe5518ed85bcf2faebe7a388") -- The Sims 4 Little Campers Kit - Depot 1985867
addappid(1985870, 1, "3e78a5bfa2eb5050a3b21eb0e4c0126ac8073676469ec49205a256a772a8bf43") -- The Sims 4 Little Campers Kit - Depot 1985870
addappid(1985872, 1, "ed6761277a06dcfabbfa26c4e1c9acff4a8f45536a5a10a8f8c993858c30c559") -- The Sims 4 Little Campers Kit - Depot 1985872
addappid(1985876, 1, "21e0f428d6d266b0df78c7ffc6c4e4d2c1a5d32af8bca63f3de2bd7aa71957b0") -- The Sims 4 Little Campers Kit - Depot 1985876
addappid(1985877, 1, "83a959505ba86c4ab32452c13ad62d5484709be5655b7f4d802e7c233ae4df76") -- The Sims 4 Little Campers Kit - Depot 1985877
-- addappid(1985864, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985864 (no key available)
-- addappid(1985868, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985868 (no key available)
-- addappid(1985869, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985869 (no key available)
-- addappid(1985871, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985871 (no key available)
-- addappid(1985873, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985873 (no key available)
-- addappid(1985874, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985874 (no key available)
-- addappid(1985875, 1, "MISSING_KEY") -- The Sims 4 Little Campers Kit - Depot 1985875 (no key available)
-- The Sims 4 Growing Together Expansion Pack (AppID: 1904392)
addappid(1904392)
addappid(1904392, 1, "35720e27381fb46832b003eb33785dc8e27b6f5076ae22b5901fb0ddd628518d") -- The Sims 4 Growing Together Expansion Pack - Depot 1904392
addappid(2112480, 1, "b861c595b9ad8bfb551c777b9cbe224f8601ea03ea9d566b01047585a43366cc") -- The Sims 4 Growing Together Expansion Pack - Depot 2112480
addappid(2112481, 1, "198ac53b99c5e62996f48ee9de53bc6a820a086f569ddcbab4e8d49bb74b007f") -- The Sims 4 Growing Together Expansion Pack - Depot 2112481
addappid(2112482, 1, "564487fe7faa30ef2f01382c9966e91a979ed837039a1b36cd685866c6ce2016") -- The Sims 4 Growing Together Expansion Pack - Depot 2112482
addappid(2112483, 1, "95887b3f16f61dbb9f3a9feef20dd10ff23918607bd860dafaebab6ce0cc9e03") -- The Sims 4 Growing Together Expansion Pack - Depot 2112483
addappid(2112485, 1, "a2c64d288bdeb3db95a29072bf397469bd5ef3e2d0b38515e7ebd02cf0ef3eff") -- The Sims 4 Growing Together Expansion Pack - Depot 2112485
addappid(2112486, 1, "129fef3ff7d919d113058cc79e5f70ff4b0cb884ce28bf83c7f6cd6ffa577ca2") -- The Sims 4 Growing Together Expansion Pack - Depot 2112486
addappid(2112487, 1, "171d729c39e69b34df5b42649dd2ac25cd6e756428867f2eed64319c43a412a1") -- The Sims 4 Growing Together Expansion Pack - Depot 2112487
addappid(2112488, 1, "ce519dbcd061b6acaf28cb6f0587775b4010abcdf1cadf5073a2e77cb27fe32c") -- The Sims 4 Growing Together Expansion Pack - Depot 2112488
addappid(2112490, 1, "c087a295833d94a764e8a79a9760d68ed3229b7191ed4cac36de1f89fad9127d") -- The Sims 4 Growing Together Expansion Pack - Depot 2112490
addappid(2112491, 1, "d44c47406a666b5e849e6f66e83f3ed00a3513e9889c854f96c8ff1faf40aee9") -- The Sims 4 Growing Together Expansion Pack - Depot 2112491
addappid(2112492, 1, "7e951281425f8b72e0716a000bc6cd359f61b6c095ae96a53a9825dbbfe0e1b6") -- The Sims 4 Growing Together Expansion Pack - Depot 2112492
addappid(2112494, 1, "19799e065c3f9ee2b134bd7c65cbf8bb27e24cd7c7285ec83e9bfa4ff8163f23") -- The Sims 4 Growing Together Expansion Pack - Depot 2112494
addappid(2112495, 1, "1cb85c1a58493adfeef28a7e5de5433478b4b83d804d74b660ef08888e090e1c") -- The Sims 4 Growing Together Expansion Pack - Depot 2112495
addappid(2112496, 1, "59d35928f45faa995c6ca2c904e63a70c8aa731a5e69f305ad70c33a17fdd2fa") -- The Sims 4 Growing Together Expansion Pack - Depot 2112496
addappid(2112497, 1, "6172bd16c311880c44c892ba4d0860129e3ea2f3489f0eca04ebab4a9ff0b3f6") -- The Sims 4 Growing Together Expansion Pack - Depot 2112497
-- addappid(2112484, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112484 (no key available)
-- addappid(2112489, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112489 (no key available)
-- addappid(2112493, 1, "MISSING_KEY") -- The Sims 4 Growing Together Expansion Pack - Depot 2112493 (no key available)
-- The Sims 4 First Fits Kit (AppID: 1932740)
addappid(1932740)
addappid(1932740, 1, "49c87003da4fc2ab3db2c142dd7a39ae6747a6f30ec9afe1d3c36589f86112ee") -- The Sims 4 First Fits Kit - Depot 1932740
addappid(1932745, 1, "103a27239b27e990f9cc975846ef8983ffad6e938c59c169daadb46aedaf0fde") -- The Sims 4 First Fits Kit - Depot 1932745
addappid(1932746, 1, "ad97f95585f7aed64e5ad5d4aed173b607dc805a4e3e44f212ee63cecf37cddb") -- The Sims 4 First Fits Kit - Depot 1932746
addappid(1932747, 1, "b76966c7a53b2ff647efccd7bbedf4f843bb7a6a29631a2020521081a05f5f90") -- The Sims 4 First Fits Kit - Depot 1932747
addappid(1932748, 1, "6e5c9f4989a13c653eed63cc56b3a36973f2fd1937ae2f0d51883cfb751760ce") -- The Sims 4 First Fits Kit - Depot 1932748
addappid(1932749, 1, "5cf8dcf3e90aed298ad97c4076f4d1deabd98f9e02eaccf8d371ebeb20ae4f81") -- The Sims 4 First Fits Kit - Depot 1932749
addappid(2112440, 1, "bc4473fec93fb7a33195f0ad45e5054b74160cebba2dd44fbd4e5fc55ee114ac") -- The Sims 4 First Fits Kit - Depot 2112440
addappid(2112441, 1, "8bfa02563a15b8d777fe3f06b366133a8e3f3ce29a5a12f3227a983d7639d9b0") -- The Sims 4 First Fits Kit - Depot 2112441
addappid(2112442, 1, "69c54b9e7dbf46df8804343690f02279367451d057cef7d5f67e4b1a92f23472") -- The Sims 4 First Fits Kit - Depot 2112442
addappid(2112443, 1, "04a817fb91ece2a2f1e2d2fcef75c96183e4812ddd3d5f7c01fed0c004d1a4bb") -- The Sims 4 First Fits Kit - Depot 2112443
addappid(2112444, 1, "4d474e213df72e2c8111cab76d315e78b2a94b1b821215ba58aa7e2394666820") -- The Sims 4 First Fits Kit - Depot 2112444
addappid(2112445, 1, "d7a72325a456f2c3bbec3da26fb544fe3097c47cf0f90bf4a92f40f1b1f8c300") -- The Sims 4 First Fits Kit - Depot 2112445
addappid(2112446, 1, "5a78bbcfb73aca4b60a4b1b32788322f2d2b4feb79237925ddb59a9891ea3177") -- The Sims 4 First Fits Kit - Depot 2112446
addappid(2112447, 1, "9c485fbfc2f1f727ffb7c6a2cfe04790db40d51981932f01632ccdf768adedba") -- The Sims 4 First Fits Kit - Depot 2112447
addappid(2112448, 1, "94d486a8722d25c72eb67f3a84170cc153e03bf5d9d420faa48dbd71439c23e0") -- The Sims 4 First Fits Kit - Depot 2112448
addappid(2112449, 1, "4d15fc7ce30dbfc6807538ee02c166e39a8ce44995ca7da87dc1bd830ef7d9e1") -- The Sims 4 First Fits Kit - Depot 2112449
addappid(2112450, 1, "ad92099685fa8ada5eff757615465d831486c88bf1a4d2febe8fb4bde43409dc") -- The Sims 4 First Fits Kit - Depot 2112450
addappid(2112451, 1, "9ea0042ac6cec94c8d218ee0b39510ed0bdce10f622f9d3a572348aebaca25f6") -- The Sims 4 First Fits Kit - Depot 2112451
addappid(2112452, 1, "b378c90eb4aa9063ac40ba1066b681ae3f6cb1db09a12b1823e571c40c072946") -- The Sims 4 First Fits Kit - Depot 2112452
-- The Sims 4 Desert Luxe Kit (AppID: 1932741)
addappid(1932741)
addappid(1932741, 1, "fe6945a7eecbfdc7cccf280562fa4254be65e98c0ced62b20258ac012e12025e") -- The Sims 4 Desert Luxe Kit - Depot 1932741
addappid(2112460, 1, "1c71cd6531032a23d04769fa34606388bd7b0aeedcd6b68239545d17236ab057") -- The Sims 4 Desert Luxe Kit - Depot 2112460
addappid(2112461, 1, "db18ab88587eafe69a329f7f486865a5cc0106b800e5e8c3ffd16e930b0c75a9") -- The Sims 4 Desert Luxe Kit - Depot 2112461
addappid(2112462, 1, "8ebf75284d558b0e034638dfb32cf3a036e2b301349b95c0753c6e24f3b58fcd") -- The Sims 4 Desert Luxe Kit - Depot 2112462
addappid(2112463, 1, "d01d7f762c555e07e30d2550df9b1d9d4e1cda03bc1c516805e75aee286a647f") -- The Sims 4 Desert Luxe Kit - Depot 2112463
addappid(2112464, 1, "e138c0f3c05e985bfb701691fd465d45d817bf88f281574fc02ec37a70eab897") -- The Sims 4 Desert Luxe Kit - Depot 2112464
addappid(2112465, 1, "45d58d7aed4ed345a843bfae216c90b59e61266f37dc6b9a4d48a2f290f49227") -- The Sims 4 Desert Luxe Kit - Depot 2112465
addappid(2112466, 1, "a96037c7924929ecb56f39da811be1a40d0e9803686e2247f54cc4321237c56d") -- The Sims 4 Desert Luxe Kit - Depot 2112466
addappid(2112467, 1, "23d1a60642bfec39b6f50e9c4096750c5c3b97ee366d22d0d07682e3691955d7") -- The Sims 4 Desert Luxe Kit - Depot 2112467
addappid(2112468, 1, "a84d9ab6055275b6de0f03471fe45868cbeb9bbd9ffeedd4c02133c5b8362d37") -- The Sims 4 Desert Luxe Kit - Depot 2112468
addappid(2112469, 1, "fc6740d3a35740acdb1b1ea88b8682858fbf81cd01a9df3350601f8747802fcd") -- The Sims 4 Desert Luxe Kit - Depot 2112469
addappid(2112470, 1, "58e7b7e8719750fe1a9f3e5ef1d6eb151ce499de9e70f31b86ee82247f83ca34") -- The Sims 4 Desert Luxe Kit - Depot 2112470
addappid(2112471, 1, "448d84e43dac1d5b8407f387e4d5f45ca5a34c684b88253eb740999a6782fc55") -- The Sims 4 Desert Luxe Kit - Depot 2112471
addappid(2112472, 1, "f08a3f05e22f00c1918a7bd346ba48152d5d96c07f3f1cc1817ac7d9a5dfd036") -- The Sims 4 Desert Luxe Kit - Depot 2112472
addappid(2112473, 1, "d4ee045fe37293e32f5e90f99bfb4c460ddca1838773a230cff058cc5263570b") -- The Sims 4 Desert Luxe Kit - Depot 2112473
addappid(2112474, 1, "52af160783fd30edebb6290ed24d16f050917fe53357ea7e43a3e79decf8fbaf") -- The Sims 4 Desert Luxe Kit - Depot 2112474
addappid(2112475, 1, "f55c5080975bbade13a0c6ba88f16df9cd855ce16037b2f6621f16bdb960abcf") -- The Sims 4 Desert Luxe Kit - Depot 2112475
addappid(2112476, 1, "a7d25aac65f3345e8cf8f8341d0859fb4e729e75e0711affaea95295c022ec27") -- The Sims 4 Desert Luxe Kit - Depot 2112476
addappid(2112477, 1, "0a6467000eb3e7cd6b3b67e865cfaf9d600b02d48259569c1da499eec4ca1d51") -- The Sims 4 Desert Luxe Kit - Depot 2112477
-- The Sims 4 Pastel Pop Kit (AppID: 1932742)
addappid(1932742)
addappid(1932742, 1, "0b633fe7eba9218f7c0d3e046cfc7f7a7d4c93527883f2e0f2450201aa651d91") -- The Sims 4 Pastel Pop Kit - Depot 1932742
addappid(2185360, 1, "715054e714c67ba9c024ee35f08aa8334d59de65a87959f685abef4f6434090d") -- The Sims 4 Pastel Pop Kit - Depot 2185360
addappid(2185361, 1, "b0dff106eebc35dcb3212db09cea70d9506022a56ed81c52437e1aacb7a56464") -- The Sims 4 Pastel Pop Kit - Depot 2185361
addappid(2185362, 1, "a4d1900a0e0acdf08844a5069789f2d2c792d9185511873bab8123c5b1225fde") -- The Sims 4 Pastel Pop Kit - Depot 2185362
addappid(2185363, 1, "c156afde5b0446b7726cdbf8fa40f403d7c1c361f9b89beb17a153b7dae0dee6") -- The Sims 4 Pastel Pop Kit - Depot 2185363
addappid(2185365, 1, "c2f7906d0dec83f794b8a43fe488d18fef67b5899c72c9f11ee3302af989a88e") -- The Sims 4 Pastel Pop Kit - Depot 2185365
addappid(2185366, 1, "cf881fa2fe32eddf02d3cfc234c5724f109c7a7736e1bd8689b83513d90226a4") -- The Sims 4 Pastel Pop Kit - Depot 2185366
addappid(2185367, 1, "23a69a00e203a956ce42072875eae85880101fc48247099b1b03d2b65fa62e16") -- The Sims 4 Pastel Pop Kit - Depot 2185367
addappid(2185370, 1, "e51792ad3988950bd1cd8cfcb9796d4a69149916b93c0bb76eb154cefebb1176") -- The Sims 4 Pastel Pop Kit - Depot 2185370
addappid(2185376, 1, "b8a300f7cb7714f3f267c16582fb4edf5b9a21cb62d406ee160d74e4200b23be") -- The Sims 4 Pastel Pop Kit - Depot 2185376
addappid(2185377, 1, "d2e06dcc19aadeab348d4950412e2b93b23aee8be08b06faaf84b7d08b914c61") -- The Sims 4 Pastel Pop Kit - Depot 2185377
-- addappid(2185364, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185364 (no key available)
-- addappid(2185368, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185368 (no key available)
-- addappid(2185369, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185369 (no key available)
-- addappid(2185371, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185371 (no key available)
-- addappid(2185372, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185372 (no key available)
-- addappid(2185373, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185373 (no key available)
-- addappid(2185374, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185374 (no key available)
-- addappid(2185375, 1, "MISSING_KEY") -- The Sims 4 Pastel Pop Kit - Depot 2185375 (no key available)
-- The Sims 4 Everyday Clutter Kit (AppID: 1932743)
addappid(1932743)
addappid(1932743, 1, "e3292f6e64b9d9501f5e3a8d6ed34a592f9314ab83650646e28faa6a8ab508cc") -- The Sims 4 Everyday Clutter Kit - Depot 1932743
addappid(2185380, 1, "7c6a82cd686cb9517301e7b41d9fd70f3c2b4cbdef30aa3b6c226e91c264c6e2") -- The Sims 4 Everyday Clutter Kit - Depot 2185380
addappid(2185381, 1, "1df94b86eb9341f533c931cf8229fb9349aeaa83c11e5b5c2c73456923ed8009") -- The Sims 4 Everyday Clutter Kit - Depot 2185381
addappid(2185382, 1, "04a92330e8e4cb9cc7014c9ab2233c6a5ab5d5aac3c179f9109a09621b2c3812") -- The Sims 4 Everyday Clutter Kit - Depot 2185382
addappid(2185383, 1, "ea1587704e2a41be319900410ec0770e6d4b3cf9e1e22a461667fda497fe6032") -- The Sims 4 Everyday Clutter Kit - Depot 2185383
addappid(2185385, 1, "a6d4680106744c3ca859a1d02411dd720d50c8a0cabc5de6a2aaf3f69380fbdf") -- The Sims 4 Everyday Clutter Kit - Depot 2185385
addappid(2185386, 1, "c6f0f424fa20742fe68ffa608eb7f5f36d032fda70987289961ebad38ecf7605") -- The Sims 4 Everyday Clutter Kit - Depot 2185386
addappid(2185387, 1, "1fc0e675237a16d91a7d65d7342b92da8a07b90eb000490572eccb80dbae90bf") -- The Sims 4 Everyday Clutter Kit - Depot 2185387
addappid(2185388, 1, "6c4b05d13acbdf6d84097564efa860d3722f7baa5b8f18b4ab25fb77ec2c98b7") -- The Sims 4 Everyday Clutter Kit - Depot 2185388
addappid(2185390, 1, "ffe4157584c72b14ae2d04de057d173487f3436a6f54f4caecdf161bf26702bd") -- The Sims 4 Everyday Clutter Kit - Depot 2185390
addappid(2185396, 1, "fe955863de8fb23a1623c063237cf0ec15b81ea068320a1e8f3a13d9340c1d28") -- The Sims 4 Everyday Clutter Kit - Depot 2185396
addappid(2185397, 1, "f326403fa610a8a71fff9d687da905001363fa60cfd1b1c259f082a12096ab1c") -- The Sims 4 Everyday Clutter Kit - Depot 2185397
-- addappid(2185384, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185384 (no key available)
-- addappid(2185389, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185389 (no key available)
-- addappid(2185391, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185391 (no key available)
-- addappid(2185392, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185392 (no key available)
-- addappid(2185393, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185393 (no key available)
-- addappid(2185394, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185394 (no key available)
-- addappid(2185395, 1, "MISSING_KEY") -- The Sims 4 Everyday Clutter Kit - Depot 2185395 (no key available)
-- The Sims 4 Horse Ranch Expansion Pack (AppID: 1990600)
addappid(1990600)
addappid(1990600, 1, "4760151948568879e2ffe7cfb1aea04c9155a3878510ab6cdb494d1c37979f9f") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990600
addappid(1990601, 1, "5ee8664c02741b666faec03233083a7fda5a4e3a72acd4d3a6d0fa8a464fddda") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990601
addappid(1990602, 1, "62579ba907e33ff0af465a9ce21db1c9325fe5ac47a1911795c9e12776c41e57") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990602
addappid(1990603, 1, "998860097a3daa31d3a4fd16832783809ff553652dbff1014ec97299186a3c71") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990603
addappid(1990604, 1, "8eea42a8a046e7cd1ca481091d1c841a087e3c92adad01e6186d17697d2201d8") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990604
addappid(1990606, 1, "51f0234995c61d9408ab0b68e0b6b5e17fc954a5eed143f7faa1b5fb9d2a4414") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990606
addappid(1990607, 1, "30d210200e8b4c6b7ecf59b118f75625f85fc886fce4cbd51155a5d9f683c1a0") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990607
addappid(1990608, 1, "d89938a74d6b65e09781d17e9dead1b733d4d4bcbf7b08f93b8a84e15462ba95") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990608
addappid(1990609, 1, "3c86bb41ebb7c78851b171bf967ddb86c9d3ab45f78c5fc14af35b83d8cc11fb") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990609
addappid(2393691, 1, "fca8a5a62f00f8c72656c7bef0c2f15a9d2fc32d4fd0d646768a1bba8051b7f0") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393691
addappid(2393693, 1, "36e44947f2a12bee0e001f17309d3d42f5176b8f5be0c21df8fb6bf0a5ebb90b") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393693
addappid(2393695, 1, "3c42ba58fc819d59e2ab5b48d662a94d7bcc12c2b6850f337cd6289143602cf0") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393695
addappid(2393696, 1, "27dad64ea1785c1030b646c963a819ad247d722768899bb893dec9b35eb02c03") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393696
addappid(2393697, 1, "cd0ca8a240f0a846690436edf72134b9174eb271c344af8f982162560f26d43f") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393697
addappid(2393698, 1, "032719a1bff90b52944a72ce3625e5e96b50c0359e7b77f019c7d97e02ff5713") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393698
-- addappid(1990605, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 1990605 (no key available)
-- addappid(2393690, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393690 (no key available)
-- addappid(2393692, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393692 (no key available)
-- addappid(2393694, 1, "MISSING_KEY") -- The Sims 4 Horse Ranch Expansion Pack - Depot 2393694 (no key available)
-- The Sims 4 Simtimates Collection Kit (AppID: 2061330)
addappid(2061330)
addappid(2061330, 1, "a06eda6e99769beb3ffedafae25b6ae5a70447d3cd299eb5b0ab205ad000a527") -- The Sims 4 Simtimates Collection Kit - Depot 2061330
addappid(2061332, 1, "352d5144b24467faeffa5ad4ba242be3395f82a92b65692de9fa0ede44a2688b") -- The Sims 4 Simtimates Collection Kit - Depot 2061332
addappid(2061333, 1, "f7785ab120146bb56cc1bcafe4250a568808101abdf3c095888b5e9961fb5614") -- The Sims 4 Simtimates Collection Kit - Depot 2061333
addappid(2061334, 1, "3437730fb2521f97d9d8b86691bcfb439b7f7f50afde8c9e7b3fb79be0b0fd0b") -- The Sims 4 Simtimates Collection Kit - Depot 2061334
addappid(2061337, 1, "1a4dc85491de42001283a65b76304af5fdb57187f641ff3ddee0f78577c3e744") -- The Sims 4 Simtimates Collection Kit - Depot 2061337
addappid(2061338, 1, "3e32b52edcd24f20e955c7f68c1a1894c68b4fa633f916676d2028400e7116ce") -- The Sims 4 Simtimates Collection Kit - Depot 2061338
addappid(2061339, 1, "10201de2630c4790bdb16007d7a6e1f3e9df73cffd24eb7aca64fd6b622bb0e6") -- The Sims 4 Simtimates Collection Kit - Depot 2061339
addappid(2243732, 1, "5cec13c41012479b779f263426bfb75210296cbaa4c858636f3a4e24dab6a25d") -- The Sims 4 Simtimates Collection Kit - Depot 2243732
addappid(2243736, 1, "630180770b4f8a7d4265fa5342de2c56b34d6aea50b29be2234672b67d0ba94f") -- The Sims 4 Simtimates Collection Kit - Depot 2243736
addappid(2243738, 1, "cdbc11f1cfda450de3b6ed908428e478c1391b8582b4e4091d630953a955ee0e") -- The Sims 4 Simtimates Collection Kit - Depot 2243738
addappid(2243739, 1, "de60ab5d3f6bfe0921fe6f51613e676109206f28f699cc19d9a5f4ee906c06fc") -- The Sims 4 Simtimates Collection Kit - Depot 2243739
-- addappid(2061335, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2061335 (no key available)
-- addappid(2061336, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2061336 (no key available)
-- addappid(2243730, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243730 (no key available)
-- addappid(2243731, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243731 (no key available)
-- addappid(2243733, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243733 (no key available)
-- addappid(2243734, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243734 (no key available)
-- addappid(2243735, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243735 (no key available)
-- addappid(2243737, 1, "MISSING_KEY") -- The Sims 4 Simtimates Collection Kit - Depot 2243737 (no key available)
-- The Sims 4 Bathroom Clutter Kit (AppID: 2061331)
addappid(2061331)
addappid(2061331, 1, "7a9f814cf1b5668e22ee59ecb68f823142c2f484bf672b9dacdba118292940b1") -- The Sims 4 Bathroom Clutter Kit - Depot 2061331
addappid(2243750, 1, "964587931561dfedab19cbf5bee320011789faaabb83f2803ec7d97f51c7585f") -- The Sims 4 Bathroom Clutter Kit - Depot 2243750
addappid(2243752, 1, "9b5888e3cde1015353540a4bed3b9e99f8367f60a0a75349e928da39467b2a19") -- The Sims 4 Bathroom Clutter Kit - Depot 2243752
addappid(2243753, 1, "e89c868d91d12070fc7835d48286a97071e7028ed74357c3fd2d78823faca23b") -- The Sims 4 Bathroom Clutter Kit - Depot 2243753
addappid(2243755, 1, "e6509176239218795d78ab15c133d93e6c3d533840103f6ee8ab31cad7591d18") -- The Sims 4 Bathroom Clutter Kit - Depot 2243755
addappid(2243756, 1, "53a93a641927bce7a1dec79866b8b03dd4f9451ea8d364f23535a032d534f6cd") -- The Sims 4 Bathroom Clutter Kit - Depot 2243756
addappid(2243757, 1, "668e5b14ee7d16c4650e3e9fd947e8a12be3f0c9b1d35a13318f0bbd77a897d7") -- The Sims 4 Bathroom Clutter Kit - Depot 2243757
addappid(2243760, 1, "48406d1c3d0c189ef05d2ecb545910810098f92256ebeb7558fac666dc814fcb") -- The Sims 4 Bathroom Clutter Kit - Depot 2243760
addappid(2243767, 1, "fda8e9a4d15bbfa2b923d6887cc3f26163418d1d7847c151f3de02752d8bb1e0") -- The Sims 4 Bathroom Clutter Kit - Depot 2243767
-- addappid(2243751, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243751 (no key available)
-- addappid(2243754, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243754 (no key available)
-- addappid(2243758, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243758 (no key available)
-- addappid(2243759, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243759 (no key available)
-- addappid(2243761, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243761 (no key available)
-- addappid(2243762, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243762 (no key available)
-- addappid(2243763, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243763 (no key available)
-- addappid(2243764, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243764 (no key available)
-- addappid(2243765, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243765 (no key available)
-- addappid(2243766, 1, "MISSING_KEY") -- The Sims 4 Bathroom Clutter Kit - Depot 2243766 (no key available)
-- The Sims 4 For Rent Expansion Pack (AppID: 2140610)
addappid(2140610)
addappid(2140610, 1, "673d782684a8135dbe163ae91fd4e4640e003e7b00ad116138f363a327ab26a2") -- The Sims 4 For Rent Expansion Pack - Depot 2140610
addappid(2140611, 1, "15d488f644f90e269447758744d69c2152ac57c70dc841587ae5060b97c6ae08") -- The Sims 4 For Rent Expansion Pack - Depot 2140611
addappid(2140612, 1, "079d3442ab7a5387cc258dd12b48ccd369e337d727af80769a409292ea97e6b1") -- The Sims 4 For Rent Expansion Pack - Depot 2140612
addappid(2140613, 1, "dfc0beaaafe0327b74aeaaba3c105f2647f404192b22caa8158ce6ebb341def3") -- The Sims 4 For Rent Expansion Pack - Depot 2140613
addappid(2140614, 1, "fed89307ccc4b71f3298af079a7cac5d40859b730c38008585316ff7d0e76f3e") -- The Sims 4 For Rent Expansion Pack - Depot 2140614
addappid(2140615, 1, "9de626fdf04354908a5c50542599ac1e24935b8365a0690e39310600b3618e93") -- The Sims 4 For Rent Expansion Pack - Depot 2140615
addappid(2140616, 1, "518993a2b489deea0c25922c7163f4025f7f1e6a9034fb0877619f869e31149a") -- The Sims 4 For Rent Expansion Pack - Depot 2140616
addappid(2140617, 1, "ebf5c98670c44cdf0384ba63af879ebfe5d7920d8547cdc71cacfd5cb3bbef9e") -- The Sims 4 For Rent Expansion Pack - Depot 2140617
addappid(2140618, 1, "8020ccf231bb389f28d7c4ab2c38e4cf34c56ab984abd8b97fe14e540f8a0ed6") -- The Sims 4 For Rent Expansion Pack - Depot 2140618
addappid(2523851, 1, "9a60c7f733c6a690b06c3ee9aea14f10d46a46cf9594907c290d31e6298822a3") -- The Sims 4 For Rent Expansion Pack - Depot 2523851
addappid(2523853, 1, "9a7e760d3ad23907fd3cd458438b9c8f56372a707c44e623b7d1e3115f7d87e1") -- The Sims 4 For Rent Expansion Pack - Depot 2523853
addappid(2523857, 1, "df87c224bd0523aec172d12f21d56f051eab2fc3a570467badf2d853d0128327") -- The Sims 4 For Rent Expansion Pack - Depot 2523857
addappid(2523858, 1, "1754770a2c793e1732fe303b098a94a7a70db2cf100b7a63a2197359a0fea5ac") -- The Sims 4 For Rent Expansion Pack - Depot 2523858
-- addappid(2140619, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2140619 (no key available)
-- addappid(2523850, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523850 (no key available)
-- addappid(2523852, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523852 (no key available)
-- addappid(2523854, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523854 (no key available)
-- addappid(2523855, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523855 (no key available)
-- addappid(2523856, 1, "MISSING_KEY") -- The Sims 4 For Rent Expansion Pack - Depot 2523856 (no key available)
-- The Sims 4 Greenhouse Haven Kit (AppID: 2167330)
addappid(2167330)
addappid(2167330, 1, "f9b163fbdb557e7821047ab65304ba97d3c36a70e14f66a41a20e9599c7ed9f3") -- The Sims 4 Greenhouse Haven Kit - Depot 2167330
addappid(2167332, 1, "bd60c06ea88d4ebb6237eda6dd4bca1c014ba5f7018c94f8a6c917d3f46a188d") -- The Sims 4 Greenhouse Haven Kit - Depot 2167332
addappid(2167333, 1, "9116662c8538e63596589cdffc98e7bd346f34cefb07a91aeab4494670e297de") -- The Sims 4 Greenhouse Haven Kit - Depot 2167333
addappid(2167334, 1, "0de0c224e368bb6bcde027e5ade31458443cb685f06e6cb045d06153b1d82b2a") -- The Sims 4 Greenhouse Haven Kit - Depot 2167334
addappid(2167335, 1, "e60872238063e67fd975995d011d294c3947029c642ad41c55e9f7334918f22d") -- The Sims 4 Greenhouse Haven Kit - Depot 2167335
addappid(2167337, 1, "3ae37693d7ebb9d40561422e94a08fe88512c3edef84ecc34d175a30d8f789f6") -- The Sims 4 Greenhouse Haven Kit - Depot 2167337
addappid(2167338, 1, "7fa1002a6a4fd2efdc58caf00b9abb903826d555aac1817f3a82619ebde857ec") -- The Sims 4 Greenhouse Haven Kit - Depot 2167338
addappid(2167339, 1, "ab0f829f818e0a3cdd040a9f5e6fdaebaee185ca26618c3cf19d51c09d477f2c") -- The Sims 4 Greenhouse Haven Kit - Depot 2167339
addappid(2243772, 1, "76061561e4126b37cb97ec1a32745d23acc88a252ff8f6b8b81800e67f3db41f") -- The Sims 4 Greenhouse Haven Kit - Depot 2243772
addappid(2243778, 1, "1732862343bb3934d64864c8bd987911930469bad3c7603cf96aab38a75b46b0") -- The Sims 4 Greenhouse Haven Kit - Depot 2243778
addappid(2243779, 1, "8dfd5673a1d75477a520d6b289fbd6a9d2557772f4dbbdfdc6fcc47bad0871ab") -- The Sims 4 Greenhouse Haven Kit - Depot 2243779
-- addappid(2167336, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2167336 (no key available)
-- addappid(2243770, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243770 (no key available)
-- addappid(2243771, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243771 (no key available)
-- addappid(2243773, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243773 (no key available)
-- addappid(2243774, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243774 (no key available)
-- addappid(2243775, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243775 (no key available)
-- addappid(2243776, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243776 (no key available)
-- addappid(2243777, 1, "MISSING_KEY") -- The Sims 4 Greenhouse Haven Kit - Depot 2243777 (no key available)
-- The Sims 4 Basement Treasures Kit (AppID: 2167331)
addappid(2167331)
addappid(2167331, 1, "d3d1326005f94e784871be83d7ee2572eff935ac0e5e98484a1d6d92953be614") -- The Sims 4 Basement Treasures Kit - Depot 2167331
addappid(2243790, 1, "4198add96ccbabd42ac78a00a61ac931d05ce50f376765b428b05126f32b6d2e") -- The Sims 4 Basement Treasures Kit - Depot 2243790
addappid(2243791, 1, "438ee161c08a9e6f05ce417e27af0901cb7565344a6ea1af9536f7ec76d173dd") -- The Sims 4 Basement Treasures Kit - Depot 2243791
addappid(2243792, 1, "c8fee852935c9e281185d451a2f34b03ccc35e92d04cba8b186e99a1c2bb87d3") -- The Sims 4 Basement Treasures Kit - Depot 2243792
addappid(2243793, 1, "c800f267b1e793c60e7744974b421cf7e6c45d73b495f30af662f850bacd40aa") -- The Sims 4 Basement Treasures Kit - Depot 2243793
addappid(2243795, 1, "f254019982a270dcbc6104ae62b73457a257db317d03ed52c33e4f5258d2ca3e") -- The Sims 4 Basement Treasures Kit - Depot 2243795
addappid(2243796, 1, "31b1fcdf87c10adf3dd1da3fee94213043df7bea13082bbf4e1aa16e5b929f08") -- The Sims 4 Basement Treasures Kit - Depot 2243796
addappid(2243797, 1, "793d207ecd5f700b335b6333ba1d0b97b2672acf11b2b60dccd517836bcdfa9c") -- The Sims 4 Basement Treasures Kit - Depot 2243797
addappid(2243800, 1, "a08fc38ebf8c5169ede854d80f0a2edf04e6b7ce9d0dc775ac8abc61f9c1b8a5") -- The Sims 4 Basement Treasures Kit - Depot 2243800
addappid(2243806, 1, "d2267c0638770d942e74a8174cc3635cf5508a72e44b0a133fce8db6baca259c") -- The Sims 4 Basement Treasures Kit - Depot 2243806
addappid(2243807, 1, "2938857c3a9626d2386a9bb48dd51a20bf356b9839a0bcdced8a1a4639401ee5") -- The Sims 4 Basement Treasures Kit - Depot 2243807
-- addappid(2243794, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243794 (no key available)
-- addappid(2243798, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243798 (no key available)
-- addappid(2243799, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243799 (no key available)
-- addappid(2243801, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243801 (no key available)
-- addappid(2243802, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243802 (no key available)
-- addappid(2243803, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243803 (no key available)
-- addappid(2243804, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243804 (no key available)
-- addappid(2243805, 1, "MISSING_KEY") -- The Sims 4 Basement Treasures Kit - Depot 2243805 (no key available)
-- The Sims 4 Grunge Revival Kit (AppID: 2278350)
addappid(2278350)
addappid(2278350, 1, "fe536d6342f292346a19f6958b497d85aa1d80f1b7581c7bc657f8b34060d2a6") -- The Sims 4 Grunge Revival Kit - Depot 2278350
addappid(2278352, 1, "8301fc01df77f9541a8f40e88d720f60e7dcdea05bccae808d7ad0cc25ecf13d") -- The Sims 4 Grunge Revival Kit - Depot 2278352
addappid(2278353, 1, "e7b9cc9ce0b7a4e7931801e476b6d8b506acb5a4caf6400a8e6206b67e319224") -- The Sims 4 Grunge Revival Kit - Depot 2278353
addappid(2278354, 1, "867e40a3fb59bdad890ae85bf375d31fd26071719b2a4b0d994e5515e54dc3f8") -- The Sims 4 Grunge Revival Kit - Depot 2278354
addappid(2278355, 1, "ea337fb21144dd311cc5802d48ab8b927db3a05a5040dbeb8f639fe9f171f878") -- The Sims 4 Grunge Revival Kit - Depot 2278355
addappid(2278356, 1, "81d741da6741c0cbcb5448d17afb7e6561daf68f19523d2be34596a93862be62") -- The Sims 4 Grunge Revival Kit - Depot 2278356
addappid(2278357, 1, "075b84228791b0e5f4627046a2ee1d54bad8044175760f7d1c8919df1a16643d") -- The Sims 4 Grunge Revival Kit - Depot 2278357
addappid(2278358, 1, "e0a9cec2e744468eefb0b3b040652de4af208ea8ca8844e492ee6ac68442bc22") -- The Sims 4 Grunge Revival Kit - Depot 2278358
addappid(2278359, 1, "44fa8ecfc0f21b0206d89d0e8d636d38b41482718f74cf184509fab334e8dd46") -- The Sims 4 Grunge Revival Kit - Depot 2278359
addappid(2438840, 1, "1290eb686c6ce0be0c92a22675ca5f29531bfd20c4f2150d99672d06ae20b71b") -- The Sims 4 Grunge Revival Kit - Depot 2438840
addappid(2438841, 1, "f5c0317f152745fd34ad2490c06f57e3aa0082384b273cd522d641411ec45eba") -- The Sims 4 Grunge Revival Kit - Depot 2438841
addappid(2438842, 1, "af5e729bf035204ded66e11f24c949e323b2ddcd1a4d4dd50fce0cdf1c46b0fa") -- The Sims 4 Grunge Revival Kit - Depot 2438842
addappid(2438843, 1, "5b930b18668f7e2cfa6b57ec4740c396488a7a844ee1f9f6449de60802bd9b01") -- The Sims 4 Grunge Revival Kit - Depot 2438843
addappid(2438844, 1, "139f2dcd167f6519c7a458220df15631e4f83493408d9dbd43d430fd054e9402") -- The Sims 4 Grunge Revival Kit - Depot 2438844
addappid(2438845, 1, "ab6b3bb34afbbed04a685cc32f8cbd9ec40eb5283983fdb6c2f18506e91736ec") -- The Sims 4 Grunge Revival Kit - Depot 2438845
addappid(2438846, 1, "938546a8e474c9162f0efa050609801b218b5d9f8d2acc539a15603a2fb1a748") -- The Sims 4 Grunge Revival Kit - Depot 2438846
addappid(2438847, 1, "28d2767e51c9ce7d3220e967e060b3b0c2a63393b729c3ea6cd075130d639250") -- The Sims 4 Grunge Revival Kit - Depot 2438847
addappid(2438848, 1, "7dab8e9b27fe58e7b3687ef114f1e838984dc6b21c9484905ecdd245b797730d") -- The Sims 4 Grunge Revival Kit - Depot 2438848
addappid(2438849, 1, "662303bce6e6195741f35bb59bf0fec6e6aa0ec207938e74c3ac55dc2d872dc4") -- The Sims 4 Grunge Revival Kit - Depot 2438849
-- The Sims 4 - Kit 25 (AppID: 2278351)
addappid(2278351)
addappid(2278351, 1, "36b874eff6f43fba3d183fd922b23533e3085f46ba613ddfa0e0f809a5d6e7bf") -- The Sims 4 - Kit 25 - Depot 2278351
addappid(2438860, 1, "41c7431520d0d2904c37f27012507c210e01ad631495ff71e98ba5b2b72524bd") -- The Sims 4 - Kit 25 - Depot 2438860
addappid(2438861, 1, "89d29daafa38e85e88e3456a05e69b52844aae874bb93162edccec4ed690faec") -- The Sims 4 - Kit 25 - Depot 2438861
addappid(2438862, 1, "d3d372bbdf4e26af0ce44af668d962af21599301cf7dfbda5c652de432186e87") -- The Sims 4 - Kit 25 - Depot 2438862
addappid(2438863, 1, "59691cee559bfeaa225cbfd095c765abb30d9197c9e01bda8da8ed60d53ce0b8") -- The Sims 4 - Kit 25 - Depot 2438863
addappid(2438865, 1, "df1854795aac1b0cb9d57f310d73903743a642f68eff43e44fe4a9ede1a5fe15") -- The Sims 4 - Kit 25 - Depot 2438865
addappid(2438866, 1, "883137bd34ce1410cb0584d1b8f6fd399edb29e8d326b70f60998116705c967a") -- The Sims 4 - Kit 25 - Depot 2438866
addappid(2438867, 1, "b3d42eac03e07d4bbac2547313b275076b7d9ca4a30e45f1fc6452249afbf799") -- The Sims 4 - Kit 25 - Depot 2438867
addappid(2438870, 1, "b972fc610da65785ff9b3d9708a3902ef94c4ec1d3a3aba0bd261f80b67ee0d6") -- The Sims 4 - Kit 25 - Depot 2438870
addappid(2438876, 1, "89a988885b823298941ff8457585148fe1fe7770d6a45176ea89e1a2878b0dc8") -- The Sims 4 - Kit 25 - Depot 2438876
addappid(2438877, 1, "bc060e59b4316749ece2d5126bf4df9b429c09337505e6aacbd0050bb723320d") -- The Sims 4 - Kit 25 - Depot 2438877
-- addappid(2438864, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438864 (no key available)
-- addappid(2438868, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438868 (no key available)
-- addappid(2438869, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438869 (no key available)
-- addappid(2438871, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438871 (no key available)
-- addappid(2438872, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438872 (no key available)
-- addappid(2438873, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438873 (no key available)
-- addappid(2438874, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438874 (no key available)
-- addappid(2438875, 1, "MISSING_KEY") -- The Sims 4 - Kit 25 - Depot 2438875 (no key available)
-- The Sims 4 Home Chef Hustle Stuff Pack (AppID: 2304400)
addappid(2304400)
addappid(2304400, 1, "7da8766d3138210a0874a4d396388318316db594e9578995506ecdeabb8d670d") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304400
addappid(2304401, 1, "8e7cb9b178868487cd33f1e0a6b168bf99d0df6474cccf48368d8eaca36888a5") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304401
addappid(2304402, 1, "0eb71635155df32ea5bdc5eb2aa9feda2ce26fa2853378cb7ee1eda53ce77f2c") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304402
addappid(2304403, 1, "d2ba4cdc49398fe3effb4662e58130791573df6367a3544722514d716b4501d6") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304403
addappid(2304404, 1, "18d2e6493127f196820de3699d878bb30e250ee22125e853666c66e5ffcf0708") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304404
addappid(2304406, 1, "992ff91eee06b31677bb50b8d0ee8833918c3ecb4a9cf863426f37a191bc3b66") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304406
addappid(2304407, 1, "bf404f6bd8a2e7303b940045879668cbd9bc56384a8288f8341a4adf8d17aee9") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304407
addappid(2304408, 1, "753e7677f605d872223fa85ee8dcabb791d648c39593be72fbb441c1cb356fb2") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304408
addappid(2304409, 1, "430b767df09786b7421c25e889c78a36cfd5148991ad3d395472843c42dc580a") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304409
addappid(2523831, 1, "5eb3cdd899c2077f32af89c86e65f560f671640e4a79d7f249d0a943cce7733c") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523831
addappid(2523833, 1, "1ba6f2330071330b2feb8647821cfdeb92ca7cf5f2eae7544781a045978f8c8d") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523833
addappid(2523835, 1, "667c31fe89872b1e7fa6bc5ecf26b4bb7e53ccf45adfdeb039e30ce5b69c0a46") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523835
addappid(2523837, 1, "0137a2a21a9df5c9c6de4dae19933224410a45bf751a85ce8ae66d14ce5a151a") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523837
addappid(2523838, 1, "5e76e89e6dc148d8e3578fc0a14450b2a81f631adfca8eec8085e9dd99093649") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523838
-- addappid(2304405, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2304405 (no key available)
-- addappid(2523830, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523830 (no key available)
-- addappid(2523832, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523832 (no key available)
-- addappid(2523834, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523834 (no key available)
-- addappid(2523836, 1, "MISSING_KEY") -- The Sims 4 Home Chef Hustle Stuff Pack - Depot 2523836 (no key available)
-- The Sims 4 Poolside Splash Kit (AppID: 2397790)
addappid(2397790)
addappid(2397790, 1, "4cc231d3c89d76c8769b54049df764b7892c9674e6a751d931fa5873f014ad0e") -- The Sims 4 Poolside Splash Kit - Depot 2397790
addappid(2397792, 1, "fc4a87950a63560d775450c58af7e848313e2e2ff5bb2b8e683b547e4cf6f01e") -- The Sims 4 Poolside Splash Kit - Depot 2397792
addappid(2397793, 1, "3f84b2e9e62eb80d851eda56103bc8f8656cafb156bc7612f4c4c1deafe992f7") -- The Sims 4 Poolside Splash Kit - Depot 2397793
addappid(2397794, 1, "8c5ab81a59822edd4a8b4188126927d62520a2b847a4d45121e44ce212d7e7d7") -- The Sims 4 Poolside Splash Kit - Depot 2397794
addappid(2397798, 1, "ea05e74fd0dcb8097f95c82723195b0b2acbcb39256cb44b846151afbc026dc2") -- The Sims 4 Poolside Splash Kit - Depot 2397798
addappid(2397799, 1, "cd8348836e9d01f226c8b4034dd6862a53edf950387e132649775fd99a2599eb") -- The Sims 4 Poolside Splash Kit - Depot 2397799
addappid(2438882, 1, "47667dcfe7b3d90229f7366e5c47545e904c0e10f82c3d9991b2dd6a21d9667c") -- The Sims 4 Poolside Splash Kit - Depot 2438882
addappid(2438888, 1, "c4b0c795e6cebaba4eae9d9a2f08c5fec2574638dd5d17d22ba9dd755a827d6c") -- The Sims 4 Poolside Splash Kit - Depot 2438888
addappid(2438889, 1, "240f986320feb0fda553f97b06ea14922f6acfb4b2a561314e0293b5c27e7ee5") -- The Sims 4 Poolside Splash Kit - Depot 2438889
-- addappid(2397795, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2397795 (no key available)
-- addappid(2397796, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2397796 (no key available)
-- addappid(2397797, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2397797 (no key available)
-- addappid(2438880, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438880 (no key available)
-- addappid(2438881, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438881 (no key available)
-- addappid(2438883, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438883 (no key available)
-- addappid(2438884, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438884 (no key available)
-- addappid(2438885, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438885 (no key available)
-- addappid(2438886, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438886 (no key available)
-- addappid(2438887, 1, "MISSING_KEY") -- The Sims 4 Poolside Splash Kit - Depot 2438887 (no key available)
-- The Sims 4 Modern Luxe Kit (AppID: 2397791)
addappid(2397791)
addappid(2397791, 1, "8e1e538712f9f1cdf62daf6b11e7e5ad60019d92f547924d30ca6b9c153111c2") -- The Sims 4 Modern Luxe Kit - Depot 2397791
addappid(2438910, 1, "3df868de6ab6aea3740edc276473109e4d50f2dbd9f3a3522d7e05a12af96eed") -- The Sims 4 Modern Luxe Kit - Depot 2438910
addappid(2438911, 1, "6ac51223073ed3b2e57baa4b4901a1f796dfd92ddf1fcc5a711f86397431a347") -- The Sims 4 Modern Luxe Kit - Depot 2438911
addappid(2438912, 1, "7bbca550eddc8822b758633834e907ddabe5d6ea89b072eccc3ddd4e11b8218b") -- The Sims 4 Modern Luxe Kit - Depot 2438912
addappid(2438913, 1, "59533fa0814efbce72d91460eb8f3d9fc32621152eebe41223890dd2c5eba872") -- The Sims 4 Modern Luxe Kit - Depot 2438913
addappid(2438915, 1, "80d5044d78a1a427cf3821db1a4193e6d70cdbdae8da1c521204719436894fe5") -- The Sims 4 Modern Luxe Kit - Depot 2438915
addappid(2438916, 1, "12bb4ed4f8718ce85d32dafd4de570b3760240ddcfc39626d20c1bbd6f838df5") -- The Sims 4 Modern Luxe Kit - Depot 2438916
addappid(2438917, 1, "9f227dc2f2f97ba1ef065cd6517bb5e2981970ef2f24a8f9d732b85739e0b3ce") -- The Sims 4 Modern Luxe Kit - Depot 2438917
addappid(2438918, 1, "991c4ae5ec8eb0cd2b3dda73b4a6eaaca6200b6f88f731eb860ed9e4082f871f") -- The Sims 4 Modern Luxe Kit - Depot 2438918
addappid(2438920, 1, "8e6bb65e2d896f40b7592325795f3b0ae5b31d14da18919e971976ebffbfea14") -- The Sims 4 Modern Luxe Kit - Depot 2438920
addappid(2438926, 1, "f7e50b8189e29dd1f2789007cd68df4d9afa927e9bee2c80ef0455b7e7945297") -- The Sims 4 Modern Luxe Kit - Depot 2438926
addappid(2438927, 1, "9728b9268b8094ac2d2c24065a792a43558a75c0db6bbd2f9bf03656f7c4108c") -- The Sims 4 Modern Luxe Kit - Depot 2438927
-- addappid(2438914, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438914 (no key available)
-- addappid(2438919, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438919 (no key available)
-- addappid(2438921, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438921 (no key available)
-- addappid(2438922, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438922 (no key available)
-- addappid(2438923, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438923 (no key available)
-- addappid(2438924, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438924 (no key available)
-- addappid(2438925, 1, "MISSING_KEY") -- The Sims 4 Modern Luxe Kit - Depot 2438925 (no key available)
-- The Sims 4 Castle Estate Kit (AppID: 2727370)
addappid(2727370)
addappid(2727370, 1, "aa354f07ff391bd72be1f2dc238bc564736b840076866782172a4449f88d3e1c") -- The Sims 4 Castle Estate Kit - Depot 2727370
addappid(2727371, 1, "6ad548045c96c2b692589e48dc0edb2d5ff6ce046caedd161fee737350c67873") -- The Sims 4 Castle Estate Kit - Depot 2727371
addappid(2727372, 1, "961b9a01429127657a3d80b42ea0596e083fa2ba99a1d024b91f81baf117bfb6") -- The Sims 4 Castle Estate Kit - Depot 2727372
addappid(2727373, 1, "be49e3bc54f504bd0b2fc9e89f154fa3edc8dcaaf3d00021df9a34e2a3e9548f") -- The Sims 4 Castle Estate Kit - Depot 2727373
addappid(2727374, 1, "e0b6cac0d96634a0bd1e54018ed29a4b4e9ec83ea6b6abe740a5cdb5a3d0ab2c") -- The Sims 4 Castle Estate Kit - Depot 2727374
addappid(2727376, 1, "ef3df73e07f5fa7b981ca3b3a3edb2c4b6ff5b230de34b708a1b6208920c3f8e") -- The Sims 4 Castle Estate Kit - Depot 2727376
addappid(2727377, 1, "05a97f9c71dc66f8b9ff1c416d2da3b2f667bb3424186cec2e759b3e6575af8f") -- The Sims 4 Castle Estate Kit - Depot 2727377
addappid(2727378, 1, "e8af659074859cc3683100472a6915dac83cc2578b3235087bc38d38208dbb7f") -- The Sims 4 Castle Estate Kit - Depot 2727378
addappid(2733211, 1, "4c2ead2a3ff198f7666016fb92cd99770fd5055ef85f17a0debada73edef6501") -- The Sims 4 Castle Estate Kit - Depot 2733211
addappid(2733213, 1, "7b1444083a9e628f074389433a7fa901f47bfed1bf66013b49a5518c4d980ee9") -- The Sims 4 Castle Estate Kit - Depot 2733213
addappid(2733218, 1, "c1c3b0162ee341e95098f05fe39352507453061769a0030e2e39a2b3fd31fe99") -- The Sims 4 Castle Estate Kit - Depot 2733218
-- addappid(2727375, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2727375 (no key available)
-- addappid(2727379, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2727379 (no key available)
-- addappid(2733210, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733210 (no key available)
-- addappid(2733212, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733212 (no key available)
-- addappid(2733214, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733214 (no key available)
-- addappid(2733215, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733215 (no key available)
-- addappid(2733216, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733216 (no key available)
-- addappid(2733217, 1, "MISSING_KEY") -- The Sims 4 Castle Estate Kit - Depot 2733217 (no key available)
-- The Sims 4 Goth Galore Kit (AppID: 2727380)
addappid(2727380)
addappid(2727380, 1, "a479c06948bbb843a46006628bea861c5f4f34b2edea3f7dd251a4db5e58e146") -- The Sims 4 Goth Galore Kit - Depot 2727380
addappid(2727381, 1, "3e850836f4240f8e49dbad2c2818ce36a822f6f9909fb3e6a6939eb62b549bbf") -- The Sims 4 Goth Galore Kit - Depot 2727381
addappid(2727382, 1, "06ebc4fec1432c31a0f6d60a92d6ff5f256f2dab566cf1d842b2dc0d213fe365") -- The Sims 4 Goth Galore Kit - Depot 2727382
addappid(2727383, 1, "ac2a851976766f89f0b79e6c7ceec37f27c50ce02c85ff869b711a9f3135f65c") -- The Sims 4 Goth Galore Kit - Depot 2727383
addappid(2727384, 1, "bd2ff5f9ba8c9a99a46f9b57b2c38bb7bcc9f40fdbc5e297c6ae6be1a1604008") -- The Sims 4 Goth Galore Kit - Depot 2727384
addappid(2727386, 1, "05884703d955287b5b0c8d0683989d5e22b72aa6c2600064e2556e42091b7951") -- The Sims 4 Goth Galore Kit - Depot 2727386
addappid(2727387, 1, "4df9efa072f81856151bbeb23682dc50e447a3f333a38b06bbbaaa192913aedb") -- The Sims 4 Goth Galore Kit - Depot 2727387
addappid(2727388, 1, "709eb7f0f7554c2d97a47a469ebd33296dbdb56f6699ca7567b4dc6721b2ac4a") -- The Sims 4 Goth Galore Kit - Depot 2727388
addappid(2727389, 1, "1afe16a972ca5dffbae3616435f456538dcf2d68d24553c2052f3041fbb1698a") -- The Sims 4 Goth Galore Kit - Depot 2727389
addappid(2733231, 1, "f6c524651f718adca7fe4327aeb7a81be7686886b9b06401cf4a9b9e026fd63d") -- The Sims 4 Goth Galore Kit - Depot 2733231
addappid(2733233, 1, "93fb873a9ff580aac64cae75ab9c73a04852b72f2ea89deab596c8bf4e60be32") -- The Sims 4 Goth Galore Kit - Depot 2733233
addappid(2733237, 1, "aae1a138fa070fcdc987510997769756ad177f3b545a1c30f5a31f5bbe10385f") -- The Sims 4 Goth Galore Kit - Depot 2733237
addappid(2733238, 1, "5ff05b312c80bd6af29a87c4784504e6f84006ef790e6072078b7bb464e28936") -- The Sims 4 Goth Galore Kit - Depot 2733238
-- addappid(2727385, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2727385 (no key available)
-- addappid(2733230, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2733230 (no key available)
-- addappid(2733232, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2733232 (no key available)
-- addappid(2733234, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2733234 (no key available)
-- addappid(2733235, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2733235 (no key available)
-- addappid(2733236, 1, "MISSING_KEY") -- The Sims 4 Goth Galore Kit - Depot 2733236 (no key available)
-- The Sims 4 Crystal Creations Stuff Pack (AppID: 2727400)
addappid(2727400)
addappid(2727400, 1, "401d8579601f6ea05bff0a77254bfbfc9174c67887926451025926cd3da3cfd6") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727400
addappid(2727401, 1, "12851d9b7f95a41fe20ef3b71a3385a34ff1d248715b389707e18a1b73b5db14") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727401
addappid(2727402, 1, "ac552fbe641c51e6e5ec7e6367c9cbf484e0012f90ae2845026a0df9702cd78a") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727402
addappid(2727403, 1, "27cc61c5a2e077c815b802967ede8f19e6365d2d323136b0398555438634700b") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727403
addappid(2727404, 1, "1dd302b15d7693f33734c40345047c50bbaf27d28384bbacc21147825245da4a") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727404
addappid(2727406, 1, "9786dfc701d651548749b96461dffd77d597cf5036ae5fd61d202df7a2013525") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727406
addappid(2727407, 1, "519d2893237ef17c305ea74cbe153c6e198a76c1739bb46a5f09423f9e2fbbd1") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727407
addappid(2727408, 1, "c7bd005f955e6bcf83fca2327405e64cb04ce0b688178cdbb08c823bac121713") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727408
addappid(2727409, 1, "b680ca9953c30bb756b80c8a0f2a532efba412cf09d996777d1f402dfe60532b") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727409
addappid(2827091, 1, "1c3cfca693910cbff90f36e88dfbeaaa6c4579c9c6d1dbe9b7701877e0316cd9") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827091
addappid(2827097, 1, "2807f2010af3933fd92ca88c68e315e59d36e1c745548b44df84353ab269a7e1") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827097
addappid(2827098, 1, "6e4b7d22384bccef70b38a3f390ccc88843ceee9ed35dfb6bad94461fa69365e") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827098
-- addappid(2727405, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2727405 (no key available)
-- addappid(2827090, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827090 (no key available)
-- addappid(2827092, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827092 (no key available)
-- addappid(2827093, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827093 (no key available)
-- addappid(2827094, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827094 (no key available)
-- addappid(2827095, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827095 (no key available)
-- addappid(2827096, 1, "MISSING_KEY") -- The Sims 4 Crystal Creations Stuff Pack - Depot 2827096 (no key available)
-- The Sims 4 Party Essentials Kit (AppID: 2738340)
addappid(2738340)
addappid(2738340, 1, "195a5d95ba2897cf057cc130383592c35de3d569b515b7588046089e873fab73") -- The Sims 4 Party Essentials Kit - Depot 2738340
addappid(2738341, 1, "5f21d8786839b17c3d4b31e3de9b7238ee19e5c60b650a1ce87fc53463d5192c") -- The Sims 4 Party Essentials Kit - Depot 2738341
addappid(2738342, 1, "5ef47de2a6f37998fc108450056889b3d3ebdedc157d8c827ab00539f1e33fee") -- The Sims 4 Party Essentials Kit - Depot 2738342
addappid(2738343, 1, "fc4f8c391706e24155894fc71f38d6143b360580c218a22bdb7f70ef9deda5f6") -- The Sims 4 Party Essentials Kit - Depot 2738343
addappid(2738344, 1, "99418d254cce15ee051753ff8eb1a271e8ebcfcffa2c1c50d9731e7d92db138f") -- The Sims 4 Party Essentials Kit - Depot 2738344
addappid(2738346, 1, "75991c61600a869629375795e992a0a3af185c4ead8172c53649eb361441a131") -- The Sims 4 Party Essentials Kit - Depot 2738346
addappid(2738347, 1, "cf08e30468b56ecd8b36e0c83e3fc049818806a1be38bd2075de8f534868ac0e") -- The Sims 4 Party Essentials Kit - Depot 2738347
addappid(2738348, 1, "a7dd2a81052ce1b9dd62a3b4059da78b4ed6ce1cdc96410d9bd4382630a1cc49") -- The Sims 4 Party Essentials Kit - Depot 2738348
addappid(2910631, 1, "36ce4caf702e66e512a6c574832472843c1d09e46730af8e7daf843055b3bb89") -- The Sims 4 Party Essentials Kit - Depot 2910631
addappid(2910637, 1, "21d4eb3e7df3843ab3d0f71e886be066d22ac0fd014a39e676da9cc683043401") -- The Sims 4 Party Essentials Kit - Depot 2910637
addappid(2910638, 1, "2202685f28a114fda95f0c681530f5d201f1e75666c410356a098bf82de1d2ae") -- The Sims 4 Party Essentials Kit - Depot 2910638
-- addappid(2738345, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2738345 (no key available)
-- addappid(2738349, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2738349 (no key available)
-- addappid(2910630, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910630 (no key available)
-- addappid(2910632, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910632 (no key available)
-- addappid(2910633, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910633 (no key available)
-- addappid(2910634, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910634 (no key available)
-- addappid(2910635, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910635 (no key available)
-- addappid(2910636, 1, "MISSING_KEY") -- The Sims 4 Party Essentials Kit - Depot 2910636 (no key available)
-- The Sims 4 - Urban Homage Kit 30 (AppID: 2738350)
addappid(2738350)
addappid(2738350, 1, "87bb061015263c26d83219bbf221b4181ae5290637e82cda1b76d37574694190") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738350
addappid(2738351, 1, "3dc1f657a4a39bffab1acff705df17c51510f7ae08dc72e78ef3b521afc5bb7b") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738351
addappid(2738352, 1, "01c612bb673f91b5ee04e54aa63f229ffdbac424bc4f88b0d9dc36e03372ff9b") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738352
addappid(2738353, 1, "c7b035e8fd491c77d7cceb41217ef7c178a9967b4185e0977b5ffa67d6f2c78b") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738353
addappid(2738354, 1, "c5549554e1e3900674ec7d655c34bae8be1ef0a573018b82d66f18bfa5038088") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738354
addappid(2738356, 1, "b0001530b4cf6b246b3603b0d3f93d28cb7e573f94944d1b21988a88d9c7698c") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738356
addappid(2738357, 1, "c2a1f52fefa6c9627c3013b0712589b4cd4e89f26e4ea0af7781129e7b9869fb") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738357
addappid(2738358, 1, "9a4f821ff2d6f0e28054614fa092908faf5d9466ad4f394aeb8bcb58d2fe3c35") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738358
addappid(2910611, 1, "869c28d988e7a55baa03dd4d60ba887d57711580467712c3b2cedb8879bf9b3a") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910611
addappid(2910618, 1, "879bf3cbe0affe1c0d9bd293f9e338f22b631d60832c8b439423fe87261e84f7") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910618
-- addappid(2738355, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738355 (no key available)
-- addappid(2738359, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2738359 (no key available)
-- addappid(2910610, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910610 (no key available)
-- addappid(2910612, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910612 (no key available)
-- addappid(2910613, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910613 (no key available)
-- addappid(2910614, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910614 (no key available)
-- addappid(2910615, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910615 (no key available)
-- addappid(2910616, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910616 (no key available)
-- addappid(2910617, 1, "MISSING_KEY") -- The Sims 4 - Urban Homage Kit 30 - Depot 2910617 (no key available)
-- The Sims 4 Pool Kit 32 (AppID: 2782860)
addappid(2782860)
addappid(2782860, 1, "cce512eff6fdedf56cb302535945168426b3b177fda14193c7e07345e380c25d") -- The Sims 4 Pool Kit 32 - Depot 2782860
addappid(2782861, 1, "8ac2fc925c3e3f4393af0648414b35c55b2973af2c76c50fc34f07d523f271fd") -- The Sims 4 Pool Kit 32 - Depot 2782861
addappid(2782862, 1, "feec3e8977995fb941a0f53178d36cc2bd0718dbb0c0d06fa9af91fe44a3c745") -- The Sims 4 Pool Kit 32 - Depot 2782862
addappid(2782863, 1, "0ada2435637de3d0a7696d85087c500142405fc4a4fed754f30aeb88dfbe4640") -- The Sims 4 Pool Kit 32 - Depot 2782863
addappid(2782864, 1, "600fbf87ab85a1ac9b7890ba823c792ceb9c6cd6797ff33cd8a0e29d5e1ad0a0") -- The Sims 4 Pool Kit 32 - Depot 2782864
addappid(2782867, 1, "037a6a8c79cf1fae05309c509a57669f8e1e34f64216a82e27b0ba68b93b7843") -- The Sims 4 Pool Kit 32 - Depot 2782867
addappid(2782868, 1, "5682fcbfc7d09db726b5d6516b7a8f7f97878803ff639e4dad94e5dec82cb56a") -- The Sims 4 Pool Kit 32 - Depot 2782868
addappid(2982171, 1, "8b842962efdefde7443c1f049e3d483167694fbe1d5853a8c43d035c35e7d00d") -- The Sims 4 Pool Kit 32 - Depot 2982171
addappid(2982178, 1, "380ffe04eaa45aba05430eb09957d5e1e97c5b49a296469d4f7fe5c50af4f6fa") -- The Sims 4 Pool Kit 32 - Depot 2982178
-- addappid(2782865, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2782865 (no key available)
-- addappid(2782866, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2782866 (no key available)
-- addappid(2782869, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2782869 (no key available)
-- addappid(2982170, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982170 (no key available)
-- addappid(2982172, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982172 (no key available)
-- addappid(2982173, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982173 (no key available)
-- addappid(2982174, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982174 (no key available)
-- addappid(2982175, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982175 (no key available)
-- addappid(2982176, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982176 (no key available)
-- addappid(2982177, 1, "MISSING_KEY") -- The Sims 4 Pool Kit 32 - Depot 2982177 (no key available)
-- The Sims 4 Bistro Kit 33 (AppID: 2782870)
addappid(2782870)
addappid(2782870, 1, "db3f196a370d5c602475c7305e452d5294ee9ee61ce485c5e9e53a8c32c88a18") -- The Sims 4 Bistro Kit 33 - Depot 2782870
addappid(2782871, 1, "a697cde409e2a07362f11c7ce7bf6a8c6f9050c7a159c06b7a2504752a255a30") -- The Sims 4 Bistro Kit 33 - Depot 2782871
addappid(2782873, 1, "c9bdb90fedb4691b3a5c88581d9ea096aa6349225da983dd2fc0a8dc7f3bcf43") -- The Sims 4 Bistro Kit 33 - Depot 2782873
addappid(2782874, 1, "cfbc0b65dc05b69d8ffe6fd0aae4161ead49cfde8ec79e246cb947206b6e1ad0") -- The Sims 4 Bistro Kit 33 - Depot 2782874
addappid(2782876, 1, "8304d24b684756bcfcb850547e3582933050ca3b42f26f70a9d75b32375c09b0") -- The Sims 4 Bistro Kit 33 - Depot 2782876
addappid(2782877, 1, "73401fbf2f968e06d6ca21c3e31399709a44ef5a03b528ba56f334f2546531a0") -- The Sims 4 Bistro Kit 33 - Depot 2782877
addappid(2782878, 1, "4baaeecb1515767b819bad3a94aa63a88465a1140ae0a939888b9d500ae77bd3") -- The Sims 4 Bistro Kit 33 - Depot 2782878
addappid(2982191, 1, "5d16390345c234f7d464488fb1b89aa53aafef85bfcebf9ba6c9761aa014529c") -- The Sims 4 Bistro Kit 33 - Depot 2982191
addappid(2982198, 1, "99cebc2526c15a3aaaa4a209e3349d2f47a00386ebac98800bcd44a58b1aaff2") -- The Sims 4 Bistro Kit 33 - Depot 2982198
-- addappid(2782872, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2782872 (no key available)
-- addappid(2782875, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2782875 (no key available)
-- addappid(2782879, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2782879 (no key available)
-- addappid(2982190, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982190 (no key available)
-- addappid(2982192, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982192 (no key available)
-- addappid(2982193, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982193 (no key available)
-- addappid(2982194, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982194 (no key available)
-- addappid(2982195, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982195 (no key available)
-- addappid(2982196, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982196 (no key available)
-- addappid(2982197, 1, "MISSING_KEY") -- The Sims 4 Bistro Kit 33 - Depot 2982197 (no key available)
-- The Sims 4 Lovestruck Expansion Pack (AppID: 2815270)
addappid(2815270)
addappid(2815270, 1, "dec415124770e020244e3b0d8c81e39002d8a96c6ef018f34c3ad426084f1182") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815270
addappid(2815271, 1, "4b91e10c583f71bff4658237d0f4cc4db71f7b508105606b80d506433b29c868") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815271
addappid(2815272, 1, "6d8a9a02e859f552ae64ca77d71ce12ef0f90aa616b7a65821c32305d6bae831") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815272
addappid(2815273, 1, "8366a31c97ffc3c860d289e0477ca399d2419f816b4d1abc42b9f9aee5ed86a9") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815273
addappid(2815274, 1, "1c61c07b60410ab0468d2ed801d4ee4c980322ae950e51cfd64c6e2f7f1703ea") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815274
addappid(2815276, 1, "099c760b178f75baa606d02a6c884616b410a3509e69db5f80f6e3c8d8ec35e6") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815276
addappid(2815277, 1, "771fbf7bfc3ac64615b2e6947328c98576e7e6fa24f1c6eeafc52a37bd08464a") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815277
addappid(2815278, 1, "8ce6c4b314f27ef0f868eae13e3e75abd89a45cd77d4dd161d45488820a3352f") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815278
addappid(2815279, 1, "cade4ab7368c98699c7c38b1d481e5e2f0b757ef9a022c5805c2d6e345900476") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815279
addappid(2880021, 1, "b09d66499400aa55d56fcc3e80857f8a78b85720fc07b3677292374bea869dd6") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880021
addappid(2880025, 1, "43c5b4cc45faf74d4baea310e5d6d1b7cbf763c312ae35d0d749560850d4ea8b") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880025
addappid(2880027, 1, "94851775e32f8bca00667e5df4bdc925bf8ef3895e028d06f766bf51c508d736") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880027
addappid(2880028, 1, "fba6e2a82de8d2fe668adb17cbb863ba4c32e23793f0154ab4e1f6e24987171c") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880028
-- addappid(2815275, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2815275 (no key available)
-- addappid(2880020, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880020 (no key available)
-- addappid(2880022, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880022 (no key available)
-- addappid(2880023, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880023 (no key available)
-- addappid(2880024, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880024 (no key available)
-- addappid(2880026, 1, "MISSING_KEY") -- The Sims 4 Lovestruck Expansion Pack - Depot 2880026 (no key available)
-- The Sims 4 Life  Death Expansion Pack (AppID: 2815290)
addappid(2815290)
addappid(2815290, 1, "2f4a48527c683662434a82e983a940f0ec5b86fca4fc693745ac8a03b5d4b6cb") -- The Sims 4 Life  Death Expansion Pack - Depot 2815290
addappid(2815291, 1, "cc1bb9046ec0c6620ed042a9bca4f123e1d4112739ef63f0078f2873d3cd56fd") -- The Sims 4 Life  Death Expansion Pack - Depot 2815291
addappid(2815292, 1, "2e1e66a55d08a9f90c8e3868341a9de4871db8d32c552eca63e7f687c1fed08d") -- The Sims 4 Life  Death Expansion Pack - Depot 2815292
addappid(2815293, 1, "4ecb48afeab9ae3deb9b928ee4ead5f641ba8a0059a5d160a5137e275c7c3056") -- The Sims 4 Life  Death Expansion Pack - Depot 2815293
addappid(2815294, 1, "b99b4658b2c9e459edfb7c4b96f2cde9f12d42de89af05398a9c1f0b1c68d806") -- The Sims 4 Life  Death Expansion Pack - Depot 2815294
addappid(2815297, 1, "6c4ab2a78baac554d707f33bd46f3c5a86edd9da064e680dbbda6b492b3975a7") -- The Sims 4 Life  Death Expansion Pack - Depot 2815297
addappid(2815298, 1, "ea9022bed7a97dcaeee189af9fc55715f988d8bd39f8c558c8599f0d60abc2cb") -- The Sims 4 Life  Death Expansion Pack - Depot 2815298
addappid(2815299, 1, "6ea085db3d1d08c3e7de64dc93e120709afcfa09ec6b5feb1857330b3b02ad9e") -- The Sims 4 Life  Death Expansion Pack - Depot 2815299
addappid(3052081, 1, "52275152d81670eacdc07994269d4691e36fc3ca43b09fdf7995f8473d355bbf") -- The Sims 4 Life  Death Expansion Pack - Depot 3052081
addappid(3052087, 1, "d876567b131b8de8d6de102d0ebd019493d4bcf4e43fe1c1f9cd3a14887ffd3f") -- The Sims 4 Life  Death Expansion Pack - Depot 3052087
addappid(3052088, 1, "a1199cab52304fe2e809472f9733f2b0f2b7d484e8be754b4ef252ac4970a4ab") -- The Sims 4 Life  Death Expansion Pack - Depot 3052088
-- addappid(2815295, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 2815295 (no key available)
-- addappid(2815296, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 2815296 (no key available)
-- addappid(3052082, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052082 (no key available)
-- addappid(3052083, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052083 (no key available)
-- addappid(3052084, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052084 (no key available)
-- addappid(3052085, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052085 (no key available)
-- addappid(3052086, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052086 (no key available)
-- addappid(3052080, 1, "MISSING_KEY") -- The Sims 4 Life  Death Expansion Pack - Depot 3052080 (no key available)
-- The Sims 4 Businesses  Hobbies Expansion Pack (AppID: 2815310)
addappid(2815310)
addappid(2815310, 1, "151dc71ffb125ef837c26533c0b7ba710dcdb34937a0a63338437152c199edb2") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815310
addappid(2815311, 1, "2dfb4e345a5cdbe824f6d6ea756437fd3c47353c9e63a165e791815146f25312") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815311
addappid(2815312, 1, "1f2d916450cefe8b187628b393ce2d8a6d5eb8d52381410cf5924ef6bf21f5c5") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815312
addappid(2815313, 1, "445c5bcf19185ec9a25ae0a1030693cde89bf89354089b0a1a6f9c40e4d4f9a7") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815313
addappid(2815316, 1, "576dc62a86e6c7c8c663bf1afefde738ab6628218f78bbb6c2596ec036d58470") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815316
addappid(2815317, 1, "6e295b75631169bc22a46bb59afa497a85c8b4b8d5fbfb3322d839fd58105b8b") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815317
addappid(2815319, 1, "cd38a8dc4495031b5f8437eaecd3842cdb513973009a31cb5edf3ab9c58a3674") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815319
addappid(3171041, 1, "441e8578e4b3591820187622e0f5db6248c4eba2840a865db042c231392ac99d") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171041
addappid(3171047, 1, "9ff08187595cc6d786178223e04b8868c793d4a8256e70477c9e37ae3a7f6f3c") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171047
addappid(3171048, 1, "d3f46aa4037b7640328c806d4b60d6b0ba4aef323f4c5929c8de0266845c995c") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171048
-- addappid(2815314, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815314 (no key available)
-- addappid(2815315, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815315 (no key available)
-- addappid(2815318, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 2815318 (no key available)
-- addappid(3171040, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171040 (no key available)
-- addappid(3171042, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171042 (no key available)
-- addappid(3171043, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171043 (no key available)
-- addappid(3171044, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171044 (no key available)
-- addappid(3171045, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171045 (no key available)
-- addappid(3171046, 1, "MISSING_KEY") -- The Sims 4 Businesses  Hobbies Expansion Pack - Depot 3171046 (no key available)
-- The Sims 4 Artist Studio Kit (AppID: 2815420)
addappid(2815420)
addappid(2815420, 1, "1ef5526bf3d00fe67183535ae0ad39b58fe4ff02b31db93d6cabcff87d82a72d") -- The Sims 4 Artist Studio Kit - Depot 2815420
addappid(2815421, 1, "a705a5be22ef4a60e561c71d9e470e3e891a68c2900cce922a3a0c1e2ef8267e") -- The Sims 4 Artist Studio Kit - Depot 2815421
addappid(2815423, 1, "55cdb103868f8ba31a40887aa02d13cda5a3410f2a8e5966363556549803545f") -- The Sims 4 Artist Studio Kit - Depot 2815423
addappid(2815426, 1, "a19f541d17d96d1ff924c7a1cf0847267b98bfa52898ad782d2a5df278de497d") -- The Sims 4 Artist Studio Kit - Depot 2815426
addappid(2815427, 1, "9344d342ee8bfd6d21bce9c84666bb3d9afe0d5a722f7b430befcc3b3c72253c") -- The Sims 4 Artist Studio Kit - Depot 2815427
addappid(2815428, 1, "c70bcf48a4b7e67c17ef9c8b60396b3f72eb4c24f2239a294dc5d94a0448f2d6") -- The Sims 4 Artist Studio Kit - Depot 2815428
addappid(3200901, 1, "e1492a40ebd19952921fdc4a3ffd2f87481a3dc67f5f6740da2b3a12fa5e661f") -- The Sims 4 Artist Studio Kit - Depot 3200901
addappid(3200908, 1, "1f224950ff4630cf991328c3b0efc87ffa0d80e5daabdc7ab94e21f9198d9a03") -- The Sims 4 Artist Studio Kit - Depot 3200908
-- addappid(2815422, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 2815422 (no key available)
-- addappid(2815424, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 2815424 (no key available)
-- addappid(2815425, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 2815425 (no key available)
-- addappid(2815429, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 2815429 (no key available)
-- addappid(3200900, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200900 (no key available)
-- addappid(3200902, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200902 (no key available)
-- addappid(3200903, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200903 (no key available)
-- addappid(3200904, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200904 (no key available)
-- addappid(3200905, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200905 (no key available)
-- addappid(3200906, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200906 (no key available)
-- addappid(3200907, 1, "MISSING_KEY") -- The Sims 4 Artist Studio Kit - Depot 3200907 (no key available)
-- The Sims 4 Storybook Nursery Kit (AppID: 2815430)
addappid(2815430)
addappid(2815430, 1, "435f3faf5b71aa3b53394d4aededcabe72c8aab985351f68d4b5331ad06ef7b5") -- The Sims 4 Storybook Nursery Kit - Depot 2815430
addappid(2815431, 1, "6f11c2cd35390bf19d51a1d0e5b8f5086903b464a3a04e9b897f889b0932762f") -- The Sims 4 Storybook Nursery Kit - Depot 2815431
addappid(2815433, 1, "b9a41002d60f649265cf344908a7b52f32f65ab5bb67874b52772f733a935004") -- The Sims 4 Storybook Nursery Kit - Depot 2815433
addappid(2815434, 1, "b0a0fcea85a19fab8a943af23b949bc7a7b808037d4bcc0ffd867f89131fd351") -- The Sims 4 Storybook Nursery Kit - Depot 2815434
addappid(2815436, 1, "38b27ad7b6e90c4548252ab0daffb1dbafdaf221f46ad7ee3feb0c9a2520fe1d") -- The Sims 4 Storybook Nursery Kit - Depot 2815436
addappid(2815437, 1, "616c7c7ae71e1f4ab19a1fead7415b9c5a55d5f3f24405343028b9fc669bcd22") -- The Sims 4 Storybook Nursery Kit - Depot 2815437
addappid(2815438, 1, "e3b5e18724cb03567b0c52cdf13db4bef96ac89e399ec8812021c7a29378096b") -- The Sims 4 Storybook Nursery Kit - Depot 2815438
addappid(3200921, 1, "33ed66efdc02adf65b3c372ad59dd63020175cc147272e09899931815cd0f9bc") -- The Sims 4 Storybook Nursery Kit - Depot 3200921
addappid(3200923, 1, "530428ae67f63846540518cc9d615cc382d6c59f3ea5478b752919b6ae30b641") -- The Sims 4 Storybook Nursery Kit - Depot 3200923
addappid(3200928, 1, "0a90a166ee744c2bd800eb7fe53715fb8b0f0e1075fd0bf25335cef6bb6fcc2e") -- The Sims 4 Storybook Nursery Kit - Depot 3200928
-- addappid(2815432, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 2815432 (no key available)
-- addappid(2815435, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 2815435 (no key available)
-- addappid(2815439, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 2815439 (no key available)
-- addappid(3200920, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200920 (no key available)
-- addappid(3200922, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200922 (no key available)
-- addappid(3200924, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200924 (no key available)
-- addappid(3200925, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200925 (no key available)
-- addappid(3200926, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200926 (no key available)
-- addappid(3200927, 1, "MISSING_KEY") -- The Sims 4 Storybook Nursery Kit - Depot 3200927 (no key available)
-- The Sims 4 Comfy Gamer Kit (AppID: 2815440)
addappid(2815440)
addappid(2815440, 1, "8ae86abb16e4308b7af4e03faa5e3fcfb436e20e22030bdfe6ff9d3759b736f4") -- The Sims 4 Comfy Gamer Kit - Depot 2815440
addappid(2815441, 1, "605ac27227317d68a3425bf7cd7ac39d085f6577d6751db20654b11247ba6b30") -- The Sims 4 Comfy Gamer Kit - Depot 2815441
addappid(2815442, 1, "b9789e909412b50a662c6986d634e6137068876dbbc99259b005bbd2a9b3a65f") -- The Sims 4 Comfy Gamer Kit - Depot 2815442
addappid(2815443, 1, "1614a8d7d1e3565aa3f25bf55f982078acae0eb79cad4720194ad5c5d007b2f0") -- The Sims 4 Comfy Gamer Kit - Depot 2815443
addappid(2815444, 1, "7abc44e5495152b68cd4d298beb70f19c3eff99646dbc522a1445d5c656c35ac") -- The Sims 4 Comfy Gamer Kit - Depot 2815444
addappid(2815446, 1, "c08415c7f0f113525f4dd0e7008f40ac9182b00a4bf1d1c5ca4dc4c2a14548bd") -- The Sims 4 Comfy Gamer Kit - Depot 2815446
addappid(2815447, 1, "d29a818bc33ff4323bc7c4cf91d7a4c0deb6ecc04ee54011983b75dde2563aba") -- The Sims 4 Comfy Gamer Kit - Depot 2815447
addappid(2815448, 1, "44dacdb6832621698b1d44641f4d4def1a2d5454c7e3e7e0e0564f06cbb862be") -- The Sims 4 Comfy Gamer Kit - Depot 2815448
addappid(2815449, 1, "311945465c52fa21ce76b616e443cfe941bfc44203d77b8d15e3300b51c52ae0") -- The Sims 4 Comfy Gamer Kit - Depot 2815449
addappid(3401191, 1, "32b187fd6ebfa1f81d81ec0febdbd7e02885ade83f9172a607a62c9c47c95d4e") -- The Sims 4 Comfy Gamer Kit - Depot 3401191
addappid(3401197, 1, "63a3e7c765171299288a3e9055ef4303068a97ca397cbe1057de96f380a3441d") -- The Sims 4 Comfy Gamer Kit - Depot 3401197
addappid(3401198, 1, "5579bdb48e235bc9013fc0bf70fa0228ca8ace319049f762404898a7f4a9c3e6") -- The Sims 4 Comfy Gamer Kit - Depot 3401198
-- addappid(2815445, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 2815445 (no key available)
-- addappid(3401190, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401190 (no key available)
-- addappid(3401192, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401192 (no key available)
-- addappid(3401193, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401193 (no key available)
-- addappid(3401194, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401194 (no key available)
-- addappid(3401195, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401195 (no key available)
-- addappid(3401196, 1, "MISSING_KEY") -- The Sims 4 Comfy Gamer Kit - Depot 3401196 (no key available)
-- The Sims 4 Secret Sanctuary Kit (AppID: 2815450)
addappid(2815450)
addappid(2815450, 1, "1a36fcc943a5f56ebf877bf0f2d60efe619b8478e88f9720d661b3455c16fadf") -- The Sims 4 Secret Sanctuary Kit - Depot 2815450
addappid(2815451, 1, "b74461932eaf4a25b28901d93fa13e75b38418b6ee4a741d5f8434ecf6e538e6") -- The Sims 4 Secret Sanctuary Kit - Depot 2815451
addappid(2815453, 1, "52f5cb73f4a44736e5070cdba074c2e98a8596aee78ac9acd8c601348ddd4064") -- The Sims 4 Secret Sanctuary Kit - Depot 2815453
addappid(2815454, 1, "9ef883c3e1e03939b7ee18da3a746d26acb9405da306cd4cace810201ac9de4f") -- The Sims 4 Secret Sanctuary Kit - Depot 2815454
addappid(2815457, 1, "1d2843e5193e56066079f9f6f47e842deb7fc8d64630ae6b706d0a17c6c0820f") -- The Sims 4 Secret Sanctuary Kit - Depot 2815457
addappid(2815458, 1, "4ab051d7451846d45510a8ede1b8987a61f2c7f9397e3b4e418ac73f502d4046") -- The Sims 4 Secret Sanctuary Kit - Depot 2815458
addappid(3401211, 1, "350af870b4aa3fe2b4112f29b73c7fe480c2cef0d8f654959d6b923c34722a68") -- The Sims 4 Secret Sanctuary Kit - Depot 3401211
addappid(3401218, 1, "8c09bc370daa161586d6707eb1cb9c78369fd7032c4b6ba23fcc08e3b56353f1") -- The Sims 4 Secret Sanctuary Kit - Depot 3401218
-- addappid(2815452, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 2815452 (no key available)
-- addappid(2815455, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 2815455 (no key available)
-- addappid(2815456, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 2815456 (no key available)
-- addappid(2815459, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 2815459 (no key available)
-- addappid(3401210, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401210 (no key available)
-- addappid(3401212, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401212 (no key available)
-- addappid(3401213, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401213 (no key available)
-- addappid(3401214, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401214 (no key available)
-- addappid(3401215, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401215 (no key available)
-- addappid(3401216, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401216 (no key available)
-- addappid(3401217, 1, "MISSING_KEY") -- The Sims 4 Secret Sanctuary Kit - Depot 3401217 (no key available)
-- The Sims 4 Casanova Cave Kit (AppID: 3197120)
addappid(3197120)
addappid(3197120, 1, "7e68e02132c3b7068d863870fde6ad141d793a141b24c09d0132a51ff35e5e21") -- The Sims 4 Casanova Cave Kit - Depot 3197120
addappid(3197121, 1, "8696f71702c515e54682523d9f0d696c28ae8bb0d97526971b4fc557b2651c9d") -- The Sims 4 Casanova Cave Kit - Depot 3197121
addappid(3197122, 1, "21f85345484cbeeb663104598d2dc8d629d01e2ed15ea14240631765ad4d4c79") -- The Sims 4 Casanova Cave Kit - Depot 3197122
addappid(3197123, 1, "d9cd9649f2e736edd15a17e6cd866c23ef74ef245be434f11f6803fd1aaeae6f") -- The Sims 4 Casanova Cave Kit - Depot 3197123
addappid(3197124, 1, "99a930c0054b7f9ae89f6e0e1b5d0dbc58781cacc3c43d49c181b91c9fa7e15d") -- The Sims 4 Casanova Cave Kit - Depot 3197124
addappid(3197127, 1, "1a4671fcf873e2b67c0cf527b92b7ee36e159e5f0f817ae7528b8966ff44268b") -- The Sims 4 Casanova Cave Kit - Depot 3197127
addappid(3197128, 1, "9846b3e39fa74e4dedd7d53a482175215318bf58a9253c09d4a74a6ff2968c81") -- The Sims 4 Casanova Cave Kit - Depot 3197128
addappid(3401231, 1, "d3ae9b001e3e4cff7143502abe7bcf618a8f9b2f649397854ecec69ae643dd4a") -- The Sims 4 Casanova Cave Kit - Depot 3401231
addappid(3401237, 1, "c8e79dfbb9515fd479caa7e67be8f89797c1b197fdc0dbef93f47522309b1732") -- The Sims 4 Casanova Cave Kit - Depot 3401237
addappid(3401238, 1, "af3506d1e5bf05170d522a005fcf481b48cfd5852649ef0bfc504608332db655") -- The Sims 4 Casanova Cave Kit - Depot 3401238
-- addappid(3197125, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3197125 (no key available)
-- addappid(3197126, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3197126 (no key available)
-- addappid(3197129, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3197129 (no key available)
-- addappid(3401230, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401230 (no key available)
-- addappid(3401232, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401232 (no key available)
-- addappid(3401233, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401233 (no key available)
-- addappid(3401234, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401234 (no key available)
-- addappid(3401235, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401235 (no key available)
-- addappid(3401236, 1, "MISSING_KEY") -- The Sims 4 Casanova Cave Kit - Depot 3401236 (no key available)
-- The Sims 4 Sweet Slumber Party Kit (AppID: 3197130)
addappid(3197130)
addappid(3197130, 1, "ca31a8974172a3bb0fc3afa5c3a86aa8188925f5685ce682935ee7d488031fd0") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197130
addappid(3197131, 1, "74c2305a9421a0e6f1c044f58f26256c28b3bdd5bfdaa6dfb0afddbe4fa32e36") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197131
addappid(3197133, 1, "076bc9ccb65b4c815d037c7b54b942bfea13eda89f0d016816a71082c9d49b0b") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197133
addappid(3197134, 1, "f44f5f0b82e1282082a645bfb012892ebb41e60d97a36d83cfb167499e29de5d") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197134
addappid(3197137, 1, "6903eb855bb708332c6f6702a559e028a8c78332ee3fdf0a9f0a8c63cd19aab8") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197137
addappid(3197138, 1, "2fb5e6f5f93555057b56eb889b67726ee05d84f112376e293cbca182cee28a45") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197138
addappid(3275141, 1, "0f367c6db388773e09615fbb7a9267011b45d75f236cb4828e29284b8bc27069") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275141
addappid(3275148, 1, "a5bd7a5767254c3935e8b7420653680576bb9a210c351c575bdd41b3817a0482") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275148
-- addappid(3197132, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197132 (no key available)
-- addappid(3197135, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197135 (no key available)
-- addappid(3197136, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197136 (no key available)
-- addappid(3197139, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3197139 (no key available)
-- addappid(3275140, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275140 (no key available)
-- addappid(3275142, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275142 (no key available)
-- addappid(3275143, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275143 (no key available)
-- addappid(3275144, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275144 (no key available)
-- addappid(3275145, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275145 (no key available)
-- addappid(3275146, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275146 (no key available)
-- addappid(3275147, 1, "MISSING_KEY") -- The Sims 4 Sweet Slumber Party Kit - Depot 3275147 (no key available)
-- The Sims 4 Cozy Kitsch Kit (AppID: 3197140)
addappid(3197140)
addappid(3197140, 1, "7744d13cba3ac994e8e3fef5b159b17aea1c93e729b190fb7171a6ae7ae752ee") -- The Sims 4 Cozy Kitsch Kit - Depot 3197140
addappid(3197141, 1, "33ef339e07b5d80a42af0248bfdd40488d9c9782d4deed2f0c4669bdeaa0a8c9") -- The Sims 4 Cozy Kitsch Kit - Depot 3197141
addappid(3197143, 1, "f571a5b17007dfae033cd62b82c8b0dc835bc6ba7f1d5e06cbb556d67f2e6ded") -- The Sims 4 Cozy Kitsch Kit - Depot 3197143
addappid(3197147, 1, "b230175b4bf87879e65ab182f31b77ad1f1c13c679f3b3b4338668a4b891809f") -- The Sims 4 Cozy Kitsch Kit - Depot 3197147
addappid(3197148, 1, "11ae54b92b4d9da7eeeaa178276b852900cbb6f6a7d3c50d2404b897047d413f") -- The Sims 4 Cozy Kitsch Kit - Depot 3197148
addappid(3275161, 1, "770c23fc0ec31ab8c89b1331e9f62fb7103df784ba0b8f331b34e52f2cec0098") -- The Sims 4 Cozy Kitsch Kit - Depot 3275161
addappid(3275168, 1, "e0563289cc54b7db7b1e9be4b2aa5f9fa5afb187bfdd44d0d50dcd3f1749c86a") -- The Sims 4 Cozy Kitsch Kit - Depot 3275168
-- addappid(3197142, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3197142 (no key available)
-- addappid(3197144, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3197144 (no key available)
-- addappid(3197145, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3197145 (no key available)
-- addappid(3197146, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3197146 (no key available)
-- addappid(3197149, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3197149 (no key available)
-- addappid(3275160, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275160 (no key available)
-- addappid(3275162, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275162 (no key available)
-- addappid(3275163, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275163 (no key available)
-- addappid(3275164, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275164 (no key available)
-- addappid(3275165, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275165 (no key available)
-- addappid(3275166, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275166 (no key available)
-- addappid(3275167, 1, "MISSING_KEY") -- The Sims 4 Cozy Kitsch Kit - Depot 3275167 (no key available)
-- The Sims 4 Enchanted by Nature Expansion Pack (AppID: 3199780)
addappid(3199780)
addappid(3199780, 1, "19bb76b39fe66921f1d2f79df8e10c921f8e2076dd202f613a2d13dcffe89451") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199780
addappid(3199781, 1, "45f72b0457d34c219a7f20692bad14e6ccf06b54b56165f71b4f2d42a1cae46c") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199781
addappid(3199782, 1, "508159f88f6c002fe27f84aee2fbeafd440222cdbcdad17e01f56f3046d3e588") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199782
addappid(3199783, 1, "ea0dec3180a9961b7f81c6207a5fa337746dc6faead1558783bc0bd712a5d241") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199783
addappid(3199784, 1, "d796205439ebef1c85a03c7a57acd3d65f23e885e352cb9d377e7ab6b1f4714d") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199784
addappid(3199786, 1, "bc321d12ae3909a1c573f4e8bf5df633d89a1904952788601c593ed07bca6d6b") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199786
addappid(3199787, 1, "d1b61de94204bd0a3351d13427e7c3f4e17384edb0b4fd75f52ccd770fa25f22") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199787
addappid(3199788, 1, "ff20035c040e3f4ce85e6ddb84d84610e0beb2ba4df10bd3435b45e7a0e2e033") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199788
addappid(3199789, 1, "e9c37f2d3681b5a85e7576913cd72d6c20adf954f566ebc7a6eb7198ae65860c") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199789
addappid(3500101, 1, "c55723203c0b709c8771f460a52f744ec6066a8f03c4882a7bc70f4427489f16") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500101
addappid(3500103, 1, "9f72f1226b7e95e1010d0b997ff9d178bf047590f3df4ccaf91cf74fbe19a9e8") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500103
addappid(3500108, 1, "c4040b9824cd0e42025a75a0df4fa5405ce94ad44b37d22acba02d69e3585e8c") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500108
-- addappid(3199785, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3199785 (no key available)
-- addappid(3500100, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500100 (no key available)
-- addappid(3500102, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500102 (no key available)
-- addappid(3500104, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500104 (no key available)
-- addappid(3500105, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500105 (no key available)
-- addappid(3500106, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500106 (no key available)
-- addappid(3500107, 1, "MISSING_KEY") -- The Sims 4 Enchanted by Nature Expansion Pack - Depot 3500107 (no key available)
-- The Sims 4 Refined Living Room Kit (AppID: 3199810)
addappid(3199810)
addappid(3199810, 1, "f00d8e534f66e8716c81a9fa81086ae6be6d0d73311e40cb67e4316335ddb232") -- The Sims 4 Refined Living Room Kit - Depot 3199810
addappid(3199811, 1, "a68833066eff5fc17eab681b1f24fc9a25c7f412f3e63ba5b321259b8fa9331f") -- The Sims 4 Refined Living Room Kit - Depot 3199811
addappid(3199812, 1, "131405301fb226299631cf28436fb6186ec79f80564b448a4f109a14835dc1e8") -- The Sims 4 Refined Living Room Kit - Depot 3199812
addappid(3199813, 1, "084b75d4f4d87924b198f82efdb035fbfce125c28ab07f6170f34882c88abfbc") -- The Sims 4 Refined Living Room Kit - Depot 3199813
addappid(3199814, 1, "e3ea362cf0ea082fea822b4664bbe791579ff3c1a804173459dbb54d2da08f30") -- The Sims 4 Refined Living Room Kit - Depot 3199814
addappid(3199816, 1, "2bbe312bc9a6466cd1c5cec9b0c8f5c6c020bf38e65694f7b6464d5f58f50b01") -- The Sims 4 Refined Living Room Kit - Depot 3199816
addappid(3199817, 1, "1eb017f85784535617d20570cf0ab6dafefa9042935f126b760956276e4b6fdb") -- The Sims 4 Refined Living Room Kit - Depot 3199817
addappid(3199819, 1, "e9987b618860822f028ab3be3a7da8ad430ac5c892457d730fea865007162421") -- The Sims 4 Refined Living Room Kit - Depot 3199819
addappid(3401311, 1, "e03645337ccc37cad5fa1daca6a5c7551196f755e1d179964088d92df15adee8") -- The Sims 4 Refined Living Room Kit - Depot 3401311
addappid(3401318, 1, "5ab6ebbf330714c4fbff51f5d2d41d9f6f27d9f8cb0a5351d7a97fcc952b92cb") -- The Sims 4 Refined Living Room Kit - Depot 3401318
-- addappid(3199815, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3199815 (no key available)
-- addappid(3199818, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3199818 (no key available)
-- addappid(3401310, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401310 (no key available)
-- addappid(3401312, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401312 (no key available)
-- addappid(3401313, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401313 (no key available)
-- addappid(3401314, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401314 (no key available)
-- addappid(3401315, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401315 (no key available)
-- addappid(3401316, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401316 (no key available)
-- addappid(3401317, 1, "MISSING_KEY") -- The Sims 4 Refined Living Room Kit - Depot 3401317 (no key available)
-- The Sims 4 Business Chic Kit (AppID: 3199820)
addappid(3199820)
addappid(3199820, 1, "b424377636a79b33c87fa9e056c7d84ed224bab2fd585d2b41054949e7712f10") -- The Sims 4 Business Chic Kit - Depot 3199820
addappid(3199821, 1, "2d27882fee7f3c1e80a815be4a36decbc093e677e29f654270832a859d91d47c") -- The Sims 4 Business Chic Kit - Depot 3199821
addappid(3199823, 1, "87b1a9fdbf949e15030166cb6f71bcbffbe4d2a602f28cb5bb007426bcecff4e") -- The Sims 4 Business Chic Kit - Depot 3199823
addappid(3199826, 1, "e5faa0572774d18d7c21a45dd3caebc03d0509308d768ee6a829a5a323090b62") -- The Sims 4 Business Chic Kit - Depot 3199826
addappid(3199827, 1, "7672dfd0b0c615f623f12eef064b3e949ba536b9fb34e44a8b9c9a79607f8b48") -- The Sims 4 Business Chic Kit - Depot 3199827
addappid(3401331, 1, "71fd329d160d6edc9254dcc880a44087e2eedb5630ae8583fb4c05f098eb91a7") -- The Sims 4 Business Chic Kit - Depot 3401331
addappid(3401333, 1, "7e4fa0bee446e1c6860b56613829942b90258e3a69b428d4b3297d72aeb264ae") -- The Sims 4 Business Chic Kit - Depot 3401333
addappid(3401338, 1, "486ca2629496b9be6b1bd77246df9fe5501caf5da1d356112b109b762a9a5160") -- The Sims 4 Business Chic Kit - Depot 3401338
-- addappid(3199822, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3199822 (no key available)
-- addappid(3199824, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3199824 (no key available)
-- addappid(3199825, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3199825 (no key available)
-- addappid(3199828, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3199828 (no key available)
-- addappid(3199829, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3199829 (no key available)
-- addappid(3401330, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401330 (no key available)
-- addappid(3401332, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401332 (no key available)
-- addappid(3401334, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401334 (no key available)
-- addappid(3401335, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401335 (no key available)
-- addappid(3401336, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401336 (no key available)
-- addappid(3401337, 1, "MISSING_KEY") -- The Sims 4 Business Chic Kit - Depot 3401337 (no key available)
-- The Sims 4 Restoration Workshop Kit (AppID: 3199990)
addappid(3199990)
addappid(3199990, 1, "5d8a6186717dfee869c0378426af36d452bf35d0b20eb7715052e5dd406dcd35") -- The Sims 4 Restoration Workshop Kit - Depot 3199990
addappid(3199991, 1, "42a88748211bbbc267f602991553a04d7adb487258c56205fd001c04f43d2cfd") -- The Sims 4 Restoration Workshop Kit - Depot 3199991
addappid(3199993, 1, "429cd7323736542ede214a01e21bef0ebafb63b280cf449127b5b2c3c48bebbb") -- The Sims 4 Restoration Workshop Kit - Depot 3199993
addappid(3199997, 1, "8901e076b8d320b8c1deb1e1b6133ba92da3ad51e0efdfe8b3c59a10f1678377") -- The Sims 4 Restoration Workshop Kit - Depot 3199997
addappid(3401251, 1, "89ecf27948bf93e6157c4ea1aeb8657a21f4b35f58f48042d200b10ab6555f1e") -- The Sims 4 Restoration Workshop Kit - Depot 3401251
addappid(3401258, 1, "d51bfab46dfb7b2450f8adcc79d7f6539de7d4b0bbd9694636dd28f45440cbc8") -- The Sims 4 Restoration Workshop Kit - Depot 3401258
-- addappid(3199992, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199992 (no key available)
-- addappid(3199994, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199994 (no key available)
-- addappid(3199995, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199995 (no key available)
-- addappid(3199996, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199996 (no key available)
-- addappid(3199998, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199998 (no key available)
-- addappid(3199999, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3199999 (no key available)
-- addappid(3401250, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401250 (no key available)
-- addappid(3401252, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401252 (no key available)
-- addappid(3401253, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401253 (no key available)
-- addappid(3401254, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401254 (no key available)
-- addappid(3401255, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401255 (no key available)
-- addappid(3401256, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401256 (no key available)
-- addappid(3401257, 1, "MISSING_KEY") -- The Sims 4 Restoration Workshop Kit - Depot 3401257 (no key available)
-- The Sims 4 Golden Years Kit (AppID: 3200000)
addappid(3200000)
addappid(3200000, 1, "c0772ca5be5e50710fd54ca3eae378efc170d8985b514a142b64a58a714e7c39") -- The Sims 4 Golden Years Kit - Depot 3200000
addappid(3200001, 1, "be0502dd68e5cdb78d9aee54358635383a5f6d2ccaea0b67ff359af9a8b32ac8") -- The Sims 4 Golden Years Kit - Depot 3200001
addappid(3200003, 1, "a0210d23962d2034df5b419ad64c51f6381e2d8aa37ad802d1bfa3a5809b3246") -- The Sims 4 Golden Years Kit - Depot 3200003
addappid(3200006, 1, "2b9df1d938c34cc2288397034ec347ab0f17fa08f476565615b521e6a9fbe595") -- The Sims 4 Golden Years Kit - Depot 3200006
addappid(3200007, 1, "acfa93b4a844320686736ddbb56d3710eb20689ab1e616afc63ccb7e7b1924bd") -- The Sims 4 Golden Years Kit - Depot 3200007
addappid(3401271, 1, "b0f06f9e795484ea6199f0e1054316bf05e421bfd7314ced419e4661e8f54eea") -- The Sims 4 Golden Years Kit - Depot 3401271
addappid(3401278, 1, "5ebb12416dc076f8e54f7606b909ee528597d772b1cd740e36fda1cd94022be9") -- The Sims 4 Golden Years Kit - Depot 3401278
-- addappid(3200002, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3200002 (no key available)
-- addappid(3200004, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3200004 (no key available)
-- addappid(3200005, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3200005 (no key available)
-- addappid(3200008, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3200008 (no key available)
-- addappid(3200009, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3200009 (no key available)
-- addappid(3401270, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401270 (no key available)
-- addappid(3401272, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401272 (no key available)
-- addappid(3401273, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401273 (no key available)
-- addappid(3401274, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401274 (no key available)
-- addappid(3401275, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401275 (no key available)
-- addappid(3401276, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401276 (no key available)
-- addappid(3401277, 1, "MISSING_KEY") -- The Sims 4 Golden Years Kit - Depot 3401277 (no key available)
-- The Sims 4 Kitchen Clutter Kit (AppID: 3200010)
addappid(3200010)
addappid(3200010, 1, "841b82fb63ef6bb7e559aa0297c43e3ec49fbb30b2285abc9bf5aa0924816cb0") -- The Sims 4 Kitchen Clutter Kit - Depot 3200010
addappid(3200011, 1, "ab5036a95087c45635b21a0a1b79e5929f157bddbf9b902088a74e94ebcf610e") -- The Sims 4 Kitchen Clutter Kit - Depot 3200011
addappid(3200012, 1, "f87fa34586d42e5a22d86f810f4fccc7b9c1d91d4e4b24bb30affcde95a82bc9") -- The Sims 4 Kitchen Clutter Kit - Depot 3200012
addappid(3200013, 1, "434e60df17e225d82abdf1ae1ef63807ba8f784dbde1de8d74b0901e0de641a4") -- The Sims 4 Kitchen Clutter Kit - Depot 3200013
addappid(3200014, 1, "ed29eee9882ce7259f18129b0940957d2e61820dac7405bee14b8bd97d7324dc") -- The Sims 4 Kitchen Clutter Kit - Depot 3200014
addappid(3200016, 1, "12f08bbbdf0a3e797cdd5731b673c55687f15e9f759c39ed57e2c19ae6a78f4a") -- The Sims 4 Kitchen Clutter Kit - Depot 3200016
addappid(3200017, 1, "c4f3b6c89af63f77319fa015803111ec057363be01005c8845afe424944157f5") -- The Sims 4 Kitchen Clutter Kit - Depot 3200017
addappid(3200018, 1, "23b1043c426fcef8718b718aa217eed83ab71e67ec8cbaa828bc2f278d8edb4e") -- The Sims 4 Kitchen Clutter Kit - Depot 3200018
addappid(3401291, 1, "f9560d58f763e869570a734795ba184ea5ba77302c2170ec436972fc4c176ac7") -- The Sims 4 Kitchen Clutter Kit - Depot 3401291
addappid(3401298, 1, "19f5e6066f8995ed5851dc637c800d35c5b5e307c52e7002ffe57de8e209ba76") -- The Sims 4 Kitchen Clutter Kit - Depot 3401298
-- addappid(3200015, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3200015 (no key available)
-- addappid(3200019, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3200019 (no key available)
-- addappid(3401290, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401290 (no key available)
-- addappid(3401292, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401292 (no key available)
-- addappid(3401293, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401293 (no key available)
-- addappid(3401294, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401294 (no key available)
-- addappid(3401295, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401295 (no key available)
-- addappid(3401296, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401296 (no key available)
-- addappid(3401297, 1, "MISSING_KEY") -- The Sims 4 Kitchen Clutter Kit - Depot 3401297 (no key available)
-- The Sims 4 Sleek Bathroom Kit (AppID: 3415980)
addappid(3415980)
addappid(3415980, 1, "d3f500ec6ad890480d9b82ae3253b7d46d185e7ccbc474046ac44121c0eb3b82") -- The Sims 4 Sleek Bathroom Kit - Depot 3415980
addappid(3415981, 1, "6d8098cc0bec138d4d6699c9c7b4ab82e111dec094e7103ebed710a49e867d23") -- The Sims 4 Sleek Bathroom Kit - Depot 3415981
addappid(3415982, 1, "a5c450e99c03788d682ddf0cd775f64d406d293d2ca5f4b174c76b076656a6c1") -- The Sims 4 Sleek Bathroom Kit - Depot 3415982
addappid(3415983, 1, "a9abad337764601ef10925f66902203eb9137038c3e2be6b6b90fcbf666573a2") -- The Sims 4 Sleek Bathroom Kit - Depot 3415983
addappid(3415984, 1, "2951733c6ff5571b22160c39f8a450b3242b0c87f957591a06e7b83aa7f4f7c6") -- The Sims 4 Sleek Bathroom Kit - Depot 3415984
addappid(3415986, 1, "767b704d3b80a9cd7631842c5e9dc7f01c03ecd91a82a8b632eeac8d1007a824") -- The Sims 4 Sleek Bathroom Kit - Depot 3415986
addappid(3415987, 1, "8fecd00d420993444936d3cafb7c32795ce4011ebecd5ab0320d00b56d507ef1") -- The Sims 4 Sleek Bathroom Kit - Depot 3415987
addappid(3415988, 1, "bd551c7000d436374c94efe477ff99991a067ee3111a2e01de4afdfd026ba6f9") -- The Sims 4 Sleek Bathroom Kit - Depot 3415988
addappid(3415989, 1, "1f567528c5b24ab8d7400cf22e185488c0248dc10e0517229a234b15e425d088") -- The Sims 4 Sleek Bathroom Kit - Depot 3415989
addappid(3500121, 1, "c22a1851e97d8696d11157c562d95820181f21308e9a09dd3ad1b2fb5e1c5d1c") -- The Sims 4 Sleek Bathroom Kit - Depot 3500121
addappid(3500126, 1, "c37b94abb4e0a926952169822c58697c5e3465aa3d08818c14f072d9b66aab55") -- The Sims 4 Sleek Bathroom Kit - Depot 3500126
addappid(3500127, 1, "214dbd35460286f2bf95d63c9526290c0329fac953e7608c633bea68b9018063") -- The Sims 4 Sleek Bathroom Kit - Depot 3500127
addappid(3500128, 1, "b3c2b7acf540105599e2f704f32665957fd963c30be03a88827988c4aa50f644") -- The Sims 4 Sleek Bathroom Kit - Depot 3500128
-- addappid(3415985, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3415985 (no key available)
-- addappid(3500120, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3500120 (no key available)
-- addappid(3500122, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3500122 (no key available)
-- addappid(3500123, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3500123 (no key available)
-- addappid(3500124, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3500124 (no key available)
-- addappid(3500125, 1, "MISSING_KEY") -- The Sims 4 Sleek Bathroom Kit - Depot 3500125 (no key available)
-- The Sims 4 Sweet Allure Kit (AppID: 3415990)
addappid(3415990)
addappid(3415990, 1, "9213916e6832f6daf65db5e4edf99ca5d3c0aea6f0de35f6c59a25a56cd69d17") -- The Sims 4 Sweet Allure Kit - Depot 3415990
addappid(3415991, 1, "62b9af30db973b20b8b076f88da3cf1f0710016aca5f7be83b368e841edf332a") -- The Sims 4 Sweet Allure Kit - Depot 3415991
addappid(3415992, 1, "070cddec35683de9a5a65bfa834778fa7d8887c46e213ce1eb3478e731eb6f16") -- The Sims 4 Sweet Allure Kit - Depot 3415992
addappid(3415993, 1, "073cb14cb71d0844d9844018d258792c064c786d1231b2ab9da5f63b35663977") -- The Sims 4 Sweet Allure Kit - Depot 3415993
addappid(3415994, 1, "9879aa6bd1e31bb1b25ad29ae38cbbb9675075299f7c4fb00d3ac17a23f0ac80") -- The Sims 4 Sweet Allure Kit - Depot 3415994
addappid(3415996, 1, "93b8db100aad4d485915eb04e9ee2b7dd1b95d32c1ffbcfc2c116600a8cd3624") -- The Sims 4 Sweet Allure Kit - Depot 3415996
addappid(3415997, 1, "c0a79b05544f3b7b2dbcb6bd7eff96a0ef85c0d9d9461b64e4aa859badfe603d") -- The Sims 4 Sweet Allure Kit - Depot 3415997
addappid(3415998, 1, "87a2d5893553a8e0b91bbd11deaa7afa9735966b9e689e881d36ef0210b4a7e4") -- The Sims 4 Sweet Allure Kit - Depot 3415998
addappid(3500141, 1, "a902c90e4866806749fa4a0464d4a16d9ff0a992213156a1837bb8f5c533cbfa") -- The Sims 4 Sweet Allure Kit - Depot 3500141
addappid(3500148, 1, "254dc343ed5ec38e81fa9ac8f0a81fd494189a6b79229a5cfbe91116b79ccf86") -- The Sims 4 Sweet Allure Kit - Depot 3500148
-- addappid(3415995, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3415995 (no key available)
-- addappid(3415999, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3415999 (no key available)
-- addappid(3500140, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500140 (no key available)
-- addappid(3500142, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500142 (no key available)
-- addappid(3500143, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500143 (no key available)
-- addappid(3500144, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500144 (no key available)
-- addappid(3500145, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500145 (no key available)
-- addappid(3500146, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500146 (no key available)
-- addappid(3500147, 1, "MISSING_KEY") -- The Sims 4 Sweet Allure Kit - Depot 3500147 (no key available)
-- The Sims 4 Royalty  Legacy Expansion Pack (AppID: 3548690)
addappid(3548690)
addappid(3548690, 1, "02843214db8730444f1ae4955b69fe64f97e09234a83588ce7e04b2a53857867") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548690
addappid(3548691, 1, "43c48c9860dc8f54b9317a012f95cb9decee64c8159bf32b101a1c277053a256") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548691
addappid(3548692, 1, "a7085620fab7141e96b6974397019bd48dbeb3fd0ace4eae7f20160c6a98c5a3") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548692
addappid(3548693, 1, "ee66f19436bfbe0034a93c1d6b645530f4553af4e9684bf8e590890fd41a51f3") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548693
addappid(3548694, 1, "76e614e33e868485892250adc18a26b605a8bab22f021568fc02525768bccd46") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548694
addappid(3548695, 1, "d0915274f417e547dffb249e8949b572495f15b772e214dd10bb2a97a0131ff2") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548695
addappid(3548696, 1, "97b571885e3a5793a89b06d50a22be573f6139e16a3e75da4935878cdfb9ee1d") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548696
addappid(3548697, 1, "88d5357ea4a4bb6e49b1d4c78edf11dd863b6168c7063223b181f84d252f04c4") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548697
addappid(3548698, 1, "2856257bcb489ef0309770b0b48292ed8dabdb50eb41dce54e7bb2a34ba7fc6f") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548698
addappid(3548699, 1, "8a535a38331e94ee69b658ff8a0911c546a1ff742d90c5d212afec018baa4765") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3548699
addappid(3719730, 1, "f7148a7e64a87c03d93bb66d9778ebcf237d9975667717c646dcc8f4b333c3b1") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719730
addappid(3719731, 1, "0f044f104df15ec6e08a270e8f3578bbb3dbaa32b3c88d0621e15f91ac3ddbe2") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719731
addappid(3719732, 1, "b742c62066fecbffc8c5a07edeb3560f76ec16d6a19f84b16b0bfe82b767c18d") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719732
addappid(3719733, 1, "d5545b313e22829d4b5fc2eacf54d3b434d428c8b23f8f7747cb4648c48a43e9") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719733
addappid(3719734, 1, "789e3909c03c0d646ee3c6f09e425ed8dcf5f0a1328a994646ef973a103539a8") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719734
addappid(3719735, 1, "0fcd10a1e89bff7d7300284a734b445ad9be157dbddf65c86631fbfc74519f4d") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719735
addappid(3719736, 1, "387e37772c911a44ff98b1706ee8e12b56e7dd43f269e2a57438115a91afe91a") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719736
addappid(3719737, 1, "2a8d7c1815cd52cb2f22e877f7dd5807360f3a8dad473062a355b4b27d948ca7") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719737
addappid(3719738, 1, "37651427f0b03b9fe893e7dde8cefdc3af90663bd14e3334299b4dbf9108efec") -- The Sims 4 Royalty  Legacy Expansion Pack - Depot 3719738
-- The Sims 4 Adventure Awaits Expansion Pack (AppID: 3548850)
addappid(3548850)
addappid(3548850, 1, "5df5284298b6d3c1065cd3f76e47d7187f60eaabe6a5e3685715a0464c50324c") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548850
addappid(3548851, 1, "3d481afb9278d25d525b5b8f8fce3b7d8db2a354bb5dfd2787d925fb2748014a") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548851
addappid(3548853, 1, "a17b4ab19c7947499c793714efff263663d19979c98f5c5ab5aac7a1709eda0d") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548853
addappid(3548854, 1, "501395ce4644192d91aa02f316f742aecc5d9d6014145e0b31badfcf08b29d99") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548854
addappid(3548856, 1, "9e43f32da3622ad4ac280bd46733fd9cb720741f8aea9acc1407c27d8d4f4e17") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548856
addappid(3548857, 1, "cad39c5dededd065fa1b789a1aad0e2177e8d93165891c47de3c1a11fc0739f6") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548857
addappid(3548858, 1, "dcd809f19c9294b85593cabb3dc2c4d0d84662a796348ca8a805f35592f5aaeb") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548858
addappid(3719711, 1, "3a9798f6336b3a8fec444c82789002cc886d10d2921932103ae26a90a41a24fc") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719711
addappid(3719712, 1, "88392d869eb78bdf65d2543007ad2680a111e5207940302c575dfee0f6ce8282") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719712
addappid(3719717, 1, "a8cb7971fb8ae591b88bf75d3aaacf7891ae2d2b35c67ea894a810370e2a69bb") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719717
addappid(3719718, 1, "0e2d9e3a30f27ff5df5164a6fecb9f47a59c94ad9cc9e0f3fb67200747b25368") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719718
-- addappid(3548852, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548852 (no key available)
-- addappid(3548855, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548855 (no key available)
-- addappid(3548859, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3548859 (no key available)
-- addappid(3719710, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719710 (no key available)
-- addappid(3719713, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719713 (no key available)
-- addappid(3719714, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719714 (no key available)
-- addappid(3719715, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719715 (no key available)
-- addappid(3719716, 1, "MISSING_KEY") -- The Sims 4 Adventure Awaits Expansion Pack - Depot 3719716 (no key available)
-- The Sims 4 SpongeBob Kids Room Kit (AppID: 3602110)
addappid(3602110)
addappid(3602110, 1, "b32e753b545a55f4ba8b5d375d328f65666ac88c580a00556e2ab4552406a404") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602110
addappid(3602111, 1, "d14b757b2845c9d92bf24af5a81860bd5df3a39d9018961a538454d05bdc6679") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602111
addappid(3602112, 1, "78403c103840d72e1e6d7288fedd2dc8ff4694d1484049cafc78d7642a9cef3b") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602112
addappid(3602113, 1, "3d8daf1fffbc4b4d116d5e7dba8d7745b313fb65667b568a327786e7c03ecffe") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602113
addappid(3602114, 1, "59c7c453f67a17dede4b1b5093f276a26e78a2f7b28f24cf0bc1762c95418a08") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602114
addappid(3602115, 1, "86c1ad4ca2860d0596fa73c22c281960770337632f4cf84bdc79b9c658626924") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602115
addappid(3602116, 1, "075bcc0255aabbfeec4df7e6ed39892e78e7940bede169dbcb28e6859f52fd27") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602116
addappid(3602117, 1, "2bc5bd7af9d7a5195531035d4bae876bbe59527a8f0127f1235f6701aa686d84") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602117
addappid(3602118, 1, "fa6f15e88ab90e2551d9f6fc8aedd392d77939034f2613e0f993fdea7c9e44fc") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602118
addappid(3602119, 1, "c138168dbb542be6238c7b9773ec4b3acf88bbfdc1ea45a266f4f2966f1e82a7") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3602119
addappid(3719790, 1, "65ef07d94017c925a421d0142eaa58b77fa8bcfb29e97690dc1786f4fae4e8fb") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719790
addappid(3719791, 1, "22b5cd4ff36499e467454a34b7c5c8df2816807e7201f46dae1e7736bdb18b0c") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719791
addappid(3719792, 1, "f1743e5f8ab668435f1bfb114518034b2cdf0e848b529199ea9c01b04ee448a3") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719792
addappid(3719793, 1, "353767b904904405ee3c7bfa1632efeffdfee0a3916157906d2ff94e9e223059") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719793
addappid(3719794, 1, "9e56ee36c944e773caf78846dece6d7bfd6ed8c0a72297dc73400ab740855c92") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719794
addappid(3719795, 1, "eba854115737a9625602d58a736dbfdf79f7a5028e8b7e1c6ba8f07c8c9ef2d7") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719795
addappid(3719796, 1, "3780ad6dc2420810b18361fdb9292397a6706a94d77a1f1fabf1c95172423daa") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719796
addappid(3719797, 1, "211b0085b048296b8c82ae69589cf5fb124cb900b84ec9015be568936163782b") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719797
addappid(3719798, 1, "f2e4f59c015e461e7b77978c4ece9dee8c21c381ab2cc12a3e2170a19546bc4b") -- The Sims 4 SpongeBob Kids Room Kit - Depot 3719798
-- The Sims 4 SpongeBobs House Kit (AppID: 3602410)
addappid(3602410)
addappid(3602410, 1, "561eefbc4e4e14b8cf6cf020bf198b5f76a9b5c991936b0ae487816d85f5b4d3") -- The Sims 4 SpongeBobs House Kit - Depot 3602410
addappid(3602411, 1, "4a17d03071c995c4e54fe5b26dd4b7364c802af71f01220f5043e923d2bc0d9d") -- The Sims 4 SpongeBobs House Kit - Depot 3602411
addappid(3602412, 1, "eb4b823ec2b157ecb438b50d9b216f144a6a9a36d85b9755ca40bf2d20f3e6da") -- The Sims 4 SpongeBobs House Kit - Depot 3602412
addappid(3602413, 1, "2c011ae209fbedaf75c796e9c232709a053bd27a6573829732c60bc3e5f5aacf") -- The Sims 4 SpongeBobs House Kit - Depot 3602413
addappid(3602414, 1, "d19c4d75cd1e054d1cadd2af82223ea0d094050220706dfd7cc07baecdd57c11") -- The Sims 4 SpongeBobs House Kit - Depot 3602414
addappid(3602415, 1, "441893647733cf9ca50a5416161d0c30367e0c14363245780089cad27bec76fd") -- The Sims 4 SpongeBobs House Kit - Depot 3602415
addappid(3602416, 1, "5897390f868366bc2d1f3a57d1bf93322555bd35300f401e0f8b832f2bd8d132") -- The Sims 4 SpongeBobs House Kit - Depot 3602416
addappid(3602417, 1, "f377ecad73fb3058d304c1944499d5af8204383fc790b408a24cc5747230b1d0") -- The Sims 4 SpongeBobs House Kit - Depot 3602417
addappid(3602418, 1, "4a9bb0613fabbc88153ec5fd5f03db0eb906f1297ce6266c5cc0c80820100423") -- The Sims 4 SpongeBobs House Kit - Depot 3602418
addappid(3602419, 1, "dbe74a9183ccaff54b96a35ec7f6b8bf8ca6918f30197fe09bcd646d4742dd1f") -- The Sims 4 SpongeBobs House Kit - Depot 3602419
addappid(3719750, 1, "7a9680fa01893acc082db117155a8e99422cda9ba131403b1f79204978e5c8a6") -- The Sims 4 SpongeBobs House Kit - Depot 3719750
addappid(3719751, 1, "c28d36225b351e035fc27c52c06efc62bc7c9a053e3a882ff7eeb3d523a87660") -- The Sims 4 SpongeBobs House Kit - Depot 3719751
addappid(3719752, 1, "2fc6f17cc3ea070d34dd385120674e8e148fedfc9eded91dbfc59df4993479ee") -- The Sims 4 SpongeBobs House Kit - Depot 3719752
addappid(3719753, 1, "ed680409685926630d1f486ef83f96686cf6268642f4b150deb2b178ede0501f") -- The Sims 4 SpongeBobs House Kit - Depot 3719753
addappid(3719754, 1, "be6a73733aea3780c2eb9367f1b9d0d8a903a01c3cf4cdbb63b32e318de79dbe") -- The Sims 4 SpongeBobs House Kit - Depot 3719754
addappid(3719755, 1, "691b51a312703c39076c50f82b5e3b87c8bd1697485a3a3fe3ac5e58442ff843") -- The Sims 4 SpongeBobs House Kit - Depot 3719755
addappid(3719756, 1, "64708269b7f30ff59a0daf667396797ccfe7c60e99fec6d0de521f1fabb380fb") -- The Sims 4 SpongeBobs House Kit - Depot 3719756
addappid(3719757, 1, "d0a19e445617ef6931121b84151cccfd659529961a6c75fc8285b75da410f0d5") -- The Sims 4 SpongeBobs House Kit - Depot 3719757
addappid(3719758, 1, "3c3695a68f290af812085fc9efd5d227f0feae53426a7b8573ecd95f2d812ed4") -- The Sims 4 SpongeBobs House Kit - Depot 3719758
-- The Sims 4 Autumn Apparel Kit (AppID: 3602420)
addappid(3602420)
addappid(3602420, 1, "15dfc39c1d0b777d0fd234609a0709447a034ecbfaf08533902e090e4b923e20") -- The Sims 4 Autumn Apparel Kit - Depot 3602420
addappid(3602421, 1, "b827ab07e63a23446f5711c6e7bcf4c5fb08f1a65f0c2acdde3e9ddbd832e80f") -- The Sims 4 Autumn Apparel Kit - Depot 3602421
addappid(3602422, 1, "beff1d3770b2404dc009c0feec5cd82d010b51ce8569c5201fb32729f96aeb72") -- The Sims 4 Autumn Apparel Kit - Depot 3602422
addappid(3602423, 1, "888d06413c9e27ff4adb97ae59955ab271df54503feffb073837e6a0e8d6049b") -- The Sims 4 Autumn Apparel Kit - Depot 3602423
addappid(3602424, 1, "82bc3df313d687eecc9c0003b4389c8ac1e7271885f5930f2cc32d57118ed597") -- The Sims 4 Autumn Apparel Kit - Depot 3602424
addappid(3602425, 1, "63c22d3d708bc798229c5c16ad6dcb42686c5e64811e03516cef626f10524b78") -- The Sims 4 Autumn Apparel Kit - Depot 3602425
addappid(3602426, 1, "faf3ae292c966d6cb7a1fab19cbabed56a5ed2fb71cd64f295dbd8df710a5d84") -- The Sims 4 Autumn Apparel Kit - Depot 3602426
addappid(3602427, 1, "5b99c0699dc0016bca5d5d6d1f83d3a1bac69e2c8a1882545dc57b8683bae4ae") -- The Sims 4 Autumn Apparel Kit - Depot 3602427
addappid(3602428, 1, "2c2747eb5d251cf27481f9431f7cf6c79fafc1e6bccdcceec37aae8af19378a9") -- The Sims 4 Autumn Apparel Kit - Depot 3602428
addappid(3602429, 1, "0f25066b4e8a757cfed5a87537b2ad784398396213d2583c41fdb926091c2331") -- The Sims 4 Autumn Apparel Kit - Depot 3602429
addappid(3719770, 1, "d892d4a53c61bc37628bb0079276d254241be50436101b53892e65f4e23c15ca") -- The Sims 4 Autumn Apparel Kit - Depot 3719770
addappid(3719771, 1, "6c73f36ef0db135333ab2a12673c6b2080912290fcecf185fcb9c81d510e4a43") -- The Sims 4 Autumn Apparel Kit - Depot 3719771
addappid(3719772, 1, "cfa4ff3abfc1025d66c1a6e9509bb593655dc0c045fb78c285ccc9eeb87717ff") -- The Sims 4 Autumn Apparel Kit - Depot 3719772
addappid(3719773, 1, "2a0a7cb8137d0549e2c5e01f616effa52ed9e1bb0dea1152cc2854128fb938e6") -- The Sims 4 Autumn Apparel Kit - Depot 3719773
addappid(3719774, 1, "e671d9e13232f612677e7a40eb402b7c9ddfb713c1f879d2b52db6d985856aac") -- The Sims 4 Autumn Apparel Kit - Depot 3719774
addappid(3719775, 1, "6b8842edb73b5419c618b959f903c4d8aa852871d4a725a26fb386d7002d1960") -- The Sims 4 Autumn Apparel Kit - Depot 3719775
addappid(3719776, 1, "44b31bbcdefb05e13d6f33108c55c65c2c190b92a21a1b956affefc69de0cc7c") -- The Sims 4 Autumn Apparel Kit - Depot 3719776
addappid(3719777, 1, "8dd6e70dd927f5ca63a1865c25ac0434b751882132241462b0fbfc4d6f0153d6") -- The Sims 4 Autumn Apparel Kit - Depot 3719777
addappid(3719778, 1, "0972f9cb768026a60ae38624afddb2c28a8134737694a14453b977c6649ba2c9") -- The Sims 4 Autumn Apparel Kit - Depot 3719778
-- The Sims 4 Grange Mudroom Kit (AppID: 3702300)
addappid(3702300)
addappid(3702300, 1, "ada181ffb289831f4f665c45b28fccba6b3fcb5a5459c3b57d6b2e1ba05a9a19") -- The Sims 4 Grange Mudroom Kit - Depot 3702300
addappid(3702301, 1, "1bbf9d44eb7997ed5c412bc1ba300b619309b5c00601cc0b4cc19dc4d87a7eec") -- The Sims 4 Grange Mudroom Kit - Depot 3702301
addappid(3702302, 1, "dad7b2f92e06a804dccfca8f6446747ae206f7afbc86cc505f28138cb8c09f14") -- The Sims 4 Grange Mudroom Kit - Depot 3702302
addappid(3702303, 1, "4ba5f92f4f2cd2b53962516df36ca322e339936004f47c93b585808a4fc1a0d6") -- The Sims 4 Grange Mudroom Kit - Depot 3702303
addappid(3702304, 1, "c0edf0398399af330a891e313202cacf28deb9ed44ceb2f533d0e864cc04e5b5") -- The Sims 4 Grange Mudroom Kit - Depot 3702304
addappid(3702307, 1, "b05389242ae57f7a0acad1e3ac6a39bcff9ed841c50c1dd92003dfeaf6218ec8") -- The Sims 4 Grange Mudroom Kit - Depot 3702307
addappid(3702308, 1, "47215d449c81dc81622e5e7a6e2127cd1eb4cbbe445ac60ab67a5baf800ee5d8") -- The Sims 4 Grange Mudroom Kit - Depot 3702308
addappid(3719811, 1, "de1f7d95e7957fdfe8e27fcb08ec8877ecacb62afe961c3b5ebf177cf6f11f5d") -- The Sims 4 Grange Mudroom Kit - Depot 3719811
addappid(3719818, 1, "ac34b182a7c10b06a9cf910f88172ab890efad76bca2dc00cac7131a6a5e20d6") -- The Sims 4 Grange Mudroom Kit - Depot 3719818
-- addappid(3702305, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3702305 (no key available)
-- addappid(3702306, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3702306 (no key available)
-- addappid(3702309, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3702309 (no key available)
-- addappid(3719810, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719810 (no key available)
-- addappid(3719812, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719812 (no key available)
-- addappid(3719813, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719813 (no key available)
-- addappid(3719814, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719814 (no key available)
-- addappid(3719815, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719815 (no key available)
-- addappid(3719816, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719816 (no key available)
-- addappid(3719817, 1, "MISSING_KEY") -- The Sims 4 Grange Mudroom Kit - Depot 3719817 (no key available)
-- The Sims 4 Essential Glam Kit (AppID: 3702310)
addappid(3702310)
addappid(3702310, 1, "a4063c6b000d91397fd9d8e9f31b66f895961924d1e9a6d0b3de881d0b513e40") -- The Sims 4 Essential Glam Kit - Depot 3702310
addappid(3702311, 1, "49865607b0f45c9a532c9f491984f85d6d19b50d27984fa762be1a23e8426633") -- The Sims 4 Essential Glam Kit - Depot 3702311
addappid(3702313, 1, "9b3ee3cada03fbaef2433d011c2a7c09ffa555c043f7281dd6f3a86abb0f414e") -- The Sims 4 Essential Glam Kit - Depot 3702313
addappid(3702314, 1, "da5083eacc9f8b88f102bb84d7f67e7852c95d623cac6c32af2995ad242d54f8") -- The Sims 4 Essential Glam Kit - Depot 3702314
addappid(3702316, 1, "cd237ce8117e15282116c2483b1ca277499a31e58d428837abe0238dccc25927") -- The Sims 4 Essential Glam Kit - Depot 3702316
addappid(3702317, 1, "1f019c213338fe4f0cb16984863921d3efe13acae283b06dbcaf23b09a427f88") -- The Sims 4 Essential Glam Kit - Depot 3702317
addappid(3702318, 1, "14caea449e59d6c6122ff30e5111565caf2c4d9a4703d16ad5c32b3bac668232") -- The Sims 4 Essential Glam Kit - Depot 3702318
addappid(3719831, 1, "5ac35759c12704dba81e0e5525e9f2e8989f6c5c3dbaa3986741f265acf9ab96") -- The Sims 4 Essential Glam Kit - Depot 3719831
addappid(3719838, 1, "4908f56f4b7c912163c5f3f1841c1b64fdf109e9fdab000c6d5baa7125929839") -- The Sims 4 Essential Glam Kit - Depot 3719838
-- addappid(3702312, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3702312 (no key available)
-- addappid(3702315, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3702315 (no key available)
-- addappid(3702319, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3702319 (no key available)
-- addappid(3719830, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719830 (no key available)
-- addappid(3719832, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719832 (no key available)
-- addappid(3719833, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719833 (no key available)
-- addappid(3719834, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719834 (no key available)
-- addappid(3719835, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719835 (no key available)
-- addappid(3719836, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719836 (no key available)
-- addappid(3719837, 1, "MISSING_KEY") -- The Sims 4 Essential Glam Kit - Depot 3719837 (no key available)
-- The Sims 4 Modern Retreat Kit (AppID: 3765160)
addappid(3765160)
addappid(3765160, 1, "5b78c900a7483608719389bdb43ac66413c1beaf10878512157810cd0e229fc7") -- The Sims 4 Modern Retreat Kit - Depot 3765160
addappid(3765161, 1, "dec7c6938b25c7b90eefbd85a2e84be916e7289cdabd94713733fd34dc2f626c") -- The Sims 4 Modern Retreat Kit - Depot 3765161
addappid(3765162, 1, "d92d5e23abd92584c7b48ff2bd0f7033f98fa681330047aa6b0d6aee47f9c5ed") -- The Sims 4 Modern Retreat Kit - Depot 3765162
addappid(3765163, 1, "e28594b3a3b4c1f77d879a9df782217ffdd19570e4d9a18d3af983d3af86400b") -- The Sims 4 Modern Retreat Kit - Depot 3765163
addappid(3765164, 1, "5627f5990063e55a6c6f25a4579163970a8c9fd6c845a0750da768a690c527df") -- The Sims 4 Modern Retreat Kit - Depot 3765164
addappid(3765165, 1, "8fe55cc058b4aecd71e5b8cbfaecb61d30be04ca3121fe8f2e5d183ce24bb47e") -- The Sims 4 Modern Retreat Kit - Depot 3765165
addappid(3765166, 1, "1791ca8899f063922d175458a6067be292632eea16ca5c838b426301bb946c17") -- The Sims 4 Modern Retreat Kit - Depot 3765166
addappid(3765167, 1, "572ec0647cf77e5e1cb122f3fa21b7b598f6b035f3aa2c0d490a11343271b1c7") -- The Sims 4 Modern Retreat Kit - Depot 3765167
addappid(3765168, 1, "466a90b27615d577b4ff8aba555bf546f0f00838289d326415382b15e9f44798") -- The Sims 4 Modern Retreat Kit - Depot 3765168
addappid(3765169, 1, "9a4377061875358f35c9797bc335721fe1682a19e547e8e6d6836304ad093ca2") -- The Sims 4 Modern Retreat Kit - Depot 3765169
addappid(4103310, 1, "2466b3575be7858ab659350b2f1651a676710b7da8ca07e5c6ca1f23c7e17adb") -- The Sims 4 Modern Retreat Kit - Depot 4103310
addappid(4103311, 1, "ca977d0b630c655c92a11d10f7fcf59ea0db5b525fb5fa2ebb1adac4f5d25510") -- The Sims 4 Modern Retreat Kit - Depot 4103311
addappid(4103312, 1, "85f79e03829ed62930013e897854a7d29477ed657cc481010c8f47f1f9d94d1c") -- The Sims 4 Modern Retreat Kit - Depot 4103312
addappid(4103313, 1, "4120b2a7be8366c0cf7e7912e65f9dcf9e529ea0744d3f3141de9f27ba1de65e") -- The Sims 4 Modern Retreat Kit - Depot 4103313
addappid(4103314, 1, "422e842b2682602b5ce006edd294c37bc195bd8492b61391b8cfeeea2484c97e") -- The Sims 4 Modern Retreat Kit - Depot 4103314
addappid(4103315, 1, "5f197b98e69802abac686b1cf32b68e2b288ab1b83adfea4d7e7788777314685") -- The Sims 4 Modern Retreat Kit - Depot 4103315
addappid(4103316, 1, "1183a2478c25a5f4486b2a7b5401f8c1951403416a56f5283952970f3c9c64d0") -- The Sims 4 Modern Retreat Kit - Depot 4103316
addappid(4103317, 1, "474a70d08205e001e8983e086704f4c5a767c71aad98cf371b666f1cbdfbe1c8") -- The Sims 4 Modern Retreat Kit - Depot 4103317
addappid(4103318, 1, "32563e8356a07f84b6423ae90d1653a8724a8eee5b3e7a1ccd285b2e1cc162a7") -- The Sims 4 Modern Retreat Kit - Depot 4103318
-- The Sims 4 Garden to Table Kit (AppID: 3765170)
addappid(3765170)
addappid(3765170, 1, "9cc07f84fb2a723a0a7d4608ffb26e6fe8e18830f7fa1931d0906a19e37f8b76") -- The Sims 4 Garden to Table Kit - Depot 3765170
addappid(3765171, 1, "e3d12fb4e725440c18f9813d24be8d271c369483ec1e3ee924b95e81e74d6dfa") -- The Sims 4 Garden to Table Kit - Depot 3765171
addappid(3765172, 1, "76663c5ea984913b3c0c7f9827ee207e90c4cbc22fda445e5cd38d6a6d0cfaee") -- The Sims 4 Garden to Table Kit - Depot 3765172
addappid(3765173, 1, "cdf242266fdabd4dbb397f647f63ea746baca6cd3757c9a2ac360cbd8da4de55") -- The Sims 4 Garden to Table Kit - Depot 3765173
addappid(3765174, 1, "b4ac0d0736744d3e4c6242c751399246f7ea85596dd497a9d304093712afa461") -- The Sims 4 Garden to Table Kit - Depot 3765174
addappid(3765175, 1, "162a495a7e5b434bd03d1b532d1e4740c8ffeb6bfea96153e60a94f76a895eed") -- The Sims 4 Garden to Table Kit - Depot 3765175
addappid(3765176, 1, "741bf584028bfb57f0b913042443bab5b7d0d66653773f87c8e9b2fd3cf10b15") -- The Sims 4 Garden to Table Kit - Depot 3765176
addappid(3765177, 1, "f318430ec2d411dfee82bd2acf95ae861196a9c6cc6767bd1132fe46f1404412") -- The Sims 4 Garden to Table Kit - Depot 3765177
addappid(3765178, 1, "2571f68a47d2c4e91f470f6ccad1c7046f9f25df3a2e2cbc3b99aa113a0b5214") -- The Sims 4 Garden to Table Kit - Depot 3765178
addappid(3765179, 1, "7bff4771826db05cffd157529512153dbbef45d726555ed8c4658837f3ac33d9") -- The Sims 4 Garden to Table Kit - Depot 3765179
addappid(4103320, 1, "949f593843b21ef4f059df4e7ae4bc0299062b3b9eb3fde86161f2c95fd26ae7") -- The Sims 4 Garden to Table Kit - Depot 4103320
addappid(4103321, 1, "46340db5d6a15dbb57aa3b243ff029996cc9105f8879177cbb64f6c5c711beb7") -- The Sims 4 Garden to Table Kit - Depot 4103321
addappid(4103322, 1, "7d1f6cdeb7e7871395ce99fbf71e1567790c4286585af4b3f718216898b88472") -- The Sims 4 Garden to Table Kit - Depot 4103322
addappid(4103323, 1, "452465eef6fe390d8308a245fb37a3dc8442bbe9ba7566c5fe3a08aac1948ea2") -- The Sims 4 Garden to Table Kit - Depot 4103323
addappid(4103324, 1, "fcc8266040c15831b300dd77fb21c724cf470d8a1a445b77a987fc5a17190ef7") -- The Sims 4 Garden to Table Kit - Depot 4103324
addappid(4103325, 1, "86b69ba37a72bdaf241944f524af7351be51867c1bc988cfb191b58ca581a914") -- The Sims 4 Garden to Table Kit - Depot 4103325
addappid(4103326, 1, "f8cccad5b529028c6e7eaf0078d8e2da14c7b0b660ec0c92974d44faab4a1736") -- The Sims 4 Garden to Table Kit - Depot 4103326
addappid(4103327, 1, "435222892412cef127ac2a76cec716d6c379b0e4acc29b43cb4a8481ebb826c2") -- The Sims 4 Garden to Table Kit - Depot 4103327
addappid(4103328, 1, "9f4940f63c84e93f1da5850d3ff97dde592e1446a4e6b882590b260cd4da0624") -- The Sims 4 Garden to Table Kit - Depot 4103328
-- The Sims 4 Wonderland Playroom Kit (AppID: 3765180)
addappid(3765180)
addappid(3765180, 1, "680a7db7ebcafb8fb1208ee81845e4b888557e3ede94b76225c92bf1c771e683") -- The Sims 4 Wonderland Playroom Kit - Depot 3765180
addappid(3765181, 1, "9f45ad8c8f57f91dc9d3ba97354c749e9c6d7c9a0f4822d14336e1710c2370ff") -- The Sims 4 Wonderland Playroom Kit - Depot 3765181
addappid(3765182, 1, "41dc8b9a69963e3607bbc1b2c575bf55d55b5bbed86ce14cb082e57406f263a8") -- The Sims 4 Wonderland Playroom Kit - Depot 3765182
addappid(3765183, 1, "669e4640bc22cdd62e81e7bc25ec7ac9d7fbfda7e52b9830e50ce77ab88559b0") -- The Sims 4 Wonderland Playroom Kit - Depot 3765183
addappid(3765187, 1, "e32f011139a26405d7515f0306bd948ea07f9addea519dccea593a4618626cf1") -- The Sims 4 Wonderland Playroom Kit - Depot 3765187
addappid(4103338, 1, "cc52f32c9e4be9890775bf5f6468d22adb7a71e9ae0650d3f2ea856abc7a4728") -- The Sims 4 Wonderland Playroom Kit - Depot 4103338
-- addappid(3765184, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 3765184 (no key available)
-- addappid(3765185, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 3765185 (no key available)
-- addappid(3765186, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 3765186 (no key available)
-- addappid(3765188, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 3765188 (no key available)
-- addappid(3765189, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 3765189 (no key available)
-- addappid(4103330, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103330 (no key available)
-- addappid(4103331, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103331 (no key available)
-- addappid(4103332, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103332 (no key available)
-- addappid(4103333, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103333 (no key available)
-- addappid(4103334, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103334 (no key available)
-- addappid(4103335, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103335 (no key available)
-- addappid(4103336, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103336 (no key available)
-- addappid(4103337, 1, "MISSING_KEY") -- The Sims 4 Wonderland Playroom Kit - Depot 4103337 (no key available)
-- The Sims 4 Silver Screen Style Kit (AppID: 3765190)
addappid(3765190)
addappid(3765190, 1, "d70b2c89bd0a903be6358dd8f9d903c7097ad899b49ce7413b005bafe341fe03") -- The Sims 4 Silver Screen Style Kit - Depot 3765190
addappid(3765191, 1, "d7b564047eba70ca37dcf9733e77830bc67f58dc07a69c5154df820c975a9562") -- The Sims 4 Silver Screen Style Kit - Depot 3765191
addappid(3765193, 1, "37f163b12601987fba88209f59eba2d2a26f0260d53da54090d40dd964fd0f9f") -- The Sims 4 Silver Screen Style Kit - Depot 3765193
addappid(3765194, 1, "2ce59ef5dc34a632fe183fed70aa94ec6457410c61bc2dad9b4566ccfcc001b0") -- The Sims 4 Silver Screen Style Kit - Depot 3765194
addappid(3765196, 1, "07b95527cee41e19237d0b9f67b928dd768f34b9a0ca56e54f95e7a9f16d809f") -- The Sims 4 Silver Screen Style Kit - Depot 3765196
addappid(3765197, 1, "7b52824ceed2bc8f5cbaeb9c164c64b61ac46e3e51eb87cbe5e296a4243bf52f") -- The Sims 4 Silver Screen Style Kit - Depot 3765197
addappid(3765198, 1, "c24f5aba558bbdd39f41edaffb595abe7baa58da8bb66fd3b3c1ca6489222fa7") -- The Sims 4 Silver Screen Style Kit - Depot 3765198
addappid(4103341, 1, "f113f51f3b53202205739bb00641c2868bb050f8216e6b9fb5e932509fbde043") -- The Sims 4 Silver Screen Style Kit - Depot 4103341
addappid(4103348, 1, "21863ff5ca4b7ce7788713e821658388dbe75326973744de979535c6c321fd27") -- The Sims 4 Silver Screen Style Kit - Depot 4103348
-- addappid(3765192, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 3765192 (no key available)
-- addappid(3765195, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 3765195 (no key available)
-- addappid(3765199, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 3765199 (no key available)
-- addappid(4103340, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103340 (no key available)
-- addappid(4103342, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103342 (no key available)
-- addappid(4103343, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103343 (no key available)
-- addappid(4103344, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103344 (no key available)
-- addappid(4103345, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103345 (no key available)
-- addappid(4103346, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103346 (no key available)
-- addappid(4103347, 1, "MISSING_KEY") -- The Sims 4 Silver Screen Style Kit - Depot 4103347 (no key available)
-- The Sims 4 Tea Time Solarium Kit (AppID: 3765200)
addappid(3765200)
addappid(3765200, 1, "87b48ed2ce4d80d09370a4bec9eb799c7f65ca72b167d3844a70b8c7c3641cab") -- The Sims 4 Tea Time Solarium Kit - Depot 3765200
addappid(3765201, 1, "34ef76c10854d4f6fe46a7203a1704b0fb972eb69f48fa1f2d39a781d87ba967") -- The Sims 4 Tea Time Solarium Kit - Depot 3765201
addappid(3765203, 1, "f31eda3b58c6519270f57d61cbd204a592f23227f29b6cd103c24b5e507957a8") -- The Sims 4 Tea Time Solarium Kit - Depot 3765203
addappid(3765204, 1, "9ff5e57a1530795197983f25ce640dd05f9b9cfc523b13b458b7f2a30270752a") -- The Sims 4 Tea Time Solarium Kit - Depot 3765204
addappid(3765206, 1, "6cce6d79432cb743aaee9aad64f436f18941545196417579f5543229ae0c3e3e") -- The Sims 4 Tea Time Solarium Kit - Depot 3765206
addappid(3765207, 1, "46e27ffee73313469a38540ce73a0c6993ec42d6224c8d556c1691ef8c1a2bb8") -- The Sims 4 Tea Time Solarium Kit - Depot 3765207
addappid(3765208, 1, "dd73abb81f16ff5d2f11d711998707480799d78c8e5aa32b18dc3547868bcab6") -- The Sims 4 Tea Time Solarium Kit - Depot 3765208
addappid(4103351, 1, "392aac42ac3926f7f32f9ee9c0111c2a4bc31aa8153a983f33f0a5e9595b55e2") -- The Sims 4 Tea Time Solarium Kit - Depot 4103351
addappid(4103358, 1, "15bb641b174bd1e59b0cd939d499a61f4929ecfefe62336a51d45150faf84321") -- The Sims 4 Tea Time Solarium Kit - Depot 4103358
-- addappid(3765202, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 3765202 (no key available)
-- addappid(3765205, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 3765205 (no key available)
-- addappid(3765209, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 3765209 (no key available)
-- addappid(4103350, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103350 (no key available)
-- addappid(4103352, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103352 (no key available)
-- addappid(4103353, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103353 (no key available)
-- addappid(4103354, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103354 (no key available)
-- addappid(4103355, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103355 (no key available)
-- addappid(4103356, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103356 (no key available)
-- addappid(4103357, 1, "MISSING_KEY") -- The Sims 4 Tea Time Solarium Kit - Depot 4103357 (no key available)
-- The Sims 4 Prairie Dreams (AppID: 3985830)
addappid(3985830)
addappid(3985830, 1, "daeb424b7f30b863a7ee68c929cc383944bd04c221520e1a6e76223b6449406d") -- The Sims 4 Prairie Dreams - Depot 3985830
addappid(3985831, 1, "7121dd82efb94899c91960287204bdfb47ff7db7a674ef1e24cd09b0908193f6") -- The Sims 4 Prairie Dreams - Depot 3985831
addappid(3985832, 1, "a68264fa7b587d062b107768158f1d4b986ae7dcf8348f93e0c44e9751c554cc") -- The Sims 4 Prairie Dreams - Depot 3985832
addappid(3985833, 1, "9a3555fb6f2f3197354fc43e67f38ec9a826876e16a3b18d0920bcbefe0f7b09") -- The Sims 4 Prairie Dreams - Depot 3985833
addappid(3985834, 1, "d6b1309d8f4fd2cafc8d2b265099881de43560cb0d220beeb1ac8c28a9fa0411") -- The Sims 4 Prairie Dreams - Depot 3985834
addappid(3985835, 1, "af6b689d91e332b2c3af3273a1547f3f5e59ddde42686f884b83ae63f6999153") -- The Sims 4 Prairie Dreams - Depot 3985835
addappid(3985836, 1, "656412200214e28cb80a7d2f81735f3a6ac9fbb5942db69036aba1e7297df555") -- The Sims 4 Prairie Dreams - Depot 3985836
addappid(3985837, 1, "5d6d0bfaa2e6cb60b4323ac4aca41502dd33b2c8a0e2868d874cfed73d477fbf") -- The Sims 4 Prairie Dreams - Depot 3985837
addappid(3985838, 1, "c9fc6b52dd8132ecca63c84e6345646924c20bad5ed1b97c3aa251b13375f513") -- The Sims 4 Prairie Dreams - Depot 3985838
addappid(3985839, 1, "88d1b8dc45f43ddd6c05c3c54350cb479307c8d987f1522a303f83f9b858f112") -- The Sims 4 Prairie Dreams - Depot 3985839
addappid(4103370, 1, "fa2e0d9a4f5c448ab5a2a9102f6c2f954e17c77556994baa0b227d28921a01b8") -- The Sims 4 Prairie Dreams - Depot 4103370
addappid(4103371, 1, "fd304c3da047a4bfc6455b4df1afb6ea0ffda4f81674cb14d255024b0ecab2ea") -- The Sims 4 Prairie Dreams - Depot 4103371
addappid(4103372, 1, "f75b03d620fe2b1e0876f4850c18a4dcfcea135a65a112394efcbf6ad74e15d3") -- The Sims 4 Prairie Dreams - Depot 4103372
addappid(4103373, 1, "5329959fcb8b5542738acbd892fe999bdec5b6f2e2d2a679e2d3848677bcfa46") -- The Sims 4 Prairie Dreams - Depot 4103373
addappid(4103374, 1, "33ed2918cdefe2508e89bb0f3af1855ef7efed16f64bdc95e799e26a6f919a2e") -- The Sims 4 Prairie Dreams - Depot 4103374
addappid(4103375, 1, "97537a0233502bf68d593c183dadb38122b7b9d6cb869daa982b6b84074c8116") -- The Sims 4 Prairie Dreams - Depot 4103375
addappid(4103376, 1, "85c12a9c6ab328fb8cab8d59769027ddaaf6ebe773c91051f2bcfdbe2782d001") -- The Sims 4 Prairie Dreams - Depot 4103376
addappid(4103377, 1, "907cdbb1b9b376de9fd5786ff67980f14315d400fd86cb55fa4927ea813541fa") -- The Sims 4 Prairie Dreams - Depot 4103377
addappid(4103378, 1, "6273b08984dc0eb612cfdd440e0599ca648786c50a0ba143483710f1388e594d") -- The Sims 4 Prairie Dreams - Depot 4103378
-- The Sims 4 Yard Charm Kit (AppID: 3986850)
addappid(3986850)
addappid(3986850, 1, "cdb8e4e4dbcbf674e0dbfd7c20f153c4a894df3b784dbe04ae0b999a6f473993") -- The Sims 4 Yard Charm Kit - Depot 3986850
addappid(3986851, 1, "6b2ae5ab40efa9609c3a9a26752794492caa927763a8f13389bc30909549ea9c") -- The Sims 4 Yard Charm Kit - Depot 3986851
addappid(3986852, 1, "78da6f76c1f89b7d0bac815e94cef75ed1a80f4ee7a80783f938cefc7c30b529") -- The Sims 4 Yard Charm Kit - Depot 3986852
addappid(3986857, 1, "0076a4d7c8493da1affe2bba6252a933a211fd9bcf2bcb31abc89a025f2d5ac0") -- The Sims 4 Yard Charm Kit - Depot 3986857
addappid(4103381, 1, "e456fa93555e9febc756641fa581cf2740f0b29534d0736450ee710f8cc43f83") -- The Sims 4 Yard Charm Kit - Depot 4103381
addappid(4103388, 1, "7a1e3ba66532f71a4d876ac8c2146e073c0ef0114495ef7187091a18a8cbbaf6") -- The Sims 4 Yard Charm Kit - Depot 4103388
-- addappid(3986853, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986853 (no key available)
-- addappid(3986854, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986854 (no key available)
-- addappid(3986855, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986855 (no key available)
-- addappid(3986856, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986856 (no key available)
-- addappid(3986858, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986858 (no key available)
-- addappid(3986859, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 3986859 (no key available)
-- addappid(4103380, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103380 (no key available)
-- addappid(4103382, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103382 (no key available)
-- addappid(4103383, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103383 (no key available)
-- addappid(4103384, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103384 (no key available)
-- addappid(4103385, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103385 (no key available)
-- addappid(4103386, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103386 (no key available)
-- addappid(4103387, 1, "MISSING_KEY") -- The Sims 4 Yard Charm Kit - Depot 4103387 (no key available)
-- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit (AppID: 4429510)
addappid(4429510)
addappid(4429510, 1, "88572f51fb8d0266ddaea03dc1a165d9ea33b44b23432cdccad26e44581f9198") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429510
addappid(4429511, 1, "96d8ebd55e5f7e8242f99ce44f1d8782dfa752057ebd2d185031f2bdc3ef4a41") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429511
addappid(4429512, 1, "9cc1508eb153ba3a0e1be68c36feccebdb3793fd5160b0e9675252586dc68f7f") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429512
addappid(4429513, 1, "b7cbdf4b5f83ae50b2523414fe232ee4c3df79ee55f7748e69e1c7ac7767cb17") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429513
addappid(4429514, 1, "ec9ed7602e60b555d190208a50df2e5b23c76494ca62cce71f7b8e8e86a28cf3") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429514
addappid(4429515, 1, "56be9acd06c678d1f056c7f32749b6276afdaa95e72283c4f43f0d343a637afd") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429515
addappid(4429516, 1, "63eba0c2522e3129c41b3117086fc3047e08c0c6d2bc4e72abd04960256e9c72") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429516
addappid(4429517, 1, "6b9ba20ced40117e8c94718db983ad0a64bc207b2f929a01f1ae235f892076bb") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429517
addappid(4429518, 1, "9f81132880e4d72f8b07b3c4b2048dca8d9cf1f37cb8834eaa5918ef9ac89e6a") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429518
addappid(4429519, 1, "52401b78f81cecd19a49c13ea40b92cab2af413f87c7c4b4e5cb29c84f81a069") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4429519
addappid(4458250, 1, "b14ebcd7033738705e043e932bfcc757119f042d1b102a10c188a00ae8017cde") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458250
addappid(4458251, 1, "51dd4b1c762699ae9fa2d4623c7d5ef42d44ea8f82fa32d845abd1b880f60357") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458251
addappid(4458252, 1, "daed2d380a8a463047c066312d241ff64a2ad7ea05c5cfaaca69286353466f75") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458252
addappid(4458253, 1, "5ece60bd85971a77185771b0899c50da2ea8463524ab82548a8b47ae202ac5be") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458253
addappid(4458254, 1, "e5dedc7ad2143e183faae2f6589e615e98d2ce5c9325364e9b34badec429565a") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458254
addappid(4458255, 1, "c61a70f6c99059138aa2d668bfb350ef4aa391ae63e79bed694efa6f269ce25b") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458255
addappid(4458256, 1, "1761a6edf1e3045a623236600679a6220c2ac499e8a9f8daa45b4b319774f55c") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458256
addappid(4458257, 1, "c8423b276d6fdcc3580386492f6e8c419765829e5f1fc90046133e14f0d5a96a") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458257
addappid(4458258, 1, "256ade42a6a5b12bf0ee03678d8bb8fff0c5ac47290b813ea3dcd84c40c23a48") -- The Sims 4 Lady Bridgertons Masquerade Ball Fashion Kit - Depot 4458258
-- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit (AppID: 4429520)
addappid(4429520)
addappid(4429520, 1, "68495e2c59c3a17948996e722535e96a114aee0db7232d14969c465ce9a0e51a") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429520
addappid(4429521, 1, "e0d0e2583df7b129188cdd04cf5493603134cfd372db8a91c118e8c2c5033d58") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429521
addappid(4429522, 1, "3745fcf11ffbf0ce74a6e3b11760139b7d39a12290eb4e7100c9f12dda898062") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429522
addappid(4429523, 1, "1aa40247c0d7a7bb2c0806742e48281c0a1c9506140a06439e7e0aed1071299f") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429523
addappid(4429524, 1, "9c4537dba53bfba2710640409115bde0e36c3cf1d0d3517057bb148f10b06f45") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429524
addappid(4429525, 1, "3a0ae0e47c562a02bef1d1a2590116c910a4406f03aef084144f7615d925f381") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429525
addappid(4429526, 1, "1cbdae3cbc70c0eadea6768818417f1b213312a9cc54a01835c626cbca8db88e") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429526
addappid(4429527, 1, "bbc55ad1ae3dc0d81739a242a27f8c08b623dfaa00d7dd4615ebd4117cdf6e26") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429527
addappid(4429528, 1, "1f55d9001db0133c2784b8f7d977a64283824a257a93fa8deab71172336fa903") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429528
addappid(4429529, 1, "040279ab24bc525f7c35bbb1c0792483aa9f31f95a1bc4796f35e887a66561c4") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4429529
addappid(4458270, 1, "a4e5a7ea0d87cd9db6b45a4503fcef4d62c331466f861301d1e1b0a8c6d984c9") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458270
addappid(4458271, 1, "6803bdb6a6c80143dd7f392123aae400deb920f3591c308a4e22010b468a068f") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458271
addappid(4458272, 1, "5eadd134ceea2bbd20b8a1c499c2f91a232d583c87d1a617ddb20d0a00cdb155") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458272
addappid(4458273, 1, "6b749e9c8dfcd3177567b1e0ae9588d2364270d6ebe633a73725690b87935d57") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458273
addappid(4458274, 1, "8841b44ee5a44d89c5430647ac52d4cde93817d0cb71281943e70d309194e442") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458274
addappid(4458275, 1, "82ff9d9d636008f7fb821c90a1d43fdca33434975028e85eb4f3ced7a3c7a208") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458275
addappid(4458276, 1, "915af3066c875abdaf383bb8945be93c909583bdfc4347ba2ecb4103f6a7fd64") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458276
addappid(4458277, 1, "3367085b0067ad34826dfcd893a0ce5d12f52b0df4c7ebfdd90a69f46b4748c9") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458277
addappid(4458278, 1, "5ae20ca5cd60f524581d07e22f3e1fdf282019806167e8b446eed62dfd8fce0b") -- The Sims 4 Lady Bridgertons Masquerade Ballroom Kit - Depot 4458278
-- The Sims 4 Music Den Kit  200 Moola (AppID: 4717310)
addappid(4717310)
addappid(4717310, 1, "e07fb163f01c9d0ce35d8dd88a700266927e11c3f9f8335a54eba86d05157dfe") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717310
addappid(4717311, 1, "615e3c3be70f7d5df582e6a108715b3937d8cc7d3ddb9ab2e4c6e64d1961ba8c") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717311
addappid(4717312, 1, "7cc463d25274bf069eb2ba19b274a81296507d40b488c26592e78208991e492b") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717312
addappid(4717313, 1, "cb6d61019a7b36bd9238aab901b36bbb3dbee607163ce5fdf307289ca6ac6b6b") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717313
addappid(4717314, 1, "803da60805971c5fd8cd2e3023c080fcf7882109cbc401aa8de4ffa04822eaf4") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717314
addappid(4717315, 1, "7bb809074bd8d4984df8050038502b8a1d68e1015b0068b4189b460d40f8cc66") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717315
addappid(4717316, 1, "c7fea476193fdd7cae075cffb43d6856baebfcaecd0d361892418e797f095e74") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717316
addappid(4717317, 1, "5da468e0327b2fd707ce2ba0eaddd13b6ad3981fbb94203fbbe69af16e705a5a") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717317
addappid(4717318, 1, "fb8d0183c06f1e998f2cddb4b58f369f4fd78cd6454da6a01819970ebe9b3154") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717318
addappid(4717319, 1, "fe99964c511e1f1e94d7da874d083956a642cb8a8487915b7bb248169fcfd780") -- The Sims 4 Music Den Kit  200 Moola - Depot 4717319
addappid(4935950, 1, "604938e690d02bfff906943ef805b95cb38261bbf1d8feed5c9bc375f52f274e") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935950
addappid(4935951, 1, "97a1e158898d72cccd292b805a3bf12be33f0c1f51e349fe526f02f0807af7d7") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935951
addappid(4935952, 1, "857e8e21d839e9037f967d179f19561b97ec910771ad745ca92316b3d4ffec18") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935952
addappid(4935953, 1, "1317e0213a7ae67e3155247319c7626db233e276a9aa76895017feba76735cf8") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935953
addappid(4935954, 1, "7c0821b8eab07420e8371815e804a622046d759269f306f8d270991a11a83b7b") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935954
addappid(4935955, 1, "eb9a3ceaae83649d91ff0cd6986ae4b8b61b0356d79fc895b950869053599f78") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935955
addappid(4935956, 1, "05402839bee9692b0438e924fde3fd5c5ff8c9cecd5ef0d720c2d3f7e09cceb8") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935956
addappid(4935957, 1, "4822f9a202b8dc14465a426be55a1fb97d9fc0d98e37263ba8a9e30d319d92d2") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935957
addappid(4935958, 1, "b3a96e20aa7c094f40425a0a73592f99891a1411f53475ecff124072a0cd46a9") -- The Sims 4 Music Den Kit  200 Moola - Depot 4935958
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1235765) -- The Sims 4 Digital Deluxe Upgrade
-- FORCE-ADDED DLCS (BYPASSES ALL VALIDATION)
addappid(4429590) -- Lady Bridgerton’s Masquerade Ball Digital Content