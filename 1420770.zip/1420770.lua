-- MAIN APPLICATION
addappid(1420770, 1, "49dd66b81a7807e691a64e9d8adfb13c1f80b5afcfc803a8d06a538ce78246bd") -- Winter Resort Simulator 2
-- MAIN APP DEPOTS
addappid(1420771, 1, "9ac7be0c7ff4039d7438a7c53a4f4b3e36277570075428d8fe7fe4a1a5c582d3") -- Winter Resort Simulator Season 2 Content
addappid(1784720, 1, "9a8e9b866b07086a97bfe47f7dacfcd8226617909234d6b30cdda4f70f3f1c98") -- "Winter Resort Simulator 2 - Ski Schanze (1784720)"-Depot
-- DLCS WITH DEDICATED DEPOTS
-- Winter Resort Simulator 2 - Content Pack (AppID: 1429910)
addappid(1429910)
addappid(1429910, 1, "463390aa4571d704fc03156ea5dba5465bb292b3b57b8c04fb28f04a7d5ec775") -- Winter Resort Simulator 2 - Content Pack - "Winter Resort Simulator Season 2 - Content Pack (1429910)"-Depot
-- Winter Resort Simulator 2 - TechnoAlpin - Snow Expert Pack (AppID: 1499590)
addappid(1499590)
addappid(1499590, 1, "c4abaa7adc6406e4d28b66ef5badd07b2d50dc4addcf80e306259ef93dce90dd") -- Winter Resort Simulator 2 - TechnoAlpin - Snow Expert Pack - "Winter Resort Simulator Season 2 - TechnoAlpin - Snow Expert Pack (1499590)"-Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2068060) -- Winter Resort Simulator 2 - Riedstein