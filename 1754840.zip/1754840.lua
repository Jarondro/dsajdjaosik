-- MAIN APPLICATION
addappid(1754840, 1, "2b1c0de29e2f79f3e5d2e9d707de1ded4b9ac5cff41feebd80ca2c147a7ccf19") -- Hacker Simulator
-- MAIN APP DEPOTS
addappid(1754841, 1, "a712e4d1bec4f811a9996e477ce6a964372106b3970ce86a38153fef3d12619d") -- Base Content
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
