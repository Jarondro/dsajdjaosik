-- MAIN APPLICATION
addappid(448280) -- Job Simulator
-- MAIN APP DEPOTS
addappid(448281, 1, "b8d16fcbf744f75f35628694c5aba487ac0d75fb60610ef40472f522cbb46eb5") -- Job Simulator Content
