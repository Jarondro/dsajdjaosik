-- MAIN APPLICATION
addappid(1151380) -- Cowboy Life Simulator
-- MAIN APP DEPOTS
addappid(1151381, 1, "10aeaa1e1ecb242e8f577ff9aabcba54ba4f68c13cb2649cca5c6eeef53a822a") -- Depot 1151381
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
