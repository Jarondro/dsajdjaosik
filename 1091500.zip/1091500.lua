-- MAIN APPLICATION
addappid(1091500, 1, "cf941dce25dfe9090877d385fca0ded473ecc1e12a09e28698b5c8dd3c134598") -- Cyberpunk 2077
-- MAIN APP DEPOTS
addappid(1091501, 1, "fd4524cb30582752f15e4bf01254dbb7b890f58008101a40208cd78fb139d800") -- Cyberpunk 2077 Content
addappid(1091502, 1, "90dd5a17a45ff0595a7ed6366d0fea078e8c362633ebbe6382c173d736063b72") -- Cyberpunk 2077 Speech PL
addappid(1091503, 1, "b2606cbfc79b86f848e75dbf59afeeae8a1d5c08523111dcdbeace51b69ec48c") -- Cyberpunk 2077 Speech RU
addappid(1091504, 1, "c874647c72c73e87686ecef42bd4c0fbc8e564be98bb0c20c487807c2c4d8d47") -- Cyberpunk 2077 Speech FR
addappid(1091505, 1, "8382ac2e50bd6c716f748eefe9aa9a7e4ccafe5f4f2d7a19f01e5d5d2d096864") -- Cyberpunk 2077 Speech IT
addappid(1091506, 1, "794d47675f8d91a58528e4b7e0bb347d1c542ccdd48eeda5a796b7c1af663e08") -- Cyberpunk 2077 Speech DE
addappid(1091507, 1, "ad400264d25291632ad0c35e48e98ae3ada3c411a7ed946bacbdfaa80fd0dd00") -- Cyberpunk 2077 Speech ES
addappid(1091508, 1, "fa0ebf333c7ac4828a8a38fd9c646543a872965d3bf1b5e205fa176dc1e93337") -- Cyberpunk 2077 Speech JP
addappid(1091509, 1, "987c3b4b920a2258661e62065089d398fcc2412b300355c47a2655b4b373fafa") -- Cyberpunk 2077 Speech ZH
addappid(1460470, 1, "97d6dfacfdc6ba0678277cfbdc4f38b561807a3fb8679513411c7b9e819195b3") -- Cyberpunk 2077 Speech KO
addappid(1460471, 1, "20f9808b7948ce1d4b7b16d660e745ce5f251bd0e40c18d8a4072d7f944eb56e") -- Cyberpunk 2077 Speech BRPT
addappid(1460472, 1, "4a09fae0555b97d34d444aedd46d8cd47c11ab25628c614721745c8a3a849c67") -- Depot 1460472
addappid(1460473, 1, "64626ac37340f33f4b81bb2c265d17c61f4fad0b9563bb7b203043296046d2e6") -- Depot 1460473
addappid(1460474, 1, "99ea9ff03413e3248190086be885c4d1737381b7f0f556a1a454cdf978e6c920") -- Depot 1460474
addappid(1460475, 1, "fb5c6a7f869e491c703a7f492c9ade3fe005c518641889a62b16bc6906f799dc") -- Depot 1460475
addappid(1460476, 1, "61fdd193af9b99cedd7e906207aa0226e707f8284c65bd101c576e1d76271f7a") -- Depot 1460476
addappid(1460477, 1, "7d2ad45d3773bf1408ae5c1a830316b4b8e9642ddac137a9f6c222621b922127") -- Depot 1460477
addappid(1460478, 1, "a2da1ad1617b6d8f0063b3d7e1bfd3a05a7f1fd2c52ec2ae6143de6a1b30144d") -- Depot 1460478
addappid(1460479, 1, "7f2d2390ec4b34101279050df7906f9cdb6945d65cb83d41406b90efc6d4820b") -- Depot 1460479
addappid(2060311, 1, "ef94a15784ab7bc81ddec255b4f2af287543f9dd64edc1210faa708302ef4644") -- Depot 2060311
addappid(2060312, 1, "f41e81056d725072d0a92b750b9f7156fc37d87f82cec6b5cc9a6e1907c25724") -- Depot 2060312
addappid(2060313, 1, "e4840e97b028bf1877c6173d714b377621610d8caba91bf5077da9ce6758ae43") -- Depot 2060313
addappid(2060314, 1, "ff813dcc60265582f65f61e4ab399689124c32d7147dc5add8ccc9cb3077310e") -- Depot 2060314
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Cyberpunk 2077 REDmod (AppID: 2060310)
addappid(2060310)
addappid(2060310, 1, "45cf0829a4dae87f0f1b263c92df30079111d1dd697bb87d6830f21e04fdf8a0") -- Cyberpunk 2077 REDmod - Cyberpunk 2077 Test (2060310) Depot
-- Cyberpunk 2077 Phantom Liberty (AppID: 2138330)
addappid(2138330)
addappid(2138330, 1, "0b2b89913e185ab0ac452b5af584c482d5a8c6f34b7b32ae2dda130deaab64bd") -- Cyberpunk 2077 Phantom Liberty - Depot 2138330
addappid(2138331, 1, "2555f9afe152d9355bbc8153ed96c38750b8bbe66724062fde11810dbf132693") -- Cyberpunk 2077 Phantom Liberty - Depot 2138331
addappid(2138332, 1, "4c64a4a0b1cd40244001e3d86e6fc19208ee6f1367cd117683860fcfe9e08dcb") -- Cyberpunk 2077 Phantom Liberty - Depot 2138332
addappid(2138333, 1, "7991a1134455aead3222a58b1246e836804a0ef11faef0284867c29d77d23945") -- Cyberpunk 2077 Phantom Liberty - Depot 2138333
addappid(2138334, 1, "7cf1934dfe03948c22b65d11c4b0df6fe4bb6f05c0b76fc6c240b730cb62c73d") -- Cyberpunk 2077 Phantom Liberty - Depot 2138334
addappid(2138335, 1, "6388e0552ce0fc948e5c93e23902afa0ba9315d78f9eb491422abdc97b390409") -- Cyberpunk 2077 Phantom Liberty - Depot 2138335
addappid(2138336, 1, "c318bdc3350aad3f756cadb68d2dde3954e60869c003ad15d150e0f5d95bdad9") -- Cyberpunk 2077 Phantom Liberty - Depot 2138336
addappid(2138337, 1, "f9d3075d5d20d353263175bd5a682ff396fc3e2e59836a39e018ac81200c505f") -- Cyberpunk 2077 Phantom Liberty - Depot 2138337
addappid(2138338, 1, "6bf9c69492004a9e232ab7c90dbdafae3ae3364cccdf4104df98f3fd02e4ddb7") -- Cyberpunk 2077 Phantom Liberty - Depot 2138338
addappid(2138339, 1, "0d34fa3f0439c9b355882e4e366c4ff89f4e17d2cc2605a05f7473c48ca93bee") -- Cyberpunk 2077 Phantom Liberty - Depot 2138339
addappid(2224070, 1, "13af5172058a27f8523f2caf0b4378c8dc58adf507ff3b8320ee6292ef2db899") -- Cyberpunk 2077 Phantom Liberty - Depot 2224070
addappid(2224071, 1, "317b5b3562f0a547d859f8203880c860e8d47727942c50486f9810b6bee43e93") -- Cyberpunk 2077 Phantom Liberty - Depot 2224071
addappid(2224072, 1, "b98c868ca11a3cb0052c5cb5fc6ed67e755c7f5da8dd080c958c6154eda17f80") -- Cyberpunk 2077 Phantom Liberty - Depot 2224072
addappid(2224073, 1, "43531dc1bf07842e223ac2591bc263b4ce37090bc89d632b94baa4effde4de20") -- Cyberpunk 2077 Phantom Liberty - Depot 2224073
addappid(2224074, 1, "8a45b53465567f0e423a2fb234f868faa70b7b827aa1d4bca9eb1169b7e63a46") -- Cyberpunk 2077 Phantom Liberty - Depot 2224074
addappid(2224075, 1, "aa69ea92143a543978677d384d5ed2ab574470c137cf691ad2de2125e9d0eb9e") -- Cyberpunk 2077 Phantom Liberty - Depot 2224075
addappid(2224076, 1, "c793077de4603ece9521f298182259790c92ea2933a854e3b8fc2729c15791df") -- Cyberpunk 2077 Phantom Liberty - Depot 2224076
addappid(2224077, 1, "f788663dc6d2f5c417e51a5b1a22356e2c3c3a60b85d89672f0216517aa92e73") -- Cyberpunk 2077 Phantom Liberty - Depot 2224077
addappid(2224078, 1, "7ee88193e5b45b787242dfef113c89d6efac43c9ef159c362f44485102488194") -- Cyberpunk 2077 Phantom Liberty - Depot 2224078
addappid(2224079, 1, "ea8df3c3b262a96dd8dd06b0d3ab8393fa170771edee5f40a240488e3edf913b") -- Cyberpunk 2077 Phantom Liberty - Depot 2224079
addappid(2224080, 1, "0cb8af78efc733ca46c7b5a0b9d520b2002b5860fd70f052d59b67dc1112e3ea") -- Cyberpunk 2077 Phantom Liberty - Depot 2224080
addappid(2224089, 1, "284e2db9b686f24646644f365f81f5447d2b26d1363163df229904c8378a0015") -- Cyberpunk 2077 Phantom Liberty - Depot 2224089
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2441600) -- Phantom Liberty Quadra Vigilante Pre-Order Bonus