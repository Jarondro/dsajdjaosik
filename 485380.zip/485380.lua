-- MAIN APPLICATION
addappid(485380) -- Welcome to the Game
-- MAIN APP DEPOTS
addappid(485381, 1, "1b01f26a8d6367d15c37109129e088148234fbf20e8072a4f3d7f2e0b981f90f") -- WTTG Windows
addappid(485382, 1, "9a08ea7e2f9be84a619979326532654f360203fc99a7d0b9b51de91804b8158f") -- WTTG Mac
-- DLCS WITH DEDICATED DEPOTS
-- Welcome to the Game - Hacker Mode (AppID: 557280)
addappid(557280)
addappid(557280, 1, "a5818c699dbd4ace1345714f6410b93bacf9fb3276c809b5a8b508697751c8f4") -- Welcome to the Game - Hacker Mode - Welcome to the Game - Hacker Mode (557280) Depot
-- The Waiting Room (AppID: 744640)
addappid(744640)
addappid(744640, 1, "45e0c74d826d062d7227dd51e4751208c5fb95175f1a66fe2591413e56def2f6") -- The Waiting Room - The Waiting Room (744640) Depot
