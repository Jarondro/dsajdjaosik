-- MAIN APPLICATION
addappid(366090, 1, "66bf0b40e1813cedb6a9aba5e6c50094f4d7998dea99ce3780e6adb5d886ad17") -- Colony Survival
-- MAIN APP DEPOTS
addappid(366091, 1, "9ec618701a0e4539e52db97cba3d1b5848d9c9821ed3ba40d8175c18ba4da50b") -- Windows 32-bit
addappid(366092, 1, "6bce22756e979b001ce91ce94cf0a90ab5ed8ddd6603be8139dea6cd69bcd12b") -- Windows 64-bit
addappid(366095, 1, "e829591abe38a04dd0eccb725a73dfda89d12ebcc953ff9c571ab63441824a52") -- Linux 32-bit
addappid(366096, 1, "b251de5137c42223518ecc6b233a8d0a34afd3f5027483ce8a2a4b5fe4acd423") -- Linux 64-bit
addappid(366093, 1, "4124822435fd86d9f9a5b13bf27e193f64ab899659265996f13fd04d917958c3") -- OSX
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
