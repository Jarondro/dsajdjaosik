-- DLCS WITH DEDICATED DEPOTS
-- MK1 4k Cinematic Pack (AppID: 2615190)
addappid(2615190)
addappid(2615191, 1, "881b5265b81aaa6e34ba005510561510c74dca7c4ddf56e688110dc4708702f7") -- MK1 4k Cinematic Pack - Depot 2615191
-- MK1 Khaos Reigns 4k Cinematic Pack (AppID: 3168020)
addappid(3168020)
addappid(3168021, 1, "30cb9e85c44a2e1796c48b863ad72b03f0c8c8944fc32e93af78420d958df89e") -- MK1 Khaos Reigns 4k Cinematic Pack - Depot 3168021
-- MK1 Khaos Reigns Expansion (AppID: 3233540)
addappid(3233540)
addappid(3233541, 1, "202206a238ab830b8c5dc5506ae41300989cd12ceadff8bb3c6d554bf3feb56b") -- MK1 Khaos Reigns Expansion - Depot 3233541
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2576730) -- MK1 Jean-Claude Van Damme Skin
addappid(2576740) -- MK1 Sub-Zero Da de Muertos Skin
addappid(2576750) -- MK1 Kollectors Edition Liu Kang Skin
addappid(2576760) -- MK1 Tanya Funkeira Skin
addappid(2576770) -- MK1 Kameo Unlock Pack
addappid(2576780) -- Kombat Pack
addappid(2576790) -- MK1 One-Time Dragon Pack
addappid(2576800) -- MK1 Shang Tsung
addappid(2576810) -- MK1 Havik
addappid(2586300) -- Premium Edition 1250 Dragon Krystals
addappid(2636080) -- MK1 Omni-Man
addappid(2636090) -- MK1 Tremor Kameo
addappid(2695680) -- MK1 Quan Chi
addappid(2695690) -- MK1 Khameleon
addappid(2777460) -- MK1 Peacemaker
addappid(2777480) -- MK1 Janet Cage
addappid(2880670) -- MK1 Ermac
addappid(2880680) -- MK1 Mavado
addappid(2968440) -- MK1 Homelander
addappid(2968450) -- MK1 Ferra
addappid(3049390) -- MK1 Takeda Takahashi
addappid(3133990) -- MK1 Khaos Reigns Expansion
addappid(3134000) -- MK1 Khaos Reigns Bundle
addappid(3161240) -- MK1 Khaos Reigns Bundle
addappid(3168140) -- MK1 Cyrax
addappid(3168150) -- MK1 Sektor
addappid(3168160) -- MK1 Noob Saibot
addappid(3168170) -- MK1 Khaos Reigns Skins Pack
addappid(3179910) -- MK1 Kollection Tracking
addappid(3226640) -- MK1 One-time Dragon Pack Kitana
addappid(3226650) -- MK1 Tournament Liu Kang
addappid(3286290) -- MK1 Ghostface
addappid(3286300) -- MK1 T-1000
addappid(3286310) -- MK1 Conan
addappid(3490300) -- MK1 Madam Bo
addappid(3497710) -- MK1 MKT Skins
addappid(3747420) -- Definitive Edition 1250 Dragon Krystals
addappid(3747600) -- MK1 Definitive Edition Upgrade
addappid(3749220) -- MK1 DE Skin Pack