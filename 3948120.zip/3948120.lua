-- MAIN APPLICATION
addappid(3948120) -- Scritchy Scratchy
-- MAIN APP DEPOTS
addappid(3948121, 1, "4d5ba58100eba881f6f9a66ee5982857f3db6a375f5319bdfddd6d9b71defc07") -- Depot 3948121
addappid(3948122, 1, "328927d058e2934b073e34b22bcbf5103daa2dea1879877f2ef930f2cf7ef046") -- Depot 3948122
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4428640) -- Scritchy Scratchy - Supporter Pack