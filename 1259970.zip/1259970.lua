-- MAIN APPLICATION
addappid(1259970) -- eFootball PES 2021 SEASON UPDATE
-- MAIN APP DEPOTS
addappid(1259971, 1, "8f4f2048e2733186e73c0e770628fda90a3d92ad2c70af4863749ddeba27e3bf") -- eFootball PES 2021 Content
addappid(1259972, 1, "8ca1d419cf83b3403c0619844b5e2b35fb12e564c561b21e8aeef0fdf8e4d433") -- english
addappid(1259973, 1, "102f2e08a7ef531af81096a122390bae31eda1ad3eefef8141094ad07f3c53a2") -- swedish
addappid(1259974, 1, "b902e3845f93e64d4f065b9b0e713b1dd7972fcdc072e9d35a6bae2c4e26ed32") -- french
addappid(1259975, 1, "fb9529b147c5fdb59b7059c56916247690eb6cb47d36dce56dd83756d89ad0fe") -- german
addappid(1259976, 1, "96d50c21ab10dd79831986c4892b12002d12d4a068272ca536a91b651fbd885f") -- italian
addappid(1259977, 1, "dd18e068449b918b286644db80a25e47b3ae6d7c3a090f189c2a8465718e1a98") -- dutch
addappid(1259978, 1, "f9d7ad8d78d5473ecd00bcaeed4e2d41a04f9de1288fb6722587e19fd4475dd2") -- turkish
addappid(1259979, 1, "e337522121484f313b712558d0700d26fc7440f2cc5e4376470b638b4b0102e3") -- russian
addappid(1263890, 1, "678789fc61b38a23a6031d275023a97df2bd9a7beb9a4c2b15ed549dbae8ecbe") -- spanish
addappid(1263891, 1, "5eb74cda899512566b7c693b2891ad9182493ee9906e66419599882355a02dfe") -- portuguese
addappid(1263892, 1, "da2de8c4e2112758c7a6b9efe86b01e360a77840aef5ddffc80c1874ec71d092") -- arabic
addappid(1263893, 1, "07b914987e2898d62216376833b2c7843d29ce03923ece490c590f4cba51acad") -- greek
addappid(1263894, 1, "069de456ada61ef4c0b27c3395eb996d9ed599c14497f1f7af28f9efebf32aa8") -- brazil
addappid(1263895, 1, "f697d65930e15146e458c17e3bb8b698d0e1a3583765c8483f5f0c633ebd52d2") -- simplified chinese
addappid(1263896, 1, "de39808f86edd57c329eb4cb80e92b6a2520f43c7f73558c06fbed0ca2e9712e") -- traditional chinese
addappid(1263897, 1, "0fdb3bb3cddae5d96ea6e32a467cf4f5b3e50bd7c3ed3d8c2c826a2d1950aaf2") -- korean
addappid(1263899, 1, "4efe2b88cee14631d6891bd1940342778e21992c27a59b721ad4d3202232893c") -- Japanese
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") -- .NET 4.6 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- eFootball PES 2021 full game certificate (AppID: 1353430)
addappid(1353430)
addtoken(1353430, "18037362000585431908")
addappid(1263898, 1, "08b2df7003b85837e3dc0da301fecee2adbabc129ba7db88058b727dcfb643d2") -- eFootball PES 2021 full game certificate - full game
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1349611) -- eFootball PES 2021 STANDARD EDITION BONUS (Digital)
addtoken(1349611, "9756444231386103696")
addappid(1349612) -- eFootball PES 2021 FC BAYERN MNCHEN EDITION BONUS
addtoken(1349612, "18335107411940895983")
addappid(1349613) -- eFootball PES 2021 JUVENTUS EDITION BONUS
addappid(1349614) -- eFootball PES 2021 MANCHESTER UNITED EDITION BONUS
addtoken(1349614, "18441864700862366575")
addappid(1349616) -- eFootball PES 2021 FC BARCELONA EDITION BONUS
addtoken(1349616, "15362554734561323565")
addappid(1349650) -- eFootball PES 2021 myClub FC BARCELONA
addtoken(1349650, "8073917163232423561")
addappid(1349651) -- eFootball PES 2021 myClub FC BAYERN MUNCHEN
addtoken(1349651, "358577208607775883")
addappid(1349652) -- eFootball PES 2021 myClub JUVENTUS
addappid(1349653) -- eFootball PES 2021 myClub MANCHESTER UNITED
addtoken(1349653, "4765065411747316834")
addappid(1349660) -- eFootball PES 2021 myClub MANCHESTER UNITED Bonus
addtoken(1349660, "15510137838978963481")
addappid(1349661) -- eFootball PES 2021 myClub JUVENTUS Bonus
addappid(1349662) -- eFootball PES 2021 myClub FC BAYERN MUNCHEN Bonus
addtoken(1349662, "10947024288778040431")
addappid(1349663) -- eFootball PES 2021 myClub FC BARCELONA Bonus
addtoken(1349663, "11379290182246790974")