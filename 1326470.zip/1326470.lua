-- MAIN APPLICATION
addappid(1326470) -- Sons Of The Forest
-- MAIN APP DEPOTS
addappid(1326471, 1, "dcc8b76a7563c836c1aed54a46abf85e7fec5fccabc0dd8e176d2151173e508e") -- Depot 1326471
