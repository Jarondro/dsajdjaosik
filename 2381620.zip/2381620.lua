-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2601380) -- Steam Engine Simulator - Power Generation