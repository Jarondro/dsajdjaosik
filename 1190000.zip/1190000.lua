-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1685720) -- Car Mechanic Simulator 2021 - Nissan DLC
addappid(1685721) -- Car Mechanic Simulator 2021 - Electric Car DLC
addappid(1748990) -- Car Mechanic Simulator 2021 - Jaguar DLC
addappid(1748991) -- Car Mechanic Simulator 2021 - Land Rover DLC
addappid(1773800) -- Car Mechanic Simulator 2021 - Pagani Remastered DLC
addappid(1773801) -- Car Mechanic Simulator 2021 - Porsche Remastered DLC
addappid(1931780) -- Car Mechanic Simulator 2021 - Hot Rod DLC
addappid(1981550) -- Car Mechanic Simulator 2021 - Lotus Remastered DLC
addappid(2085260) -- Car Mechanic Simulator 2021 - Mazda Remastered DLC
addappid(2112230) -- Car Mechanic Simulator 2021 - Aston Martin DLC
addappid(2112231) -- Car Mechanic Simulator 2021 - Drag Racing DLC
addappid(2112232) -- Car Mechanic Simulator 2021 - Mercedes Remastered DLC
addappid(2282030) -- Car Mechanic Simulator 2021 - Ford Remastered DLC
addappid(2464230) -- Car Mechanic Simulator 2021 - Dodge  Plymouth  Chrysler DLC
addappid(2546830) -- Car Mechanic Simulator 2021 - China DLC
addappid(2601200) -- Car Mechanic Simulator 2021 - BMW DLC
addappid(2721070) -- Car Mechanic Simulator 2021 - Rims DLC
addappid(2889700) -- Car Mechanic Simulator 2021 - Jeep  RAM Remastered DLC
addappid(3335470) -- Car Mechanic Simulator 2021 - Taxi DLC
addappid(3660210) -- Car Mechanic Simulator 2021 - Police DLC
addappid(4185010) -- Car Mechanic Simulator 2021 - Rims 2 DLC