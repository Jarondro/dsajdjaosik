-- MAIN APPLICATION
addappid(848450) -- Subnautica: Below Zero
-- MAIN APP DEPOTS
addappid(848452, 1, "2faf06aaa2ceea761e8a38f7f8f72d4c64e3768d5e94c600e3c671f2eeffa17e") -- Subnautica Expansion (Windows)
addappid(848453, 1, "396d4aced9c9e5f7fa7f07f8971b1f0d673438dc324831ebd79a9cce5ae693b8") -- Subnautica Expansion (OSX)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
