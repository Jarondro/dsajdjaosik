-- MAIN APPLICATION
addappid(648800) -- Raft
-- MAIN APP DEPOTS
addappid(648801, 1, "69b674ffb72cbe77ce081b29070056279accc29956cad5d38d31e0d3e2090632") -- Raft Content
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
