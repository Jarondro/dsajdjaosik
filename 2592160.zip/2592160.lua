-- MAIN APPLICATION
addappid(2592160, 1, "94ae1de1f6d1f0fb70fe57e5fbcfd7761611372ed8325748dc0f011bcc3781f5") -- Dispatch
-- MAIN APP DEPOTS
addappid(2592161, 1, "5b4a3a4477e47584b99200004c6f4ef8cf41be05df586de9e1771e160fc7527d") -- Depot 2592161
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3920280) -- Dispatch - Deluxe Edition Upgrade