-- MAIN APPLICATION
addappid(972740) -- KOBOLD: Chapter I
-- MAIN APP DEPOTS
addappid(972741, 1, "bb224bafa3ddfe8b1e98d4016391b13a5e31e235b80518ac6b2604c5c54982f4") -- KOBOLD: Chapter I Content
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
