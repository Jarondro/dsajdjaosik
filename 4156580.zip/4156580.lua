-- MAIN APPLICATION
addappid(4156580) -- Weed Supermarket Simulator
-- MAIN APP DEPOTS
addappid(4156581, 1, "b2faec161ec6a0514e36e3777d2bcb3e351efb5ad1088c7614d6c4b7ec218aa9") -- Depot 4156581
