-- MAIN APPLICATION
addappid(1366800, 1, "4dd13eda157bbef37f1b72f4b538e1ee7e6b437bfd5678303e0e9e493215d60e") -- Crosshair X
-- MAIN APP DEPOTS
addappid(1366801, 1, "c5417c02a22d0961ede2808e93da40d019b1d1f88131568488d7659bdc01ddcf") -- ProSight Content
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
