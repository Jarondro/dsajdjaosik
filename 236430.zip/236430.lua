-- MAIN APPLICATION
addappid(236430, 1, "3b01703a979f8e646f85a896dfcf285c5b7dc1132a7a8e5dcb4212b82e267246") -- DARK SOULS™ II
-- MAIN APP DEPOTS
addappid(236432, 1, "eda018a11af0a6a37b59a60dadcbfca12bd721227868fcff4053b8b85e67bd05") -- DARK SOULS™ II TechDev Depot
addappid(236434, 1, "0b32f571e0c05f8fb40ea9d3d4fb2281c9b5431dc2da21a8cc799f96bd6304f6") -- DARK SOULS™ II JP Depot
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Dark Souls II - Pre-Order DLC ROW (AppID: 271940)
addappid(271940)
addappid(271940, 1, "591c3310fabae8ea378bcd7de0d2d6e51021ff65de92140c0869f2a90df0e3ce") -- Dark Souls II - Pre-Order DLC ROW - Dark Souls II - Pre-Order DLC (271940) Depot
-- Dark Souls II - Digital Extras (AppID: 271941)
addappid(271941)
addappid(271941, 1, "e6c617c30eb9d95791592e9fb5200627d32cb74264e74e58d55ffd04d01b0ff6") -- Dark Souls II - Digital Extras - Dark Souls II - Digital Extras (271941) Depot
-- Dark Souls II Crown of the Sunken King (AppID: 271942)
addappid(271942)
addappid(271942, 1, "a1965b62e56b19e4ff236ec31cef3b501ea253fd4d0f958b9f3db502e7e92e86") -- Dark Souls II Crown of the Sunken King - Dark Souls II - DLC 1 (271942) Depot
-- DARK SOULS II Crown of the Old Iron King (AppID: 271943)
addappid(271943)
addappid(271943, 1, "03066e42170eb2798cc95b53972b74fc6ad4e994b1f0ad1c62720136abbd954a") -- DARK SOULS II Crown of the Old Iron King - Dark Souls II - DLC 2 (271943) Depot
--  DARK SOULS II Crown of the Ivory King  (AppID: 271944)
addappid(271944)
addappid(271944, 1, "cce41eba79f1afc8fe13f0c97724e9bf9e1fbe22782a2eb17582fdc3a8b5780e") --  DARK SOULS II Crown of the Ivory King  - Dark Souls II - DLC 3 (271944) Depot
-- Darks Souls II JP Retail Pre-Order DLC 5 (AppID: 289122)
addappid(289122)
addappid(289122, 1, "b48ee6ed45aa5e4caa03670599af7090b3a522984ceb8dc86e9f9094e5c2e0f4") -- Darks Souls II JP Retail Pre-Order DLC 5 - Darks Souls II JP Retail Pre-Order DLC 5 (289122) Depot
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(284450) -- DARK SOULS II - Season Pass
addappid(355700) -- Dark Souls II Upgrade to DX11 (no content)
addtoken(355700, "11688840643228370216")
-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Dark Souls II - Pre-Order DLC JP (AppID: 287360) - missing depot keys
-- addappid(287360)
-- Darks Souls II JP Retail Pre-Order DLC 1 (AppID: 287770) - missing depot keys
-- addappid(287770)
-- Darks Souls II JP Retail Pre-Order DLC 2 (AppID: 287771) - missing depot keys
-- addappid(287771)
-- Darks Souls II JP Retail Pre-Order DLC 3 (AppID: 289120) - missing depot keys
-- addappid(289120)
-- Darks Souls II JP Retail Pre-Order DLC 4 (AppID: 289121) - missing depot keys
-- addappid(289121)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(236431) -- Depot 236431 (empty depot)