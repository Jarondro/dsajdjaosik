addappid(460550)
addtoken(460550, "9585617095825466956")
addappid(460550, 1, "c10f169a7f5cff556e46550868b5ae8b5ff11851d16fdb3524dc1420c975cfe7") -- Hearts of Iron IV German Tanks Pack - Hearts of Iron IV: German Tanks Unit Pack (460550) Depot
-- Hearts of Iron IV French Tanks Pack (AppID: 460551)
addappid(460551)
addtoken(460551, "16275667242675001026")
addappid(460551, 1, "3819a9db13bf790c863cb012854e902995ae3aa6849b4dc221731f02b43b3539") -- Hearts of Iron IV French Tanks Pack - Hearts of Iron IV: French Tanks Unit Pack (460551) Depot
-- Hearts of Iron IV Heavy Cruisers Unit Pack (AppID: 460553)
addappid(460553)
addtoken(460553, "11573714775602706286")
addappid(460553, 1, "5fdc9a36997e71b6d2fca8aa2f20c017127f2ed12447ef42d20a8489f1ede32d") -- Hearts of Iron IV Heavy Cruisers Unit Pack - Hearts of Iron IV: Heavy Cruisers Unit Pack (460553) Depot
-- Hearts of Iron IV Soviet Tanks Unit Pack (AppID: 460554)
addappid(460554)
addtoken(460554, "11238938662297864256")
addappid(460554, 1, "b18063aa7bbece48450ea44d1c19ae8cb80dfafa6eb33b449bd8d0cfae8a8e5b") -- Hearts of Iron IV Soviet Tanks Unit Pack - Hearts of Iron IV: Soviet Tanks Unit Pack (460554) Depot
-- Hearts of Iron IV US Tanks Unit Pack (AppID: 460555)
addappid(460555)
addtoken(460555, "10961420285359384908")
addappid(460555, 1, "90358c1ea70d38de534e78fbc4b1b7495cf8c7530b993d7b27dd56ce29c73a4c") -- Hearts of Iron IV US Tanks Unit Pack - Hearts of Iron IV: US Tanks Unit Pack (460555) Depot
-- Hearts of Iron IV British Tanks Unit Pack (AppID: 460556)
addappid(460556)
addtoken(460556, "10062749250456526762")
addappid(460556, 1, "6defcc9d18882ae376f552fc49a1248e5cccd1bbabee500bf029bdc12e567748") -- Hearts of Iron IV British Tanks Unit Pack - Hearts of Iron IV: British Tanks Unit Packs (460556) Depot
-- Hearts of Iron IV German March Order Music Pack (AppID: 460557)
addappid(460557)
addtoken(460557, "1756483884513088827")
addappid(460557, 1, "3494d9162194df258b972acf2a7971b2176bac05190fa61103ec60fa2641461a") -- Hearts of Iron IV German March Order Music Pack - Hearts of Iron IV: German March Order Music Pack (460557) Depot
-- Hearts of Iron IV Allied Radio Music Pack (AppID: 460558)
addappid(460558)
addtoken(460558, "1778888310352667182")
addappid(460558, 1, "c89a66b596e379bedb101f2ea7424bfff2dcf2004771dea83bca4fbd6b802bb6") -- Hearts of Iron IV Allied Radio Music Pack - Hearts of Iron IV: Allied Radio Music Pack (460558) Depot
-- Hearts of Iron IV Rocket Launcher Unit Pack (AppID: 460559)
addappid(460559)
addtoken(460559, "15137437872504968902")
addappid(460559, 1, "cc7e9d2c3883c3eca4006e1acafac81482f4095b852ff9ffe795526d290c3a27") -- Hearts of Iron IV Rocket Launcher Unit Pack - Hearts of Iron IV: Rocket Launchers Unit Pack (460559) Depot
-- Hearts of Iron IV Poland - United and Ready (AppID: 460600)
addappid(460600)
addtoken(460600, "3999706104044691024")
addappid(460600, 1, "67011014224330c337542bf6f0030bc8a0fac03762b3048d13a6f34e4a2a675b") -- Hearts of Iron IV Poland - United and Ready - Hearts of Iron IV: Polish - United and Ready (460600) Depot
-- Hearts of Iron IV German Historical Portraits (AppID: 460610)
addappid(460610)
addtoken(460610, "10259662308381790200")
addappid(460610, 1, "bcad1434eb9a39898d10ddbb5a74906ffa28bc5455c933eb8620c7cea3dffc10") -- Hearts of Iron IV German Historical Portraits - Hearts of Iron IV: German Historical Portraits (460610) Depot
-- Hearts of Iron IV Sabaton Soundtrack (AppID: 461800)
addappid(461800)
addappid(461800, 1, "0a82a5eed8a7da5bf9bd64cebb03a9b16a56a31f3a63a53b5a8f160ee7563466") -- Hearts of Iron IV Sabaton Soundtrack - Hearts of Iron IV: Sabaton Soundtrack (461800) Depot
-- Hearts of Iron IV Wallpaper (AppID: 472410)
addappid(472410)
addtoken(472410, "5527231669488435870")
addappid(472410, 1, "da6439bdb944123afe1fb7e06b63e9a5e2876bc0de0f5c39cf9057e10eb94db4") -- Hearts of Iron IV Wallpaper - Hearts of Iron IV: Wallpaper (472410) Depot
-- Hearts of Iron IV Artbook (AppID: 473130)
addappid(473130)
addtoken(473130, "17684798506335096366")
addappid(473130, 1, "87d0b5afa061335b45f2f97e44f2828e245c7a19f958be230cc0fcc1947f86d4") -- Hearts of Iron IV Artbook - Hearts of Iron IV: Artbook (473130) Depot
-- Hearts of Iron IV Together for Victory (AppID: 530760)
addappid(530760)
addappid(530760, 1, "a97b49da667b41d9e0d65169630c60b558a038daa8ae39884c89f0c7eea516f9") -- Hearts of Iron IV Together for Victory - Hearts of Iron IV: Together for Victory (530760) Depot
-- Hearts of Iron IV Death or Dishonor (AppID: 584140)
addappid(584140)
addappid(584140, 1, "367370ab05b71cb2e4d774ddbd9fbe14d5e3ead25a4d53db1c6cee33d96d1f3d") -- Hearts of Iron IV Death or Dishonor - Hearts of Iron IV: Death or Dishonor (584140) Depot
-- Hearts of Iron IV Sabaton Soundtrack Vol. 2 (AppID: 584141)
addappid(584141)
addappid(584141, 1, "84e407766f58601bb06db405ccdd310b1500c490c82f90c2e14a1f903e8c8dc9") -- Hearts of Iron IV Sabaton Soundtrack Vol. 2 - Hearts of Iron IV: Sabaton Soundtrack Vol. 2 (584141) Depot
-- Hearts of Iron IV Anniversary Pack (AppID: 642010)
addappid(642010)
addtoken(642010, "6013593090336126140")
addappid(642010, 1, "4866a3c5c0e5269bf0d428932f12481cc9e412bc3d6055adf75e3d38e8034354") -- Hearts of Iron IV Anniversary Pack - Hearts of Iron IV: Anniversary Pack (642010) Depot
-- Hearts of Iron IV Waking the Tiger (AppID: 702350)
addappid(702350)
addappid(702350, 1, "bc6d4e5aa395f974e78bd681f25de70571d6f938e53e8c35d9d7a12db7bb3697") -- Hearts of Iron IV Waking the Tiger - Hearts of Iron IV: Cornflakes (702350) Depot
-- Hearts of Iron IV Man the Guns (AppID: 815460)
addappid(815460)
addappid(815460, 1, "c4ad7f64ac408649ddb507770bd69b8c2678a427e1ea1b36641031ee9a497610") -- Hearts of Iron IV Man the Guns - Hearts of Iron IV: Russian Earl Grey (815460) Depot
-- Hearts of Iron IV Man the Guns Wallpaper (Pre-Order) (AppID: 1032150)
addappid(1032150)
addtoken(1032150, "1857506442554708310")
addappid(1032150, 1, "e385a5d9624e132c3ce8f65105f1c8d0fbcb9ff9f43440cb8fa2f5f83b520a40") -- Hearts of Iron IV Man the Guns Wallpaper (Pre-Order) - Hearts of Iron IV: Man the Guns Wallpaper (Pre-Order) (1032150) Depot
-- Cosmetic Pack - Hearts of Iron IV Axis Armor (AppID: 1086480)
addappid(1086480)
addappid(1086480, 1, "0b83f57f5fe0dea47576984a3073b0fb7c74b9dfe3f59d0d505c2997217aa0c1") -- Cosmetic Pack - Hearts of Iron IV Axis Armor - Hearts of Iron IV: Axis Tanks Unit Pack (1086480) Depot
-- Music - Hearts of Iron IV Radio Pack (AppID: 1086481)
addappid(1086481)
addappid(1086481, 1, "312547d7598d5db9d09e2b656eb1bcc4f1e2d4f8e5e897fe827bce91670a7fee") -- Music - Hearts of Iron IV Radio Pack - Hearts of Iron IV: Radio Music Pack (1086481) Depot
-- Hearts of Iron IV La Rsistance (AppID: 1158100)
addappid(1158100)
addappid(1158100, 1, "417579bb04c14ef0c0a99b84d4527addedcf4b5f42f79f36ae1736844da654a8") -- Hearts of Iron IV La Rsistance - Hearts of Iron IV: Project Husky (1158100) Depot
-- Hearts of Iron IV La Rsistance Pre-Order Bonus (AppID: 1206030)
addappid(1206030)
addtoken(1206030, "14207592363682915451")
addappid(1206030, 1, "0fe9516c65785cf6906d9934e368a92e72c395edac615955f7cae610a60279a1") -- Hearts of Iron IV La Rsistance Pre-Order Bonus - Hearts of Iron IV: Project Husky Fur (1206030) Depot
-- Cosmetic Pack - Hearts of Iron IV Allied Armor (AppID: 1317230)
addappid(1317230)
addappid(1317230, 1, "b513b57fee4591f7d9f2e6883fef1019051dd93259eee88f8a1513a29c5807c2") -- Cosmetic Pack - Hearts of Iron IV Allied Armor - Hearts of Iron IV: Allied Armor Pack (1317230) Depot
-- Music - Hearts of Iron IV Allied Speeches Pack (AppID: 1317250)
addappid(1317250)
addappid(1317250, 1, "b19bdf31327b07945efbf7cb689df20880b2312fe9797f030844bd8251043531") -- Music - Hearts of Iron IV Allied Speeches Pack - Hearts of Iron IV: Allied Speeches Radio Pack (1317250) Depot
-- Country Pack - Hearts of Iron IV Battle for the Bosporus (AppID: 1348660)
addappid(1348660)
addappid(1348660, 1, "442d4c3ced2da36e4728ea1225129227b54a92264e3d7ceb36b37061cb772a65") -- Country Pack - Hearts of Iron IV Battle for the Bosporus - Hearts of Iron IV: Project Collie (1348660) Depot
-- Hearts of Iron IV No Step Back (AppID: 1348661)
addappid(1348661)
addappid(1348661, 1, "90210499739763009b116193b4dfa4f9660c987fe76c5b57fa4ebf5ae9d791d8") -- Hearts of Iron IV No Step Back - Hearts of Iron IV: Project Barbarossa (1348661) Depot
-- Cosmetic Pack - Hearts of Iron IV Eastern Front Planes (AppID: 1579991)
addappid(1579991)
addappid(1579991, 1, "3d68de74eaadbaf29c12201591f7643c5d61c738ac124fc97ff61c53ee586c78") -- Cosmetic Pack - Hearts of Iron IV Eastern Front Planes - Hearts of Iron IV: Project Collie Fur (1579991) Depot
-- Music - Hearts of Iron IV Songs of the Eastern Front (AppID: 1579992)
addappid(1579992)
addappid(1579992, 1, "763bd218331be2765a97d624c56e09c373fd00e657d3d66f343b230599ce6365") -- Music - Hearts of Iron IV Songs of the Eastern Front - Hearts of Iron IV: Project Collie Tail (1579992) Depot
-- Hearts of Iron IV No Step Back - Katyusha (Pre-Order Bonus) (AppID: 1785140)
addappid(1785140)
addappid(1785140, 1, "1a80928b279ecfcc82751e89918e6c29725797022d8b76e2207c4eb0f9fcad92") -- Hearts of Iron IV No Step Back - Katyusha (Pre-Order Bonus) - Hearts of Iron IV: Project Barbarossa P (1785140) Depot
-- Hearts of Iron IV By Blood Alone (AppID: 1880650)
addappid(1880650)
addappid(1880650, 1, "3c4781bac59c92ee366aeb4a3f6e6e66fc9e247731eef90a13db05bdbab47774") -- Hearts of Iron IV By Blood Alone - Depot 1880650
-- Hearts of Iron IV By Blood Alone (Pre-Order Bonus) (AppID: 1880660)
addappid(1880660)
addappid(1880660, 1, "35ad0071c08a5e2142c146e0c620f0463f6e6db590cc216970cb2cffa7c1ed97") -- Hearts of Iron IV By Blood Alone (Pre-Order Bonus) - Depot 1880660
-- Hearts of Iron IV Arms Against Tyranny (AppID: 2183930)
addappid(2183930)
addappid(2183930, 1, "157cf6d2f8725bcb35250fea726ee2806b46836405b6a9de22b17e7c75bc18d0") -- Hearts of Iron IV Arms Against Tyranny - Depot 2183930
-- Hearts of Iron IV Arms Against Tyranny - Skkijrven Polkka (AppID: 2280250)
addappid(2280250)
addappid(2280250, 1, "bf241195711d1509cee05bcc4b5f9c90cacedd9de071f2b2bdc474417be35485") -- Hearts of Iron IV Arms Against Tyranny - Skkijrven Polkka - Depot 2280250
-- Country Pack - Hearts of Iron IV Trial of Allegiance (AppID: 2695150)
addappid(2695150)
addappid(2695150, 1, "3adc98cb6857ffdbb33dc39f0a55f767672396004827344ff611700ce53fd9c2") -- Country Pack - Hearts of Iron IV Trial of Allegiance - Depot 2695150
-- Country Pack - Hearts of Iron IV Trial of Allegiance Pre-order Bonus (AppID: 2786480)
addappid(2786480)
addappid(2786480, 1, "f01467b0fa4734ee2f04b0de1c2e2e6fdfd1ff017708e7571a18f9dc1c868390") -- Country Pack - Hearts of Iron IV Trial of Allegiance Pre-order Bonus - Depot 2786480
-- Hearts of Iron IV Content Creator Pack - Soviet Union 2D (AppID: 2981720)
addappid(2981720)
addappid(2981720, 1, "e6c2ccd3152d32b6f83f546feb98bde8e477df96162cd8d71b4a430941ebb879") -- Hearts of Iron IV Content Creator Pack - Soviet Union 2D - Depot 2981720
-- Expansion - Hearts of Iron IV Gtterdmmerung (AppID: 3152780)
addappid(3152780)
addappid(3152780, 1, "1ab7182cba3aa4cef6510149eef4794796be5ec8d80f8443c46e42d82e086157") -- Expansion - Hearts of Iron IV Gtterdmmerung - Depot 3152780
-- Country Pack - Hearts of Iron IV Graveyard of Empires (AppID: 3152790)
addappid(3152790)
addappid(3152790, 1, "f6086a1fa52b8db2e8ef6e941724531584e64b374c99f8383238747e86d53c96") -- Country Pack - Hearts of Iron IV Graveyard of Empires - Depot 3152790
-- Cosmetic Pack - Hearts of Iron IV Prototype Vehicles (AppID: 3152800)
addappid(3152800)
addappid(3152800, 1, "f7c43c7f2eee064c93357a502e21e56c5938af3798991eee657cf6fa78a81388") -- Cosmetic Pack - Hearts of Iron IV Prototype Vehicles - Depot 3152800
-- Expansion pass 1 Bonus - Hearts of Iron IV Supporter Pack (AppID: 3152820)
addappid(3152820)
addappid(3152820, 1, "aa2c6313d363bbb39ed44c21cc29501031156abe975c269bace4e23b99268543") -- Expansion pass 1 Bonus - Hearts of Iron IV Supporter Pack - Depot 3152820
-- Expansion Pass 1 Bonus - Hearts of Iron IV Ride of the Valkyries Music (AppID: 3152840)
addappid(3152840)
addappid(3152840, 1, "feba775f8944a74904f8b1084a4ea00c67ffbb21d7ada3192d4e2df68f28cd9a") -- Expansion Pass 1 Bonus - Hearts of Iron IV Ride of the Valkyries Music - Depot 3152840
-- Hearts of Iron IV Seaplane Tenders (AppID: 3796250)
addappid(3796250)
addappid(3796250, 1, "3b5a157bca6454b92d2414ee234ae568af431e003d8550f90c4ea39fb0eeb4ea") -- Hearts of Iron IV Seaplane Tenders - Depot 3796250
-- Expansion - Hearts of Iron IV No Compromise, No Surrender (AppID: 3796260)
addappid(3796260)
addappid(3796260, 1, "2688a757fe15aba9d24a7079821c09109c265946b32c0c166c24c1a6c8a8a199") -- Expansion - Hearts of Iron IV No Compromise, No Surrender - Depot 3796260
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(445630) -- Hearts of Iron IV War Stories
addtoken(445630, "16694871766851180349")
addappid(554840) -- Hearts of Iron IV Expansion Pass DLC
addappid(616200) -- Hearts of Iron IV Colonel Edition Upgrade Pack
addappid(1877010) -- Hearts of Iron IV - DLC Subscription
addappid(3152810) -- Hearts of Iron IV Expansion Pass 1
addappid(3654400) -- Hearts of Iron IV Bonus Songs Pack
addappid(3796240) -- Hearts of Iron IV Expansion Pass 2
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3757310) -- Focus Pack - Hearts of Iron IV: Peace for our Time (unreleased)
-- addappid(3796270) -- Cosmetic Pack - Hearts of Iron IV:  Warships of the Pacific (unreleased)
-- addappid(3796290) -- Theater Pack - Hearts of Iron IV: Thunder at our Gates (unreleased)