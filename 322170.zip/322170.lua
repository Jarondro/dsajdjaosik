-- MAIN APPLICATION
addappid(322170, 1, "ad9b88bbea506f1fdeada87713d73123f34a9757ec404f69125253369540b6f2") -- Geometry Dash
-- MAIN APP DEPOTS
addappid(322171, 1, "73d09cfe5a697e2e5bf2a2591259e00c715e9dc3376d4a71ff7e915483be399d") -- Geometry Dash Windows
addappid(322172, 1, "6accd00ac7da1a455e3e689eed217adcdcb14198e5dd23b1e553abbed6d5c38e") -- Geometry Dash Mac
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
