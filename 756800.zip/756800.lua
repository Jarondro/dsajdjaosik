-- MAIN APPLICATION
addappid(756800, 1, "833c66d8422fc8f1c49e21d67906787b24619d693882a43d444afc6c6c699bff") -- Contraband Police
-- MAIN APP DEPOTS
addappid(756801, 1, "1e813879ae7ee6dc69988e440b40c97412996770a6720c6ffeed76214ac6ce07") -- Depot 756801
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(3439880) -- Contraband Police - Crimson Fall (unreleased)