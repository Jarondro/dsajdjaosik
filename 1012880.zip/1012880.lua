- MAIN APPLICATION
addappid(1012880, 1, "9604cb48ff5dc92f51032d77feb0ee97e2f4b4f1ebca130c1dd7d0a11984046c") -- 60 Seconds! Reatomized
-- MAIN APP DEPOTS
addappid(1012881, 1, "0f953c110914b4b70a6b6846415d46d0386b0cc1ce3874be245f8b14f494ab6f") -- 60 Seconds! Remaster Win64
addappid(1012882, 1, "8daf35d709e19c788b82f7b20528bb2633d0ed73b8cebb055b448c3ac4d822f5") -- 60 Seconds! Remaster - macOS
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1012883) -- Depot 1012883 (empty depot)