-- MAIN APPLICATION
addappid(12110) -- Grand Theft Auto: Vice City
-- MAIN APP DEPOTS
addappid(12111, 1, "a7ad1f1b98647e90ed852384deda16f4822fd85665445503aa576ca6f82bdcb5") -- Grand Theft Auto Vice City content
-- EMPTY DEPOTS (no content on any branch)
-- addappid(12113) -- Depot 12113 (empty depot)
-- addappid(12114) -- Depot 12114 (empty depot)
-- addappid(12115) -- Depot 12115 (empty depot)
-- addappid(12116) -- Depot 12116 (empty depot)
-- addappid(12117) -- Depot 12117 (empty depot)