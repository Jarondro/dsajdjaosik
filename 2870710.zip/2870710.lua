-- MAIN APPLICATION
addappid(2870710) -- Pih
-- MAIN APP DEPOTS
addappid(2870711, 1, "b2ddc85ffb0094b75d9222fd057d715f4f6d039e242ac38f31d18e49e9914304") -- Depot 2870711
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
