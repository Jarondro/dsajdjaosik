-- MAIN APPLICATION
addappid(1030840) -- Mafia: Definitive Edition
-- MAIN APP DEPOTS
addappid(1030841, 1, "d6e79f53321a7947e8963e27e1baefb862ce738eb51a2fa8eeaa90c476917f64") -- Scotch Content
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
-- DLCS WITH DEDICATED DEPOTS
-- Chicago Pack (AppID: 1316300)
addappid(1316300)
addtoken(1316300, "16475343798686789276")
addappid(1316300, 1, "724c017202bf35f19f8cdbbec2e6a859a2d88b805b1abe089d4d8a329b318471") -- Chicago Pack - Chicago Pack (1316300) Depot
