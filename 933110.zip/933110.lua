-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1581450) -- Age of Empires III Definitive Edition - United States Civilization
addappid(1581451) -- Age of Empires III  DE The African Royals
addappid(1817361) -- Age of Empires III Definitive Edition - Knights of the Mediterranean
addappid(1817370) -- Age of Empires III Definitive Edition - Mexico Civilization
addappid(2154360) -- Age of Empires III Definitive Edition  Hero Cosmetic Pack  Lizzie
addappid(2154361) -- Age of Empires III Definitive Edition  Hero Cosmetic Pack  Kunoichi
addappid(2154362) -- Age of Empires III Definitive Edition  Hero Cosmetic Pack  Vol. 1
addappid(2477660) -- Age of Empires III Definitive Edition (Base Game)