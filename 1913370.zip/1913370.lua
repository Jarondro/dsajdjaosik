-- MAIN APPLICATION
addappid(1913370) -- OPERATOR
-- MAIN APP DEPOTS
addappid(1913371, 1, "14e1d60b03f5511ee5e4a550d5f3d5a71dd6317cf8b974cd3aec8077798ecdaf") -- Depot 1913371
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(1913372) -- Depot 1913372 (empty depot)