-- MAIN APPLICATION
addappid(12100) -- Grand Theft Auto III
-- MAIN APP DEPOTS
addappid(12101, 1, "a6808fc3d1c16fdf788138c0cfbb9fb7602de9d9018b0091f2ab65c8b7f7e82a") -- Grand Theft Auto 3 content
